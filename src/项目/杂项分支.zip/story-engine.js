/* ===================================================
 * 《问道修仙学院》剧情对话引擎 v2.0
 *
 * 负责：场景渲染 / 对话流转 / 选项分支 / 旗标 & 奖励
 *
 * 调用：
 *   Story.play(sceneId, STORY_DATA, onFinish)
 *   Story.seen(sceneId)        判断是否已播放过
 *   Story.markSeen(sceneId)    手动标记
 *
 * 数据结构（与 story-data.js 对齐）：
 *   sceneId: {
 *     id, lines:[{speaker, avatar, text}],
 *     choices?:[{text, next, flag, reward:{daoxin,stones,exp}}],
 *     reward?:{...},                  // 场景结束统一奖励
 *     onEnd?: function(Game){...}     // 自定义钩子（可选）
 *   }
 * =================================================== */

(function (global) {
  'use strict';

  // ====== 已播放剧情（持久化在 Game.state.flags.seenScenes） ======
  function _flags() {
    if (!global.Game || !Game.state) return { seenScenes: {} };
    Game.state.flags = Game.state.flags || {};
    Game.state.flags.seenScenes = Game.state.flags.seenScenes || {};
    return Game.state.flags;
  }

  function seen(id) {
    return !!_flags().seenScenes[id];
  }
  function markSeen(id) {
    _flags().seenScenes[id] = true;
    if (global.Game && Game.save) Game.save();
  }

  // ====== 渲染遮罩 ======
  function _mountMask() {
    let mask = document.querySelector('.xx-story-mask');
    if (mask) return mask;
    mask = document.createElement('div');
    mask.className = 'xx-story-mask';
    mask.innerHTML = `
      <div class="xx-story-box">
        <div class="xx-story-speaker">
          <div class="xx-story-avatar" id="story-avatar">🌌</div>
          <div class="xx-story-name" id="story-name">???</div>
        </div>
        <div class="xx-story-text" id="story-text"></div>
        <div class="xx-story-choices" id="story-choices"></div>
        <div class="xx-story-next" id="story-next">▼ 点击继续</div>
      </div>
    `;
    document.body.appendChild(mask);
    return mask;
  }

  function _typewriter(el, text, speed, done) {
    el.textContent = '';
    let i = 0;
    const N = text.length;
    let stopped = false;
    function tick() {
      if (stopped) return;
      if (i >= N) { done && done(); return; }
      el.textContent += text.charAt(i++);
      setTimeout(tick, speed);
    }
    tick();
    return () => { stopped = true; el.textContent = text; done && done(); };
  }

  // ====== 应用奖励 ======
  function _applyReward(rwd) {
    if (!rwd || !global.Game) return;
    if (rwd.daoxin) Game.addDaoxin(rwd.daoxin);
    if (rwd.stones) Game.addStones(rwd.stones);
    if (rwd.exp)    Game.addExp(rwd.exp);
    if (rwd.flag)   { Game.state.flags = Game.state.flags || {}; Game.state.flags[rwd.flag] = true; Game.save(); }
    // v2.0 法宝/技能解锁（如果 game-core 支持）
    if (rwd.artifact && Game.unlockArtifact) Game.unlockArtifact(rwd.artifact);
    if (rwd.skill    && Game.unlockSkill)    Game.unlockSkill(rwd.skill);
  }

  // ====== 主播放器 ======
  const Story = {
    seen,
    markSeen,

    play(sceneId, DATA, onFinish) {
      DATA = DATA || global.STORY_DATA || {};
      const scene = DATA[sceneId];
      if (!scene) {
        console.warn('[Story] 场景不存在:', sceneId);
        onFinish && onFinish();
        return;
      }
      const mask = _mountMask();
      mask.style.display = 'flex';

      const elName    = mask.querySelector('#story-name');
      const elAvatar  = mask.querySelector('#story-avatar');
      const elText    = mask.querySelector('#story-text');
      const elChoices = mask.querySelector('#story-choices');
      const elNext    = mask.querySelector('#story-next');

      let idx = 0;
      let skip = null;
      const lines = scene.lines || [];

      function showLine() {
        elChoices.innerHTML = '';
        elNext.style.display = 'none';

        if (idx >= lines.length) {
          // 末尾：要么选项，要么结束
          if (scene.choices && scene.choices.length) {
            _renderChoices(scene.choices);
          } else {
            _end();
          }
          return;
        }

        const ln = lines[idx];
        elName.textContent   = ln.speaker || '';
        elAvatar.textContent = ln.avatar  || '✨';

        skip = _typewriter(elText, ln.text || '', 35, () => {
          elNext.style.display = 'block';
        });
      }

      function _renderChoices(choices) {
        elText.textContent = ' ';
        elNext.style.display = 'none';
        elChoices.innerHTML = '';
        choices.forEach((ch) => {
          const btn = document.createElement('button');
          btn.className = 'xx-story-choice';
          btn.textContent = ch.text;
          btn.onclick = () => {
            if (ch.reward) _applyReward(ch.reward);
            if (ch.flag) {
              Game.state.flags = Game.state.flags || {};
              Game.state.flags[ch.flag] = true;
              Game.save();
            }
            if (ch.next && DATA[ch.next]) {
              mask.style.display = 'none';
              Story.play(ch.next, DATA, onFinish);
            } else {
              _end();
            }
          };
          elChoices.appendChild(btn);
        });
      }

      function _end() {
        markSeen(sceneId);
        if (scene.reward) _applyReward(scene.reward);
        if (typeof scene.onEnd === 'function') {
          try { scene.onEnd(global.Game); } catch (e) { console.warn(e); }
        }
        mask.style.display = 'none';
        // 顶部状态栏刷新（如果存在）
        if (global.UI && UI.refreshTopbar) UI.refreshTopbar();
        onFinish && onFinish();
      }

      // 点击：未打完则跳过打字，已打完则下一句
      mask.onclick = (e) => {
        if (e.target.tagName === 'BUTTON') return; // 选项按钮自己处理
        if (skip && elNext.style.display === 'none') {
          skip(); // 跳过打字效果
        } else {
          idx++;
          showLine();
        }
      };

      showLine();
    }
  };

  global.Story = Story;

})(typeof window !== 'undefined' ? window : this);
