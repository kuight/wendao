/* ===================================================
 * 《问道修仙学院》UI 通用组件 v2.0
 * v1.0：顶部状态栏 / 弹窗 / Toast / 角色面板 / 境界突破
 * v2.0 新增：灵根抽取 / 法宝阁 / 洞府 / 秘境 / 每日任务 /
 *            战斗技能栏 / 答题特效 / 灵气粒子背景
 * =================================================== */

(function (global) {
  'use strict';

  const UI = {

    // ====== Toast 飘字 ======
    toast(text, type = 'info', dur = 2800) {
      let wrap = document.querySelector('.xx-toast-wrap');
      if (!wrap) {
        wrap = document.createElement('div');
        wrap.className = 'xx-toast-wrap';
        document.body.appendChild(wrap);
      }
      const t = document.createElement('div');
      t.className = 'xx-toast ' + type;
      t.textContent = text;
      wrap.appendChild(t);
      setTimeout(() => { t.remove(); }, dur + 200);
    },

    // ====== 顶部状态栏（v3.0：增加 HP/MP + 灵根徽章） ======
    renderTopbar(opts = {}) {
      if (Game._ensureAllFields) Game._ensureAllFields();
      const c = Game.state.char;
      const realm = Game.currentRealm();
      const backHref = opts.backHref || 'index.html';
      const inSubPage = !!opts.backHref;
      const root = Game.getSpiritRoot && Game.getSpiritRoot();
      const rootBadge = root ? `<span class="xx-stat root-badge">${root.icon} ${root.name}</span>` : '';
      // 境界tag着色（v4 每大境界有色）
      const realmColor = realm.color || '#f5c97a';
      const html = `
        <div class="xx-topbar">
          <div class="brand">
            <a href="${backHref}" style="color:inherit;text-decoration:none;">⚔ 问道修仙学院</a>
            <span class="v-tag">v4.0</span>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center;">
            <span class="xx-stat xx-realm-tag" style="border-color:${realmColor};color:${realmColor};">${realm.name}</span>
            ${rootBadge}
            <span class="xx-stat" title="气血"><span>❤️</span> <b>${c.hp}/${c.maxHp}</b></span>
            <span class="xx-stat" title="灵力"><span>💫</span> <b>${c.mp}/${c.maxMp}</b></span>
            <span class="xx-stat" title="道心"><span>🧘</span> <b>${c.daoxin}</b></span>
            <span class="xx-stat"><span>💎</span> <b>${c.lingshi}</b></span>
            <span class="xx-stat"><span>🔥</span> <b>${c.streak}</b></span>
            ${ inSubPage ? `<a href="${backHref}" class="xx-btn">⬅ 山门</a>` : ''}
          </div>
        </div>
      `;
      return html;
    },

    refreshTopbar(opts = {}) {
      const old = document.querySelector('.xx-topbar');
      if (!old) return;
      const tmp = document.createElement('div');
      tmp.innerHTML = this.renderTopbar(opts);
      old.replaceWith(tmp.firstElementChild);
    },

    // ====== 弹窗 ======
    modal(opts = {}) {
      const { title = '', body = '', actions = [], onClose, wide = false } = opts;
      const mask = document.createElement('div');
      mask.className = 'xx-modal-mask';

      const m = document.createElement('div');
      m.className = 'xx-modal' + (wide ? ' xx-modal-wide' : '');
      m.innerHTML = `
        <button class="xx-modal-close" aria-label="关闭">×</button>
        ${title ? `<h3 class="xx-modal-title">${title}</h3>` : ''}
        <div class="xx-modal-body">${body}</div>
        ${actions.length ? `<div class="quest-actions" style="margin-top:16px;justify-content:flex-end;"></div>` : ''}
      `;

      const close = () => {
        mask.remove();
        if (onClose) onClose();
      };

      m.querySelector('.xx-modal-close').onclick = close;
      mask.onclick = (e) => { if (e.target === mask) close(); };

      if (actions.length) {
        const aw = m.querySelector('.quest-actions');
        actions.forEach(a => {
          const b = document.createElement('button');
          b.className = 'xx-btn ' + (a.primary ? 'xx-btn-primary' : '');
          b.textContent = a.label;
          b.onclick = () => {
            if (a.onClick && a.onClick() === false) return; // 返回 false 阻止关闭
            close();
          };
          aw.appendChild(b);
        });
      }

      mask.appendChild(m);
      document.body.appendChild(mask);
      return { close, mask, m };
    },

    confirm(text, onYes) {
      return this.modal({
        title: '⚠ 确认',
        body: `<p>${text}</p>`,
        actions: [
          { label: '取消' },
          { label: '确定', primary: true, onClick: onYes }
        ],
      });
    },

    // ====== 境界突破特效 ======
    breakthrough(realm) {
      const mask = document.createElement('div');
      mask.className = 'breakthrough-mask';
      mask.innerHTML = `
        <div class="breakthrough-text">突 破</div>
        <div class="breakthrough-realm">${realm.name}</div>
        <div style="color:#f5c97a;margin-top:14px;font-size:14px;letter-spacing:2px;">${realm.sub}</div>
      `;
      document.body.appendChild(mask);
      setTimeout(() => mask.remove(), 2200);
      this.toast(`恭喜突破至「${realm.name}」`, 'success', 3500);
    },

    // ====== 角色面板（v3.0：2D 立绘 + HP/MP + 装备预览） ======
    renderCharPanel() {
      if (Game._ensureAllFields) Game._ensureAllFields();
      const c = Game.state.char;
      const realm = Game.currentRealm();
      const next = Game.nextRealm();
      const progress = Math.round(Game.realmProgress() * 100);
      const acc = (Game.accuracy() * 100).toFixed(1);
      const hpPct = Math.round((c.hp||0) / (c.maxHp||1) * 100);
      const mpPct = Math.round((c.mp||0) / (c.maxMp||1) * 100);
      const pet = c.pet;
      const petBadge = pet ? `<div style="margin-top:8px;font-size:12px;color:var(--xx-purple);">🐉 ${pet.emoji} ${pet.name} · Lv.${pet.level}</div>` : '';
      return `
        <div class="char-panel">
          <div class="char-avatar-box">
            <div class="char-portrait">
              <div class="char-portrait-body">
                <span class="char-portrait-emoji">${c.avatar||'🧙'}</span>
              </div>
            </div>
            <div class="char-name">${c.name}</div>
            <div style="color:var(--xx-text-dim);font-size:12px;margin-top:4px;">${c.title}</div>
            <div style="margin-top:12px;">
              <span class="xx-stat xx-realm-tag">${realm.name}</span>
            </div>
            <div style="font-size:12px;color:var(--xx-text-soft);margin-top:6px;">${realm.sub}</div>
            ${petBadge}
          </div>
          <div class="char-info-box">
            <div style="font-family:var(--xx-font-art);font-size:16px;color:var(--xx-gold);letter-spacing:2px;">⚡ 修为进度</div>
            <div class="cult-bar-wrap">
              <div class="cult-bar"><div class="cult-bar-fill" style="width:${progress}%"></div></div>
              <div class="cult-bar-label">
                <span>${c.exp} / ${next ? next.need : c.exp}</span>
                <span>${next ? `距「${next.name}」${next.need - c.exp} 修为` : '已至飞升真仙'}</span>
              </div>
            </div>
            <!-- v3：HP / MP 双条状态 -->
            <div class="cult-bar-wrap" style="margin-top:10px;">
              <div style="font-size:11px;color:var(--xx-text-dim);">❤ 气血  ${c.hp} / ${c.maxHp}</div>
              <div class="cult-bar" style="height:8px;"><div class="cult-bar-fill" style="width:${hpPct}%;background:var(--v3-hp);"></div></div>
            </div>
            <div class="cult-bar-wrap" style="margin-top:6px;">
              <div style="font-size:11px;color:var(--xx-text-dim);">💫 灵力  ${c.mp} / ${c.maxMp}</div>
              <div class="cult-bar" style="height:8px;"><div class="cult-bar-fill" style="width:${mpPct}%;background:var(--v3-mp);"></div></div>
            </div>

            <div class="stat-grid">
              <div class="stat-item cyan"><div class="lab">💎 灵石</div><div class="val">${c.lingshi}</div></div>
              <div class="stat-item green"><div class="lab">🧘 道心</div><div class="val">${c.daoxin}</div></div>
              <div class="stat-item gold"><div class="lab">⚔ 攻击</div><div class="val">${c.atk}</div></div>
              <div class="stat-item purple"><div class="lab">🛡 防御</div><div class="val">${c.def}</div></div>
              <div class="stat-item purple"><div class="lab">🔥 最高连击</div><div class="val">${c.bestStreak}</div></div>
              <div class="stat-item"><div class="lab">📊 正确率</div><div class="val">${acc}%</div></div>
              <div class="stat-item"><div class="lab">⚔ 共答题</div><div class="val">${c.totalAnswered}</div></div>
              <div class="stat-item red"><div class="lab">😈 心魔</div><div class="val">${Game.heartDemons().length}</div></div>
            </div>
          </div>
        </div>
      `;
    },

    // ============================================================
    //  v4.0 修复：主页四宫格（洞府/秘境/法宝阁/每日任务）
    //  v3 中此方法缺失，导致主页 four-grid-mount 一片空白
    // ============================================================
    renderFourGrid() {
      if (Game._ensureAllFields) Game._ensureAllFields();
      const cave = Game.state.cave || { level:1 };
      const secret = Game.state.secret || { count:0 };
      const daily = Game.state.daily || { tasks:[] };
      const artifacts = (Game.state.char && Game.state.char.artifacts) || [];
      const pills = Object.keys(Game.state.pills || {}).reduce((s,k)=>s+(Game.state.pills[k]||0),0);
      const gears = Object.keys(Game.state.gears || {}).length;
      const pet = Game.state.char && Game.state.char.pet;
      // 每日任务已领取/总数
      const totalDaily = (daily.tasks || []).length;
      const doneDaily  = (daily.tasks || []).filter(t => t.claimed).length;
      const canMed = Game.canMeditate && Game.canMeditate();
      const canSec = Game.canEnterSecret && Game.canEnterSecret();

      const cell = (o) => `
        <div class="xx-four-cell ${o.hot?'hot':''}" data-open="${o.id}">
          <div class="xx-four-icon" style="background:${o.bg};color:${o.fg};">${o.icon}</div>
          <div class="xx-four-body">
            <div class="xx-four-title">${o.title}</div>
            <div class="xx-four-desc">${o.desc}</div>
            <div class="xx-four-badge">${o.badge}</div>
          </div>
          <div class="xx-four-arrow">➤</div>
        </div>
      `;
      return `
        <div class="xx-four-grid">
          ${cell({ id:'cave',  icon:'🏔', bg:'rgba(110,213,224,0.15)', fg:'#6ed5e0',
                    title:'洞府闭关', desc:'打坐冥想恢复道心 + 修为', hot:canMed,
                    badge:`Lv.${cave.level||1} · ${canMed?'✅可打坐':'⏳冷却中'}` })}
          ${cell({ id:'secret',icon:'🌌', bg:'rgba(178,136,255,0.15)', fg:'#b288ff',
                    title:'秘境探索', desc:'随机奇遇 / 稀有掉落', hot:canSec,
                    badge:`已探 ${secret.count||0} 次 · ${canSec?'🚪可进入':'⏳未就绪'}` })}
          ${cell({ id:'artifact',icon:'🔮', bg:'rgba(245,201,122,0.15)', fg:'#f5c97a',
                    title:'法宝阁', desc:'法宝 · 装备 · 丹药 · 灵宠', hot:false,
                    badge:`法宝 ${artifacts.length} · 丹 ${pills} · 装 ${gears} ${pet?'· 宠🐉':''}` })}
          ${cell({ id:'daily', icon:'📋', bg:'rgba(140,226,140,0.15)', fg:'#8ce28c',
                    title:'每日任务', desc:'每日 4 项，坚持稳步精进', hot:doneDaily<totalDaily,
                    badge:`${doneDaily}/${totalDaily} 已领取` })}
          ${cell({ id:'gear', icon:'⚔', bg:'rgba(255,158,198,0.15)', fg:'#ff9ec6',
                    title:'装备阁', desc:'武器·衣袍·法器·头冠 四部位', hot:false,
                    badge:`已藏 ${gears} 件 · 已装 ${Object.values(((Game.state.char||{}).equippedGear)||{}).filter(Boolean).length||0}/4` })}
          ${cell({ id:'pill', icon:'💊', bg:'rgba(243,156,86,0.15)', fg:'#f39c56',
                    title:'丹药房', desc:'恢复气血 · 增益修为', hot:false,
                    badge:`存丹 ${pills} 粒` })}
          ${cell({ id:'pet', icon:'🐉', bg:'rgba(127,179,255,0.15)', fg:'#7fb3ff',
                    title:'灵宠殿', desc:'白虎/青龙/朱雀/玄武/麒麟', hot:!pet,
                    badge:`${pet?(pet.emoji+' '+pet.name+' Lv.'+pet.level):'尚未拜师'}` })}
          ${cell({ id:'achv', icon:'🏆', bg:'rgba(245,201,122,0.15)', fg:'#f5c97a',
                    title:'成就殿堂', desc:'30 项成就 · 记录辉煌', hot:false,
                    badge:`${Object.values(Game.state.achievements||{}).filter(x=>x.done).length} / ${Object.keys(Game.ACHIEVEMENTS||{}).length} 已达成` })}
        </div>
      `;
    },

    bindFourGrid() {
      const grid = document.querySelector('.xx-four-grid');
      if (!grid) return;
      grid.querySelectorAll('[data-open]').forEach(el => {
        el.onclick = () => {
          const key = el.dataset.open;
          if (key === 'cave')     this._openCaveModal();
          else if (key === 'secret')   this._openSecretModal();
          else if (key === 'artifact') this._openArtifactModal();
          else if (key === 'daily')    this._openDailyModal();
          else if (key === 'gear')     this._openArtifactModal('gear');
          else if (key === 'pill')     this._openArtifactModal('pill');
          else if (key === 'pet')      this._openArtifactModal('pet');
          else if (key === 'achv')     this._openAchvModal();
        };
      });
    },

    _openCaveModal() {
      const inst = this.modal({
        title:'🏔 洞府闭关',
        body: this.renderCave(),
        actions:[{ label:'关闭', primary:true }]
      });
      const body = inst.m.querySelector('.xx-modal-body');
      const rebind = () => {
        this.bindCave(body, () => {
          body.innerHTML = this.renderCave();
          rebind();
        });
      };
      if (body) rebind();
    },

    _openSecretModal() {
      const inst = this.modal({
        title:'🌌 秘境探索',
        body: this.renderSecretRealm(),
        actions:[{ label:'关闭', primary:true }]
      });
      const body = inst.m.querySelector('.xx-modal-body');
      const rebind = () => {
        this.bindSecretRealm(body, () => {
          body.innerHTML = this.renderSecretRealm();
          rebind();
        });
      };
      if (body) rebind();
    },

    _openDailyModal() {
      const inst = this.modal({
        title:'📋 每日任务',
        body: this.renderDailyTasks(),
        actions:[{ label:'关闭', primary:true }]
      });
      const body = inst.m.querySelector('.xx-modal-body');
      const rebind = () => {
        this.bindDailyTasks(body, () => {
          body.innerHTML = this.renderDailyTasks();
          rebind();
        });
      };
      if (body) rebind();
    },

    _openArtifactModal(initialTab) {
      // 复合面板：切换 tab（法宝阁 / 装备 / 丹药 / 灵宠）
      let current = initialTab || 'artifact';
      let outer = null;
      const tabs = [
        { key:'artifact', name:'🔮 法宝阁' },
        { key:'gear',     name:'⚔ 装备'   },
        { key:'pill',     name:'💊 丹药'   },
        { key:'pet',      name:'🐉 灵宠'   },
      ];
      const renderCurrent = () => {
        if (current === 'artifact') return this.renderArtifactShop();
        if (current === 'gear')     return this.renderGear();
        if (current === 'pill')     return this.renderPills();
        if (current === 'pet')      return this.renderPets();
        return '';
      };
      const bindCurrent = (el) => {
        if (!el) return;
        if (current === 'artifact') this.bindArtifactShop(el, refreshTab);
        else if (current === 'gear') this.bindGear(el, refreshTab);
        else if (current === 'pill') this.bindPills(el, refreshTab);
        else if (current === 'pet')  this.bindPets(el, refreshTab);
      };
      const refreshTab = () => {
        const body = outer && outer.querySelector('#artifact-tab-body');
        if (!body) return;
        body.innerHTML = renderCurrent();
        bindCurrent(body);
      };
      const buildHtml = () => `
        <div class="xx-tabs" id="artifact-tabs" style="margin-bottom:12px;">
          ${tabs.map(t => `<button class="xx-tab ${t.key===current?'active':''}" data-tab="${t.key}">${t.name}</button>`).join('')}
        </div>
        <div id="artifact-tab-body"></div>
      `;
      const inst = this.modal({
        title:'🔮 法宝阁 · 综合仓储',
        body: buildHtml(),
        actions:[{ label:'关闭', primary:true }]
      });
      outer = inst.m.querySelector('.xx-modal-body');
      if (!outer) return;
      const bindTabs = () => {
        outer.querySelectorAll('#artifact-tabs .xx-tab').forEach(btn => {
          btn.onclick = () => {
            current = btn.dataset.tab;
            outer.innerHTML = buildHtml();
            bindTabs();
            refreshTab();
          };
        });
      };
      bindTabs();
      refreshTab();
    },

    // v4.0 新增：成就殿堂弹窗
    _openAchvModal() {
      const inst = this.modal({
        title:'🏆 成就殿堂',
        body: this.renderAchievements(),
        actions:[{ label:'关闭', primary:true }]
      });
    },

    // ====== 宗门地图 ======
    renderSectMap() {
      const sects = [
        { key:'physics',   icon:'⚡', name:'雷霆殿', subject:'物理', desc:'掌天地之力，操控雷霆万钧。运动、波动、电磁、热学，皆在掌中。', cls:'sect-physics'  },
        { key:'chemistry', icon:'⚗',  name:'丹鼎峰', subject:'化学', desc:'炼丹问道，元素为基。从化学反应到有机分子，洞察物质本源。',     cls:'sect-chemistry'},
        { key:'geography', icon:'🌏', name:'山河阁', subject:'地理', desc:'纵观天地，山川河流，气候洋流，区域兴衰皆入眼帘。',           cls:'sect-geography'},
        { key:'chinese',   icon:'📜', name:'文渊阁', subject:'语文', desc:'笔走龙蛇，文以载道。古诗文阅读、现代文鉴赏、议论文写作。',    cls:'sect-chinese'  },
        { key:'math',      icon:'🔢', name:'推衍宫', subject:'数学', desc:'演算天机，函数为剑，几何作盾。万物皆数，数即道也。',          cls:'sect-math'     },
        { key:'english',   icon:'🌐', name:'译灵堂', subject:'英语', desc:'通晓异界灵语，沟通天下。词汇、语法、阅读、写作。',           cls:'sect-english'  },
      ];
      let html = '<div class="sect-map">';
      sects.forEach(s => {
        const st = Game.state.sects[s.key] || { masteredManuals:[], defeatedQuests:[] };
        const mCnt = st.masteredManuals.length;
        const qCnt = st.defeatedQuests.length;
        const locked = !st.unlocked;
        const cls = `sect-card ${s.cls} ${locked ? 'locked' : ''}`;
        const href = locked ? 'javascript:void(0)' : `subjects/${s.key}.html`;
        // 用 manual 数估算总进度（如果数据已加载）
        const totalManuals = (global[`${s.key.toUpperCase()}_MANUALS`] || []).length || 0;
        const totalBank = (global[`${s.key.toUpperCase()}_BANK`] || []).length || 0;
        const totalAll = totalManuals + totalBank;
        const done = mCnt + qCnt;
        const pct = totalAll > 0 ? Math.min(100, Math.round(done / totalAll * 100)) : 0;
        html += `
          <a class="${cls}" href="${href}">
            <span class="sect-icon">${s.icon}</span>
            <div class="sect-subject">${s.subject}</div>
            <div class="sect-name">${s.name}</div>
            <div class="sect-desc">${s.desc}</div>
            <div class="sect-progress">
              功法 ${mCnt} / 妖兽 ${qCnt}
              <div class="sect-progress-bar"><div class="sect-progress-fill" style="width:${pct}%"></div></div>
            </div>
          </a>
        `;
      });
      html += '</div>';
      return html;
    },

    // ====== 心魔录视图 ======
    renderHeartDemons() {
      const list = Game.heartDemons();
      if (!list.length) {
        return `<div class="xx-empty">心境空明，无心魔缠身 🌿</div>`;
      }
      const sectName = { physics:'⚡雷霆殿', chemistry:'⚗丹鼎峰', geography:'🌏山河阁',
                         chinese:'📜文渊阁', math:'🔢推衍宫', english:'🌐译灵堂' };
      let html = '<div class="heart-demon-list">';
      list.forEach(d => {
        const bank = global[`${d.sect.toUpperCase()}_BANK`] || [];
        const q = bank.find(x => x.id === d.qid);
        const qDesc = q ? (q.q.length > 50 ? q.q.slice(0, 50) + '…' : q.q) : '(题目数据未加载)';
        html += `
          <div class="heart-demon-item" data-sect="${d.sect}" data-qid="${d.qid}">
            <span style="color:var(--xx-red);font-weight:700;">[${sectName[d.sect] || d.sect}]</span>
            ${qDesc}
            <div style="font-size:11px;color:var(--xx-text-dim);margin-top:4px;">
              失手 ${d.wrongCount} 次 · ${new Date(d.lastWrongAt).toLocaleString('zh-CN')}
              · <a href="subjects/${d.sect}.html#q=${d.qid}" style="color:var(--xx-cyan);">前往重练 →</a>
            </div>
          </div>
        `;
      });
      html += '</div>';
      return html;
    },

    // ============================================================
    //  v2.0 新增：灵根抽取
    // ============================================================
    showSpiritRootDraw(onPicked) {
      const roots = Object.values(Game.SPIRIT_ROOTS);
      let body = '<p style="color:var(--xx-text-soft);font-size:13.5px;line-height:1.7;margin-bottom:12px;">' +
        '入道之初，需测灵根。每个修士天赋不同，可影响日后修行速度。<br>' +
        '<b style="color:var(--xx-gold);">注意：灵根一经选定，不可更改！</b>请慎重抉择。</p>';
      body += '<div class="spirit-root-grid">';
      roots.forEach(r => {
        body += `
          <div class="spirit-root-card root-${r.id}" data-root="${r.id}">
            <span class="root-icon">${r.icon}</span>
            <div class="root-name">${r.name}</div>
            <div class="root-desc">${r.desc}</div>
          </div>
        `;
      });
      body += '</div>';
      body += '<div class="hint-bubble">提示：物化地选手建议优先考虑 <b>雷灵根</b>（物理大加成）、<b>火灵根</b>（化学大加成）或 <b>土灵根</b>（地理大加成）。</div>';
      const m = UI.modal({ title:'✦ 测灵根 · 入道之始', body, actions:[] });
      m.m.querySelectorAll('.spirit-root-card').forEach(card => {
        card.onclick = () => {
          const rid = card.dataset.root;
          UI.confirm(`确定选择「${Game.SPIRIT_ROOTS[rid].name}」吗？此选择不可更改。`, () => {
            Game.setSpiritRoot(rid);
            UI.toast(`你选择了「${Game.SPIRIT_ROOTS[rid].name}」，修行之路就此启程！`, 'success');
            m.close();
            if (onPicked) onPicked(rid);
          });
        };
      });
      return m;
    },

    // ============================================================
    //  v2.0 新增：法宝阁
    // ============================================================
    renderArtifactShop() {
      if (Game._ensureAllFields) Game._ensureAllFields();
      const arts = Game.ARTIFACTS || {};
      const owned = Game.state.char.artifacts || [];
      const equipped = Game.state.char.equippedArtifacts || [];
      let html = '<div class="xx-tip">🎒 法宝阁 · 每件法宝可永久增益。最多同时装备 3 件。</div>';
      html += '<div class="artifact-grid">';
      Object.keys(arts).forEach(aid => {
        const a = arts[aid];
        const has = owned.includes(aid);
        const eq  = equipped.includes(aid);
        const cls = `artifact-card ${has?'owned':''} ${eq?'equipped':''}`;
        let action = '';
        if (!has) {
          action = `<button class="iv-btn" data-buy="${aid}">💎 炼制 ${a.cost}</button>`;
        } else if (!eq) {
          action = `<button class="iv-btn ghost" data-equip="${aid}">⚔ 装备</button>`;
        } else {
          action = `<button class="iv-btn ghost" data-unequip="${aid}">⬇ 卸下</button>`;
        }
        html += `
          <div class="${cls}">
            <span class="artifact-icon">${a.icon}</span>
            <div class="artifact-name">${a.name}</div>
            <div class="artifact-desc">${a.desc}</div>
            <div class="artifact-cost">${has?'已拥有':`售价 ${a.cost} 灵石`}</div>
            <div class="artifact-actions">${action}</div>
          </div>
        `;
      });
      html += '</div>';
      return html;
    },
    bindArtifactShop(container, onChange) {
      container.querySelectorAll('[data-buy]').forEach(b => {
        b.onclick = () => {
          const r = Game.buyArtifact(b.dataset.buy);
          UI.toast(r.msg, r.ok?'success':'error');
          if (r.ok && onChange) onChange();
        };
      });
      container.querySelectorAll('[data-equip]').forEach(b => {
        b.onclick = () => {
          if (Game.equipArtifact(b.dataset.equip)) {
            UI.toast('已装备', 'success');
            if (onChange) onChange();
          }
        };
      });
      container.querySelectorAll('[data-unequip]').forEach(b => {
        b.onclick = () => {
          Game.unequipArtifact(b.dataset.unequip);
          UI.toast('已卸下', 'info');
          if (onChange) onChange();
        };
      });
    },

    // ============================================================
    //  v2.0 新增：洞府
    // ============================================================
    renderCave() {
      if (Game._ensureAllFields) Game._ensureAllFields();
      const cave = Game.state.cave;
      const canM = Game.canMeditate();
      const cdMin = canM ? 0 : Math.ceil((30*60*1000 - (Date.now() - cave.lastMeditateAt))/60000);
      let html = `
        <div class="cave-stage">
          <div class="cave-bg-stars"></div>
          <div class="cave-avatar">${Game.state.char.avatar||'🧘'}</div>
          <div class="cave-info">
            <div class="cave-title">${cave.level >= 5?'飞升宝殿':(cave.level >= 3?'灵气洞府':'修士石洞')}</div>
            <div class="cave-level-tag">洞府等级 Lv.${cave.level}</div>
            <div style="margin-top:14px;color:var(--xx-text-soft);font-size:13px;">
              此处灵气浓郁，可助你恢复道心、参悟天地。
            </div>
          </div>
        </div>
        <div class="iv-controls" style="justify-content:center;margin-top:14px;">
          <button class="iv-btn" id="cave-meditate" ${canM?'':'disabled'}>
            🧘 ${canM?`打坐冥想（道心+30, 修为+${10*cave.level}）`:`冷却中（${cdMin} 分钟）`}
          </button>
          <button class="iv-btn ghost" id="cave-upgrade">
            ⏫ 升级洞府（${cave.level*500} 灵石）
          </button>
        </div>
      `;
      return html;
    },
    bindCave(container, onChange) {
      const btnM = container.querySelector('#cave-meditate');
      const btnU = container.querySelector('#cave-upgrade');
      if (btnM) btnM.onclick = () => {
        const r = Game.meditate();
        UI.toast(r.msg, r.ok?'success':'error');
        if (r.ok && onChange) onChange();
      };
      if (btnU) btnU.onclick = () => {
        UI.confirm(`花费 ${Game.state.cave.level*500} 灵石升级洞府？升级后打坐效果增强。`, () => {
          const r = Game.upgradeCave();
          UI.toast(r.msg, r.ok?'success':'error');
          if (r.ok && onChange) onChange();
        });
      };
    },

    // ============================================================
    //  v2.0 新增：秘境
    // ============================================================
    renderSecretRealm() {
      if (Game._ensureAllFields) Game._ensureAllFields();
      const sr = Game.state.secretRealm;
      const canE = Game.canEnterSecret();
      const cdMin = canE ? 0 : Math.ceil((60*60*1000 - (Date.now() - sr.lastEnterAt))/60000);
      let html = `
        <div class="secret-realm-stage">
          <div style="text-align:center;padding:30px 10px;">
            <div style="font-size:48px;">🗺</div>
            <div style="font-family:var(--xx-font-art);font-size:20px;color:var(--xx-purple);letter-spacing:4px;margin-top:10px;">秘境探索</div>
            <div style="font-size:13px;color:var(--xx-text-soft);margin-top:6px;line-height:1.7;">
              传闻有上古遗迹蕴藏天材地宝、奇异机缘。<br>每一小时可探索一次。
            </div>
            <button class="iv-btn" id="sr-enter" ${canE?'':'disabled'} style="margin-top:16px;">
              ${canE?'🚪 进入秘境':`冷却中（${cdMin} 分钟）`}
            </button>
          </div>
        </div>
      `;
      if (sr.events && sr.events.length) {
        html += '<div class="xx-section-title" style="margin-top:18px;font-size:15px;">📜 历次奇遇</div>';
        sr.events.slice(0,8).forEach(e => {
          html += `<div class="secret-history-item"><b style="color:var(--xx-purple);">${e.msg}</b> <span style="color:var(--xx-green);">${e.detail||''}</span></div>`;
        });
      }
      return html;
    },
    bindSecretRealm(container, onChange) {
      const btn = container.querySelector('#sr-enter');
      if (btn) btn.onclick = () => {
        const r = Game.enterSecret();
        if (!r.ok) { UI.toast(r.msg, 'error'); return; }
        // 弹窗显示奇遇
        UI.modal({
          title: '✦ 秘境奇遇',
          body: `
            <div class="secret-event-card">
              <div class="secret-event-msg">${r.event.msg}</div>
              <div class="secret-event-detail">${r.detail}</div>
            </div>
          `,
          actions: [{ label:'继续修行', primary:true }]
        });
        if (onChange) onChange();
      };
    },

    // ============================================================
    //  v2.0 新增：每日任务
    // ============================================================
    renderDailyTasks() {
      // 若今日任务还未生成，主动调一次
      if (Game._ensureAllFields) Game._ensureAllFields();
      if (Game._refreshDaily) Game._refreshDaily();
      const tasks = (Game.state.daily && Game.state.daily.tasks) || [];
      if (!tasks.length) return '<div class="xx-empty">每日任务加载中…</div>';
      let html = '<div class="xx-tip">📅 每日任务 · 子夜 0:00 刷新。完成后可领取丰厚奖励。</div>';
      tasks.forEach(t => {
        const pct = Math.min(100, Math.round(t.progress/t.target*100));
        const done = t.progress >= t.target;
        html += `
          <div class="daily-task ${done?'done':''} ${t.claimed?'claimed':''}">
            <div class="task-info">
              <div class="task-desc">${t.desc}</div>
              <div class="task-progress-bar">
                <div class="task-progress-fill" style="width:${pct}%"></div>
              </div>
              <div class="task-reward">进度 ${t.progress}/${t.target} · 奖励：+${t.reward.exp}修为 +${t.reward.shi}灵石</div>
            </div>
            ${ t.claimed ? '<span style="color:var(--xx-text-dim);font-size:12px;">✓ 已领取</span>'
               : (done ? `<button class="iv-btn" data-claim="${t.id}">🎁 领取</button>`
                  : '<span style="color:var(--xx-text-dim);font-size:12px;">进行中</span>') }
          </div>
        `;
      });
      return html;
    },
    bindDailyTasks(container, onChange) {
      container.querySelectorAll('[data-claim]').forEach(b => {
        b.onclick = () => {
          const r = Game.claimDaily(b.dataset.claim);
          UI.toast(r.msg, r.ok?'success':'error');
          if (r.ok && onChange) onChange();
        };
      });
    },

    // ============================================================
    //  v2.0 新增：答题特效（暴击爆发/正误反馈）
    // ============================================================
    showCombo(text) {
      const el = document.createElement('div');
      el.className = 'combo-burst';
      el.textContent = text;
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 1200);
    },
    showAnswerFx(correct) {
      const el = document.createElement('div');
      el.className = 'answer-fx';
      el.textContent = correct ? '⚔' : '💔';
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 900);
    },

    // ============================================================
    //  v2.0 新增：灵气粒子背景
    // ============================================================
    initQiParticles() {
      if (document.querySelector('.qi-particles')) return;
      const wrap = document.createElement('div');
      wrap.className = 'qi-particles';
      for (let i=0; i<10; i++) {
        const p = document.createElement('div');
        p.className = 'qi-particle';
        p.style.left = (Math.random()*100) + '%';
        p.style.animationDelay = (Math.random()*8) + 's';
        p.style.animationDuration = (6 + Math.random()*4) + 's';
        if (Math.random() > 0.6) p.style.background = 'var(--xx-purple)';
        wrap.appendChild(p);
      }
      document.body.appendChild(wrap);
    },

    // ================================================
    //  🗺 v3 新增：世界大地图
    // ================================================
    renderWorldMap() {
      if (Game._ensureAllFields) Game._ensureAllFields();
      const wm = Game.state.worldMap;
      // 8 个节点位置（800×480 SVG 坐标）
      const NODES = [
        { id:'start',     name:'问道山门', sub:'缘起之地',       x:400, y:70,  emoji:'⛩', href:null },
        { id:'physics',   name:'雷震殿',   sub:'物理 / 18 篇功法', x:150, y:170, emoji:'⚡', href:'subjects/physics.html' },
        { id:'chemistry', name:'丹鼎峰',   sub:'化学 / 11 篇功法', x:650, y:170, emoji:'⚗',  href:'subjects/chemistry.html' },
        { id:'geography', name:'山河阁',   sub:'地理 / 11 篇功法', x:70,  y:320, emoji:'🌏', href:'subjects/geography.html' },
        { id:'chinese',   name:'文渊阁',   sub:'语文 / 9 篇功法',  x:280, y:340, emoji:'📜', href:'subjects/chinese.html' },
        { id:'math',      name:'推衍宫',   sub:'数学 / 9 篇功法',  x:520, y:340, emoji:'🔢', href:'subjects/math.html' },
        { id:'english',   name:'译灵堂',   sub:'英语 / 7 篇功法',  x:730, y:320, emoji:'🌐', href:'subjects/english.html' },
        { id:'tower',     name:'飞升宝塔', sub:'高考 / 终极塔',      x:400, y:430, emoji:'🗼', href:'#tower' },
      ];
      const paths = [
        ['start','physics'], ['start','chemistry'],
        ['physics','geography'], ['physics','chinese'],
        ['chemistry','math'], ['chemistry','english'],
        ['geography','chinese'], ['chinese','math'], ['math','english'],
        ['geography','tower'], ['english','tower'], ['chinese','tower'], ['math','tower']
      ];
      const nMap = {};
      NODES.forEach(n => nMap[n.id] = n);
      const nodeById = id => nMap[id];

      let svg = `<svg class="world-map-svg" viewBox="0 0 800 480" preserveAspectRatio="xMidYMid meet">`;
      // 背景远山 (装饰)
      svg += `<defs>
        <radialGradient id="wm-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="rgba(178,136,255,0.35)"/><stop offset="100%" stop-color="transparent"/>
        </radialGradient>
        <linearGradient id="wm-cloud" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="rgba(178,136,255,0.20)"/><stop offset="100%" stop-color="transparent"/>
        </linearGradient>
      </defs>`;
      // 云雾 (多层)
      svg += `<ellipse cx="200" cy="460" rx="260" ry="40" fill="url(#wm-cloud)" class="cloud"/>`;
      svg += `<ellipse cx="600" cy="470" rx="260" ry="35" fill="url(#wm-cloud)" class="cloud"/>`;
      // 远山（三角）
      svg += `<polygon class="mountain" points="0,470 100,300 200,400 260,340 340,460" fill="rgba(30,25,60,0.6)"/>`;
      svg += `<polygon class="mountain" points="460,470 540,340 620,400 720,300 800,470" fill="rgba(30,25,60,0.6)"/>`;
      // 星星
      for (let i = 0; i < 20; i++) {
        const x = Math.random()*800; const y = Math.random()*280;
        svg += `<circle cx="${x}" cy="${y}" r="${Math.random()*1.5+0.5}" fill="#fff" opacity="${0.3+Math.random()*0.5}"/>`;
      }
      // 路径
      paths.forEach(([a,b]) => {
        const A = nodeById(a), B = nodeById(b);
        if (!A || !B) return;
        // 绘制一条弧线
        const mx = (A.x+B.x)/2, my = (A.y+B.y)/2 - 20;
        svg += `<path class="path-line" d="M ${A.x} ${A.y} Q ${mx} ${my} ${B.x} ${B.y}"/>`;
      });
      // 节点
      NODES.forEach(n => {
        const unlocked = wm.unlocked[n.id] !== false;
        const cls = 'location' + (unlocked ? '' : ' locked');
        const href = unlocked ? (n.href||'') : '';
        svg += `<g class="${cls}" data-node="${n.id}" data-href="${href}">`;
        // 光晕
        if (unlocked) svg += `<circle cx="${n.x}" cy="${n.y}" r="38" fill="url(#wm-glow)"/>`;
        svg += `<circle class="loc-ring" cx="${n.x}" cy="${n.y}" r="28"/>`;
        // emoji
        svg += `<text class="loc-emoji" x="${n.x}" y="${n.y+11}" text-anchor="middle">${n.emoji}</text>`;
        // 标题
        svg += `<text class="loc-label" x="${n.x}" y="${n.y+50}">${n.name}</text>`;
        svg += `<text class="loc-sub" x="${n.x}" y="${n.y+66}">${n.sub}</text>`;
        svg += `</g>`;
      });
      svg += `</svg>`;
      return `<div class="world-map-wrap">${svg}
        <div class="world-map-legend">
          <span class="legend-item"><span class="lgd-dot"></span>已解锁</span>
          <span class="legend-item"><span class="lgd-dot locked"></span>未解锁</span>
          <span style="margin-left:auto;color:var(--xx-text-dim);">💡 点击任一宗门进入</span>
        </div>
      </div>`;
    },

    bindWorldMap(container) {
      container.querySelectorAll('.location').forEach(g => {
        if (g.classList.contains('locked')) {
          g.onclick = () => UI.toast('此地尚未解锁', 'error');
          return;
        }
        g.onclick = () => {
          const href = g.dataset.href;
          const node = g.dataset.node;
          Game.visitNode(node);
          if (href && href !== '#tower') { window.location.href = href; return; }
          if (href === '#tower') { UI.toast('飞升宝塔 — 请先突破金丹期后解锁', 'info'); return; }
          if (node === 'start') { UI.toast('你回到了问道山门', 'info'); }
        };
      });
    },

    // ================================================
    //  🏆 v3 成就殿堂
    // ================================================
    renderAchievements() {
      if (!Game.ACHIEVEMENTS) return '<div class="xx-empty">成就系统未启用</div>';
      Game._checkAchievements();
      const s = Game.state;
      const total = Object.keys(Game.ACHIEVEMENTS).length;
      const done = Object.values(s.achievements||{}).filter(x=>x.done).length;
      let html = `<div class="xx-tip">🏆 成就殿堂 · <b style="color:var(--xx-gold);">${done} / ${total}</b> 已解锁</div>`;
      html += '<div class="achv-grid">';
      Object.keys(Game.ACHIEVEMENTS).forEach(aid => {
        const a = Game.ACHIEVEMENTS[aid];
        const rec = (s.achievements||{})[aid] || { progress:0, done:false };
        const pct = Math.min(100, Math.round(rec.progress / (a.target||1) * 100));
        html += `
          <div class="achv-card ${rec.done?'done':'locked'}">
            <div class="achv-icon">${a.icon}</div>
            <div class="achv-name">${a.name}</div>
            <div class="achv-desc">${a.desc}</div>
            <div class="achv-progress"><div class="achv-progress-fill" style="width:${pct}%"></div></div>
            <div class="achv-progress-text">${rec.progress}/${a.target||1}${rec.done?' · ✅':''}</div>
          </div>
        `;
      });
      html += '</div>';
      return html;
    },

    // ================================================
    //  ⚔ v3 装备面板
    // ================================================
    renderGear() {
      if (Game._ensureAllFields) Game._ensureAllFields();
      const c = Game.state.char;
      const gears = Game.GEAR_DATA || {};
      const owned = c.gear || {};
      // 先列已装备四槽
      const slots = [
        { key:'weapon', name:'武器', icon:'🗡' },
        { key:'robe',   name:'衣袍', icon:'👘' },
        { key:'focus',  name:'法器', icon:'📖' },
        { key:'crown',  name:'头冠', icon:'👑' },
      ];
      let html = `<div class="xx-tip">⚔ 装备共 4 部位：武器 / 衣袍 / 法器 / 头冠。装备后得相应属性。</div>`;
      html += '<div class="equip-slots">';
      slots.forEach(sl => {
        const gid = c.equippedGear[sl.key];
        const g = gid && gears[gid];
        if (g) {
          html += `
            <div class="equip-slot equipped rarity-${g.rarity}" data-slot="${sl.key}" title="${g.desc}">
              <div class="slot-icon">${g.emoji}</div>
              <div class="slot-name" style="color:var(--xx-gold);">${g.name}</div>
            </div>`;
        } else {
          html += `
            <div class="equip-slot" data-slot="${sl.key}">
              <div class="slot-icon">${sl.icon}</div>
              <div class="slot-name">${sl.name}</div>
            </div>`;
        }
      });
      html += '</div>';
      // 背包（拥有的装备）
      html += '<div style="margin-top:14px;font-family:var(--xx-font-art);font-size:15px;color:var(--xx-gold);letter-spacing:3px;">🎒 背包·装备</div>';
      html += '<div class="inv-grid" style="margin-top:8px;">';
      let hasAny = false;
      Object.keys(gears).forEach(gid => {
        if (!owned[gid]) return;
        hasAny = true;
        const g = gears[gid];
        const equipped = Object.values(c.equippedGear).includes(gid);
        const buffText = Object.entries(g.buff || {}).map(([k,v])=>{
          const map = { atk:'攻击', def:'防御', maxHp:'气血', maxMp:'灵力', crit:'暴击' };
          const val = k==='crit' ? `${Math.round(v*100)}%` : `+${v}`;
          return `${map[k]||k}${val}`;
        }).join(' · ');
        html += `
          <div class="inv-item rarity-${g.rarity}" data-gear="${gid}" title="${g.desc}">
            <div class="inv-icon">${g.emoji}</div>
            <div class="inv-name">${g.name}</div>
            <div class="inv-tag">${buffText}</div>
            <button class="iv-btn" style="margin-top:6px;" data-eq-btn="${gid}">${equipped?'卸下':'装备'}</button>
          </div>`;
      });
      if (!hasAny) html += '<div class="xx-empty" style="grid-column:1/-1;">背包空空如也。<br>去秘境探索、或担当宗门讨伐得到装备。</div>';
      html += '</div>';
      return html;
    },

    bindGear(container, onChange) {
      const gears = Game.GEAR_DATA || {};
      container.querySelectorAll('[data-eq-btn]').forEach(b => {
        b.onclick = (e) => {
          e.stopPropagation();
          const gid = b.dataset.eqBtn;
          const g = gears[gid]; if (!g) return;
          const c = Game.state.char;
          const equipped = c.equippedGear[g.slot] === gid;
          if (equipped) {
            Game.unequipGear(g.slot);
            UI.toast('已卸下', 'info');
          } else {
            const r = Game.equipGear(gid);
            UI.toast(r.msg, r.ok?'success':'error');
          }
          if (onChange) onChange();
        };
      });
    },

    // ================================================
    //  🐉 v3 宠物面板
    // ================================================
    renderPets() {
      if (Game._ensureAllFields) Game._ensureAllFields();
      const c = Game.state.char;
      const pets = Game.PET_DATA || {};
      let html = '<div class="xx-tip">🐉 灵宠伴你修行，获取方式见各宠描述。同一时间只能携带一只。</div>';
      if (c.pet) {
        const p = c.pet;
        const nextExp = p.level * 100;
        const pct = Math.round(p.exp/nextExp * 100);
        html += `
          <div class="pet-card">
            <div class="pet-avatar">${p.emoji}</div>
            <div class="pet-info">
              <div class="pet-name">${p.name}</div>
              <div class="pet-lv">Lv.${p.level} · ${p.exp}/${nextExp} EXP</div>
              <div class="pet-stats">
                <span class="pet-stat">⚔ <b>${p.atk}</b></span>
                <span class="pet-stat">❤ <b>${p.hp}</b></span>
              </div>
              <div class="cult-bar" style="height:6px;margin-top:6px;"><div class="cult-bar-fill" style="width:${pct}%"></div></div>
              <button class="iv-btn ghost" style="margin-top:6px;" data-pet-dismiss="1">👋 送走</button>
            </div>
          </div>`;
      }
      html += '<div style="margin-top:14px;font-family:var(--xx-font-art);color:var(--xx-gold);letter-spacing:3px;">🌟 可拜入门下</div>';
      html += '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px;margin-top:8px;">';
      Object.keys(pets).forEach(pid => {
        const p = pets[pid];
        const owned = c.pet && c.pet.id === pid;
        html += `
          <div class="pet-card" style="opacity:${owned?0.55:1};">
            <div class="pet-avatar">${p.emoji}</div>
            <div class="pet-info">
              <div class="pet-name">${p.name}</div>
              <div class="pet-lv">${p.rarity==='legend'?'✨传奇':(p.rarity==='epic'?'💎史诗':'频维稀有')}</div>
              <div style="font-size:11px;color:var(--xx-text-soft);line-height:1.6;margin-top:4px;">${p.desc}</div>
              <div style="font-size:10.5px;color:var(--xx-cyan);margin-top:4px;">解锁：${p.unlock}</div>
              <button class="iv-btn" style="margin-top:6px;" data-pet-adopt="${pid}" ${owned?'disabled':''}>${owned?'已拥有':'🤍 拜入门下'}</button>
            </div>
          </div>`;
      });
      html += '</div>';
      return html;
    },

    bindPets(container, onChange) {
      container.querySelectorAll('[data-pet-adopt]').forEach(b => {
        b.onclick = () => {
          const r = Game.adoptPet(b.dataset.petAdopt);
          UI.toast(r.msg, r.ok?'success':'error');
          if (r.ok && onChange) onChange();
        };
      });
      const dis = container.querySelector('[data-pet-dismiss]');
      if (dis) dis.onclick = () => {
        UI.confirm('确定送走当前灵宠？不可恢复。', () => {
          Game.dismissPet();
          UI.toast('宠物已送走', 'info');
          if (onChange) onChange();
        });
      };
    },

    // ================================================
    //  💊 v3 丹药房
    // ================================================
    renderPills() {
      if (Game._ensureAllFields) Game._ensureAllFields();
      const c = Game.state.char;
      const pills = Game.PILL_DATA || {};
      let html = '<div class="xx-tip">💊 丹药可恢复 HP / MP / 道心，或直接增长修为。可在秘境/每日任务/名山大川得到。</div>';
      html += '<div class="inv-grid">';
      let any = false;
      Object.keys(pills).forEach(pid => {
        const p = pills[pid];
        const n = c.pills[pid] || 0;
        if (n <= 0) return;
        any = true;
        const effect = [];
        if (p.hp) effect.push(`HP+${p.hp}`);
        if (p.mp) effect.push(`MP+${p.mp}`);
        if (p.daoxin) effect.push(`道心+${p.daoxin}`);
        if (p.exp) effect.push(`修为+${p.exp}`);
        html += `
          <div class="inv-item rarity-${p.rarity}">
            <div class="inv-count">×${n}</div>
            <div class="inv-icon">${p.emoji}</div>
            <div class="inv-name">${p.name}</div>
            <div class="inv-tag">${effect.join(' · ')}</div>
            <button class="iv-btn" style="margin-top:6px;" data-use-pill="${pid}">服用</button>
          </div>`;
      });
      if (!any) html += '<div class="xx-empty" style="grid-column:1/-1;">丹室空空。<br>去秘境探索、或完成每日任务获取丹药。</div>';
      html += '</div>';
      return html;
    },

    bindPills(container, onChange) {
      container.querySelectorAll('[data-use-pill]').forEach(b => {
        b.onclick = () => {
          const r = Game.usePill(b.dataset.usePill);
          UI.toast(r.msg, r.ok?'success':'error');
          if (r.ok && onChange) onChange();
        };
      });
    },

    // ================================================
    //  ⚔ v3 战斗场景
    // ================================================
    //  ⚔ v4.0 · 二次元修仙 · 沉浸式斩妖场
    //  用法：UI.openBattle({ enemy:{name,pixel,hp,atk,diff,sect}, getQuestion, onWin, onLose, onClose })
    //  改进点：
    //   1) 使用 PixelArt 像素妖兽替代 emoji（更沉浸）
    //   2) 每道题上方自动挂 AutoViz 可视化图（辅助理解）
    //   3) 战斗日志历史（最新5条），非单行覆盖
    //   4) Boss 战自动震屏 + 血红光晕 + 危险符文
    //   5) 修复：技能选择状态、连续答题时的题目切换、mask 泄露
    //   6) 答题正确触发学科专属特效粒子（雷/火/丹/风）
    // ================================================
    openBattle(opts) {
      opts = opts || {};
      // v4.0 FIX: 兼容旧接口（Immersive-learning 使用的参数）
      //   旧 API: { question, sect, monsterName, difficulty, onDone }
      //   新 API: { enemy:{name,hp,atk,diff,sect}, getQuestion, onWin, onLose, onClose }
      if (opts.question && !opts.enemy) {
        const q = opts.question;
        const sect = opts.sect || 'physics';
        const diff = opts.difficulty || q.difficulty || 'normal';
        // 单题小怪：HP 一招斩（避免重复同题）
        const singleHp = 5;
        opts.enemy = { name: opts.monsterName || '妖兽', hp: singleHp, maxHp: singleHp, atk: { easy:8, normal:12, hard:18, boss:26 }[diff] || 12, diff, sect };
        let served = false;
        opts.getQuestion = () => { if (served) return null; served = true; return q; };
        let answered = false;
        const done = opts.onDone;
        opts._trialSingle = true;
        opts.onWin  = () => { if (!answered && done) { answered = true; done(true);  } };
        opts.onLose = () => { if (!answered && done) { answered = true; done(false); } };
        opts.onClose = (ok) => { if (!answered && done) { answered = true; done(!!ok); } };
      }
      const enemy = Object.assign({
        name: '妖兽', emoji: '👿', hp: 100, maxHp: 100, atk: 12,
        diff: 'normal', sect: 'physics'
      }, opts.enemy || {});
      enemy.maxHp = enemy.maxHp || enemy.hp;
      const c = Game.state.char;
      const isBoss = enemy.diff === 'boss';
      const isHard = enemy.diff === 'hard';

      // 妖兽像素立绘（优先）
      let enemyVisual = '';
      if (typeof PixelArt !== 'undefined' && PixelArt.monster) {
        try {
          enemyVisual = PixelArt.monster(enemy.diff, enemy.sect);
        } catch (e) { /* fallback below */ }
      }
      if (!enemyVisual) {
        enemyVisual = `<div style="font-size:82px;filter:drop-shadow(0 0 20px ${isBoss?'#e25b5b':'#b288ff'});">${enemy.emoji}</div>`;
      }

      // 学科主色
      const sectColor = {
        physics:'#7fb3ff', chemistry:'#ff9a5e', geography:'#8ce28c',
        chinese:'#f5c97a', math:'#b288ff', english:'#ff9ec6'
      };
      const clr = sectColor[enemy.sect] || '#f5c97a';

      // 场景外框
      const mask = document.createElement('div');
      mask.className = 'xx-modal-mask v43-battle-mask';
      const scene = document.createElement('div');
      scene.className = 'xx-modal v43-battle-modal ' + (isBoss?'is-boss':(isHard?'is-hard':'is-normal'));
      scene.style.maxWidth = '820px';
      scene.style.padding = '0';
      scene.innerHTML = `
        <button class="xx-modal-close">×</button>
        <div class="battle-scene v43-scene ${isBoss?'boss-scene':''}">
          <div class="v43-battle-bg">
            <div class="v43-bg-clouds"></div>
            <div class="v43-bg-mountain" style="border-color:${clr};"></div>
          </div>
          <div class="v43-battle-header">
            <div class="v43-battle-title" style="color:${clr};">
              ${isBoss?'💀 ':(isHard?'⚡ ':'⚔ ')}${enemy.name}
              <span style="font-size:12px;color:var(--xx-text-dim);margin-left:8px;">
                ${isBoss?'· 妖王':isHard?'· 精英':'· 妖兽'} · ${enemy.sect}宗
              </span>
            </div>
          </div>
          <div class="battle-stage v43-stage">
            <div class="battle-hero v43-hero">
              <div class="v43-hero-portrait hero-portrait">${c.avatar||'🧙'}</div>
              <div class="battle-name">${c.name} <span style="color:var(--xx-cyan);font-size:11px;">${Game.getRealmName ? Game.getRealmName() : ''}</span></div>
              <div class="battle-hp-wrap">
                <div class="battle-hp"><div class="battle-hp-fill hero-hp" style="width:${c.hp/c.maxHp*100}%"></div></div>
                <div class="battle-mp"><div class="battle-mp-fill hero-mp" style="width:${c.mp/c.maxMp*100}%"></div></div>
                <div class="battle-hp-label">
                  <span class="hero-hp-txt">❤ ${c.hp}/${c.maxHp}</span>
                  <span class="hero-mp-txt">💧 MP ${c.mp}/${c.maxMp}</span>
                </div>
              </div>
            </div>
            <div class="v43-vs-mark">VS</div>
            <div class="battle-enemy v43-enemy tier-${enemy.tier || (isBoss?'boss':isHard?'elite':'normal')}">
              <div class="v43-enemy-portrait enemy-portrait">${enemyVisual}</div>
              <div class="battle-name" style="color:${isBoss?'#e25b5b':clr};">${enemy.name}</div>
              ${(enemy.titles && enemy.titles.length) ? `<div class="v43-enemy-titles">${enemy.titles.map(t => `<span class=\"v43-enemy-title ${t.cls}\">${t.text}</span>`).join('')}</div>` : ''}
              <div class="battle-hp-wrap">
                <div class="battle-hp"><div class="battle-hp-fill enemy-hp ${isBoss?'boss-hp':''}" style="width:100%"></div></div>
                <div class="battle-hp-label">
                  <span class="enemy-hp-txt">❤ ${enemy.hp}/${enemy.maxHp}</span>
                  <span>⚔ ATK ${enemy.atk}</span>
                </div>
              </div>
            </div>
          </div>
          <div class="battle-control v43-control">
            <div class="skill-bar v43-skill-bar">
              <span class="skill-btn v43-skill active" data-skill="basic">⚔ 平取<br><span class="skill-cost">免费·1×</span></span>
              <span class="skill-btn v43-skill" data-skill="lightning">⚡ 天雷诀<br><span class="skill-cost">20MP·2×</span></span>
              <span class="skill-btn v43-skill" data-skill="fireball">🔥 火球术<br><span class="skill-cost">15MP·1.5×</span></span>
              <span class="skill-btn v43-skill heal-btn" data-skill="heal">💚 小循环<br><span class="skill-cost">10MP·+30HP</span></span>
            </div>
            <div class="v43-battle-log battle-log"></div>
            <div class="v43-viz-wrap"></div>
            <div class="battle-question-wrap v43-question-wrap"></div>
          </div>
        </div>
      `;
      mask.appendChild(scene);
      document.body.appendChild(mask);

      let selectedSkill = 'basic';
      let currentQuestion = null;
      const logHistory = [];

      const heroEl     = scene.querySelector('.hero-portrait');
      const enemyEl    = scene.querySelector('.enemy-portrait');
      const heroHpFill = scene.querySelector('.hero-hp');
      const heroMpFill = scene.querySelector('.hero-mp');
      const heroHpTxt  = scene.querySelector('.hero-hp-txt');
      const heroMpTxt  = scene.querySelector('.hero-mp-txt');
      const enemyHpFill= scene.querySelector('.enemy-hp');
      const enemyHpTxt = scene.querySelector('.enemy-hp-txt');
      const logEl      = scene.querySelector('.v43-battle-log');
      const vizWrap    = scene.querySelector('.v43-viz-wrap');
      const qWrap      = scene.querySelector('.battle-question-wrap');
      const closeBtn   = scene.querySelector('.xx-modal-close');

      function pushLog(msg, cls) {
        logHistory.unshift(`<div class="v43-log-line ${cls||''}">${msg}</div>`);
        if (logHistory.length > 4) logHistory.length = 4;
        logEl.innerHTML = logHistory.join('');
      }
      function updHero() {
        heroHpFill.style.width = (c.hp/c.maxHp*100)+'%';
        heroMpFill.style.width = (c.mp/c.maxMp*100)+'%';
        heroHpTxt.textContent  = `❤ ${c.hp}/${c.maxHp}`;
        heroMpTxt.textContent  = `💧 MP ${c.mp}/${c.maxMp}`;
      }
      function updEnemy() {
        enemyHpFill.style.width = (enemy.hp/enemy.maxHp*100)+'%';
        enemyHpTxt.textContent  = `❤ ${enemy.hp}/${enemy.maxHp}`;
      }
      function floatText(target, text, cls) {
        const t = document.createElement('div');
        t.className = 'dmg-float v43-float ' + (cls||'dmg');
        t.textContent = text;
        const rect = target.getBoundingClientRect();
        const parent = scene.querySelector('.battle-scene');
        const parentRect = parent.getBoundingClientRect();
        t.style.left = (rect.left - parentRect.left + rect.width/2) + 'px';
        t.style.top  = (rect.top  - parentRect.top - 20) + 'px';
        parent.appendChild(t);
        setTimeout(()=>t.remove(), 1400);
      }
      // 学科专属特效
      const SPELL_ICON = {
        fireball:'🔥', lightning:'⚡', ice:'❄️',
        physics:'⚡', chemistry:'⚗', geography:'🌪',
        chinese:'📜', math:'🔢', english:'🌐'
      };
      function spellFx(kind) {
        const wrap = scene.querySelector('.battle-scene');
        // 主特效
        const el = document.createElement('div');
        el.className = 'spell-fx v43-spell-fx ' + kind;
        el.style.fontSize = '68px';
        el.style.color = kind==='fireball'?'#f39c56':kind==='lightning'?'#f5c97a':kind==='ice'?'#6ed5e0':'#fff';
        el.style.textShadow = '0 0 20px currentColor';
        el.textContent = SPELL_ICON[kind] || '✨';
        wrap.appendChild(el);
        setTimeout(()=>el.remove(), 900);
        // 粒子伴生
        for (let i=0;i<8;i++) {
          const p = document.createElement('div');
          p.className = 'v43-particle';
          p.style.color = el.style.color;
          p.style.fontSize = (6 + Math.random()*8) + 'px';
          p.textContent = '✦';
          wrap.appendChild(p);
          const angle = Math.random()*Math.PI*2;
          const dist = 60 + Math.random()*100;
          p.animate([
            { transform:'translate(0,0)', opacity:1 },
            { transform:`translate(${Math.cos(angle)*dist}px,${Math.sin(angle)*dist}px)`, opacity:0 }
          ], { duration: 800+Math.random()*400, easing:'ease-out' });
          setTimeout(()=>p.remove(), 1400);
        }
      }

      // 绑定技能栏
      scene.querySelectorAll('.v43-skill').forEach(b => {
        b.onclick = () => {
          const skill = b.dataset.skill;
          if (skill === 'heal') {
            if (c.mp < 10) { UI.toast('灵力不足', 'error'); return; }
            c.mp -= 10; c.hp = Math.min(c.maxHp, c.hp + 30); Game.save();
            updHero();
            floatText(heroEl, '+30 HP', 'heal');
            pushLog('💚 施展小循环 · HP +30', 'heal');
            // heal 是即时技，不改变 selectedSkill
            return;
          }
          scene.querySelectorAll('.v43-skill').forEach(x=>x.classList.remove('active'));
          b.classList.add('active');
          selectedSkill = skill;
          const names = { basic:'⚔ 已选：平取（免费）', lightning:'⚡ 已选：天雷诀（20MP·2倍伤害）', fireball:'🔥 已选：火球术（15MP·1.5倍伤害）' };
          pushLog(names[skill] || '', 'info');
        };
      });

      function loadQuestion() {
        const q = opts.getQuestion ? opts.getQuestion() : opts.question;
        if (!q) {
          // v4.0 FIX: 单题试炼模式下没有下一道题 = 已结束（胜/负已在 finishBattle 中回调）
          // 多题模式下：题库耗尽依旧逻辑判胜
          if (opts._trialSingle) { return; }
          finishBattle(true);
          return;
        }
        currentQuestion = q;
        // 挂 AutoViz 可视化（若可用）
        if (typeof AutoViz !== 'undefined' && AutoViz.render) {
          try {
            vizWrap.innerHTML = AutoViz.render(q);
          } catch(e) { vizWrap.innerHTML = ''; }
        } else {
          vizWrap.innerHTML = '';
        }
        renderQuestion(q);
      }
      // v4.1-fix：多题型 + 双格式选项兼容
      function _normOpts(q) {
        // 输出统一: [{k:'A', v:'xxx'}]
        const raw = q.options || [];
        // 判断题：无 options 时自动生成
        if (q.type === 'judge' && !raw.length) {
          return [{k:'A', v:'○ 正确'}, {k:'B', v:'✕ 错误'}];
        }
        return raw.map((o, i) => {
          if (typeof o === 'object' && o && 'k' in o) return { k:String(o.k), v:String(o.v) };
          const s = String(o).trim();
          const m = s.match(/^([A-Z])[\.、:：\s]+(.+)$/);
          if (m) return { k:m[1], v:m[2] };
          return { k:String.fromCharCode(65+i), v:s };
        });
      }
      function _normAns(q) {
        // 输出统一: 答案 key 集合 Set(['A','B'])
        let a = q.answer;
        const type = q.type || 'single';
        if (type === 'judge') {
          // 兼容 '对'/'错'/'正确'/'错误'/'A'/'B'/true/false
          if (a === true || a === '对' || a === '正确' || a === 'A' || a === '是') return new Set(['A']);
          return new Set(['B']);
        }
        if (Array.isArray(a)) return new Set(a.map(x => String(x).toUpperCase()));
        if (typeof a === 'string') {
          // 'ABC' 或 'A,B,C' 或 'A B C'
          const chars = a.match(/[A-Z]/g) || [];
          return new Set(chars);
        }
        return new Set();
      }
      let _multiPicked = new Set(); // 多选题临时状态

      function renderQuestion(q) {
        _multiPicked = new Set();
        const opts2 = _normOpts(q);
        const type  = q.type || 'single';
        const badge = q.local_fj ? '<span class="v43-badge fj">🏯 福建/莆田本地题</span>' :
                     q.gaokao   ? '<span class="v43-badge gk">🎯 高考真题</span>' : '';
        const typeBadge = { single:'单选', multi:'多选', judge:'判断', fill:'填空' }[type] || '';
        const typeHtml = typeBadge ? `<span class="v43-badge" style="background:rgba(178,136,255,0.15);border:1px solid #b288ff;color:#b288ff;">${typeBadge}</span>` : '';

        if (type === 'fill') {
          qWrap.innerHTML = `
            <div class="battle-question v43-question">${badge}${typeHtml}${q.q}</div>
            <div style="margin:6px 12px 8px;">
              <input type="text" class="v43-fill-input" id="__fillInput" placeholder="输入答案后回车 / 点提交" autocomplete="off"
                style="width:100%;padding:10px;background:rgba(0,0,0,0.4);border:1px solid rgba(245,201,122,0.35);border-radius:6px;color:var(--xx-text);font-size:14px;">
              <button class="xx-btn xx-btn-primary" id="__fillSubmit" style="margin-top:6px;width:100%;">✓ 出招印证</button>
            </div>`;
          const input = qWrap.querySelector('#__fillInput');
          const submit = qWrap.querySelector('#__fillSubmit');
          const doSubmit = () => {
            const val = input.value.trim();
            if (!val) { UI.toast('请先填写答案', 'warn'); return; }
            input.disabled = true; submit.disabled = true;
            const std = String(q.answer||'').trim();
            const ok = val === std || val.replace(/\s/g,'') === std.replace(/\s/g,'');
            onAnswer(q, val, submit, ok);
          };
          input.addEventListener('keydown', e => { if (e.key === 'Enter') doSubmit(); });
          submit.onclick = doSubmit;
          setTimeout(() => input.focus(), 100);
          return;
        }

        qWrap.innerHTML = `
          <div class="battle-question v43-question">${badge}${typeHtml}${q.q}</div>
          <div class="battle-options v43-options">
            ${opts2.map(o => `<div class="battle-option v43-option" data-opt="${o.k}">${o.k}. ${o.v}</div>`).join('')}
          </div>
          ${type === 'multi' ? '<button class="xx-btn xx-btn-primary" id="__multiSubmit" style="margin:8px 12px 0;width:calc(100% - 24px);">✓ 出招印证（多选）</button>' : ''}
        `;
        qWrap.querySelectorAll('.v43-option').forEach(op => {
          op.onclick = () => {
            if (type === 'multi') {
              const k = op.dataset.opt;
              if (_multiPicked.has(k)) {
                _multiPicked.delete(k);
                op.classList.remove('picked');
              } else {
                _multiPicked.add(k);
                op.classList.add('picked');
              }
            } else {
              onAnswer(q, op.dataset.opt, op);
            }
          };
        });
        if (type === 'multi') {
          const btn = qWrap.querySelector('#__multiSubmit');
          btn.onclick = () => {
            if (!_multiPicked.size) { UI.toast('请至少选一项', 'warn'); return; }
            btn.disabled = true;
            qWrap.querySelectorAll('.v43-option').forEach(op => op.style.pointerEvents='none');
            onAnswer(q, Array.from(_multiPicked).sort().join(''), btn);
          };
        }
      }
      function onAnswer(q, pick, el, forcedCorrect) {
        const ansSet = _normAns(q);
        // pick 可能是 'A' 或 'AB' 或 用户填空文本
        let correct;
        if (typeof forcedCorrect === 'boolean') {
          correct = forcedCorrect;
        } else if ((q.type||'single') === 'multi') {
          // 完全匹配：picked 集合 = 答案集合
          const pickSet = new Set(String(pick).match(/[A-Z]/g) || []);
          correct = (pickSet.size === ansSet.size) && [...pickSet].every(k => ansSet.has(k));
        } else {
          correct = ansSet.has(String(pick).toUpperCase());
        }
        const ansRaw = q.answer;
        // 禁用其它选项防止重复点击
        qWrap.querySelectorAll('.v43-option').forEach(op => op.style.pointerEvents = 'none');
        // v4.0 FIX: answerReport 已内部依赖 submitAnswer，一体入账 exp/shi
        const rep = Game.answerReport ? Game.answerReport(q, correct) : null;

        if (correct) {
          el.classList.add('correct');
          // 小提示：飘字显示奖励
          if (rep && rep.expGain) {
            setTimeout(() => floatText(heroEl, `+${rep.expGain} 修为`, 'heal'), 40);
            setTimeout(() => floatText(heroEl, `+${rep.shiGain||0} 灵石`, 'heal'), 340);
          }
          let mul = 1, mpCost = 0, spell = null;
          if (selectedSkill === 'lightning') { mul = 2;   mpCost = 20; spell = 'lightning'; }
          else if (selectedSkill === 'fireball') { mul = 1.5; mpCost = 15; spell = 'fireball'; }
          if (c.mp < mpCost) { mul = 1; mpCost = 0; spell = null; pushLog('灵力不够，降为平取', 'warn'); }
          const r = Game.battleCast({ skillMul: mul, mpCost });
          heroEl.classList.add('attack');
          setTimeout(()=>heroEl.classList.remove('attack'), 500);
          if (spell) spellFx(spell);
          enemy.hp = Math.max(0, enemy.hp - r.dmg);
          setTimeout(()=>{
            enemyEl.classList.add('hurt');
            setTimeout(()=>enemyEl.classList.remove('hurt'), 400);
            floatText(enemyEl, (r.crit?'暴击! ':'') + '-' + r.dmg, r.crit?'crit':'dmg');
            updEnemy(); updHero();
            pushLog(`✅ 答对！${r.crit?'<b style="color:#ffe066;">暴击！</b>':''}对${enemy.name}造成 <b style="color:#f5c97a;">${r.dmg}</b> 伤害`, 'good');
            if (enemy.hp <= 0) {
              enemyEl.classList.add('defeat');
              pushLog('⚔ <b style="color:#ff9ec6;">妖兽已斩！</b>', 'win');
              if (isBoss) UI.screenShake();
              UI.explodeAt && UI.explodeAt(enemyEl);
              setTimeout(()=>finishBattle(true), 1100);
            } else {
              setTimeout(loadQuestion, 900);
            }
          }, 300);
        } else {
          if (el && el.classList) el.classList.add('wrong');
          // v4.1-fix: 用统一 ansSet 高亮正确选项
          qWrap.querySelectorAll('.v43-option').forEach(op => {
            if (ansSet.has(op.dataset.opt)) op.classList.add('correct');
          });
          const dmg = Game.battleTakeHit(enemy.atk);
          heroEl.classList.add('hurt');
          if (isBoss) UI.screenShake();
          setTimeout(()=>heroEl.classList.remove('hurt'), 400);
          floatText(heroEl, '-' + dmg.dmg, 'dmg');
          updHero();
          pushLog(`❌ 答错！${enemy.name}反噬 <b style="color:#e25b5b;">${dmg.dmg}</b> 伤害`, 'bad');
          if (dmg.dead) { setTimeout(()=>finishBattle(false), 1100); }
          else { setTimeout(loadQuestion, 1600); }
        }
      }
      function finishBattle(win) {
        if (win && opts.onWin) opts.onWin();
        if (!win && opts.onLose) opts.onLose();
        setTimeout(()=>{
          const winMsg = win
            ? `<div class="v43-battle-end win">
                <div class="v43-end-title">⚔ 斩妖胜利</div>
                <div class="v43-end-sub">修行更进一步 · 修为 灵石 已入账</div>
              </div>`
            : `<div class="v43-battle-end lose">
                <div class="v43-end-title">💀 道心崩碎</div>
                <div class="v43-end-sub">莫气馁 · 心魔录已记录此题</div>
              </div>`;
          vizWrap.innerHTML = '';
          qWrap.innerHTML = winMsg + `<div style="text-align:center;margin-top:12px;"><button class="xx-btn xx-btn-primary v43-end-btn" id="battleEnd">${win?'继续修炼':'重整旗鼓'}</button></div>`;
          if (win) UI.confetti && UI.confetti(40);
          scene.querySelector('#battleEnd').onclick = () => { mask.remove(); if (opts.onClose) opts.onClose(win); };
        }, 500);
      }

      closeBtn.onclick = () => { mask.remove(); if (opts.onClose) opts.onClose(false); };
      // ESC 关闭
      const escHandler = (e) => { if (e.key === 'Escape') { mask.remove(); document.removeEventListener('keydown', escHandler); if (opts.onClose) opts.onClose(false); } };
      document.addEventListener('keydown', escHandler);

      loadQuestion();

      return { close: () => mask.remove() };
    },

    // ============================================================
    //  v4.0 新增：学科页外框 (修复 v3 丢失问题)
    // ============================================================
    renderSubjectShell(sectKey, contentHtml) {
      const sectName = { physics:'⚡ 雷霆殿 · 物理', chemistry:'⚗ 丹鼎峰 · 化学',
                         geography:'🌏 山河阁 · 地理', chinese:'📜 文渊阁 · 语文',
                         math:'🔢 推衍宫 · 数学',    english:'🌐 译灵堂 · 英语' };
      const sectColor = { physics:'#7fb3ff', chemistry:'#ff9a5e', geography:'#8ce28c',
                          chinese:'#f5c97a', math:'#b288ff', english:'#ff9ec6' };
      const st = Game.state.sects[sectKey] || {};
      const totalManuals = (window[`${sectKey.toUpperCase()}_MANUALS`] || []).length;
      const totalBank    = (window[`${sectKey.toUpperCase()}_BANK`]    || []).length;
      const clr = sectColor[sectKey] || '#f5c97a';
      return `
        <div class="xx-immortal-box subject-header" style="margin-bottom:24px;border-color:${clr};">
          <div class="corner-tr"></div><div class="corner-bl"></div>
          <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
            <div>
              <h2 style="margin:0;font-family:var(--xx-font-art);font-size:28px;color:${clr};letter-spacing:4px;text-shadow:0 0 12px ${clr}88;">${sectName[sectKey] || sectKey}</h2>
              <div style="color:var(--xx-text-soft);font-size:13px;margin-top:6px;">
                已参悟功法 <b style="color:var(--xx-gold);">${(st.masteredManuals||[]).length}</b>/${totalManuals} ·
                已斩妖兽 <b style="color:var(--xx-red);">${(st.defeatedQuests||[]).length}</b>/${totalBank}
              </div>
            </div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;">
              <a href="../index.html" class="xx-btn">⬅ 回山门</a>
            </div>
          </div>
        </div>
        ${contentHtml}
      `;
    },

    // ============================================================
    //  v4.0 新增：Boss 战粒子爆炸特效
    // ============================================================
    explodeAt(el) {
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      for (let i = 0; i < 24; i++) {
        const p = document.createElement('div');
        p.style.cssText = `position:fixed;left:${cx}px;top:${cy}px;
          width:10px;height:10px;border-radius:50%;
          background:${['#f5c97a','#ff9ec6','#b288ff','#6ed5e0','#ffe6a3'][i%5]};
          pointer-events:none;z-index:9999;
          box-shadow:0 0 14px currentColor;
        `;
        document.body.appendChild(p);
        const angle = Math.random() * Math.PI * 2;
        const dist = 80 + Math.random() * 120;
        const dx = Math.cos(angle) * dist;
        const dy = Math.sin(angle) * dist;
        p.animate([
          { transform:'translate(0,0) scale(1)', opacity: 1 },
          { transform:`translate(${dx}px,${dy}px) scale(0)`, opacity: 0 }
        ], { duration: 900 + Math.random() * 400, easing: 'cubic-bezier(0.2, 0.6, 0.4, 1)' });
        setTimeout(() => p.remove(), 1400);
      }
    },

    // ============================================================
    //  v4.0 新增：CG 占位框 (像素/emoji/场景背景)
    // ============================================================
    renderCG(opts) {
      const { emoji='✨', caption='', scene='', sub='', pixel='' } = opts || {};
      const bg = _cgSceneBg(scene);
      const emojis = String(emoji).split(/[\s,，]+/).filter(Boolean);
      let mainVisual;
      if (pixel && typeof PixelArt !== 'undefined' && PixelArt.scene) {
        const px = PixelArt.scene(pixel);
        if (px) mainVisual = `<div class="cg-pixel-wrap">${px}</div>`;
      }
      if (!mainVisual) {
        mainVisual = emojis.length > 1
          ? `<div class="cg-emoji-row" style="display:flex;gap:14px;justify-content:center;align-items:flex-end;">` +
            emojis.map((e,i) => `<div class="cg-emoji" style="font-size:${i===0?68:52}px;animation-delay:${i*0.3}s;">${e}</div>`).join('') +
            `</div>`
          : `<div class="cg-emoji">${emoji}</div>`;
      }
      return `
        <div class="cg-frame" ${bg?`style="${bg}"`:''}>
          <div class="cg-sweep"></div>
          <div class="cg-content">
            ${mainVisual}
            ${caption ? `<div style="font-size:14px;margin-top:6px;color:var(--xx-text);letter-spacing:1px;">${caption}</div>` : ''}
            ${sub ? `<div style="font-size:11px;margin-top:4px;color:var(--xx-text-dim);letter-spacing:2px;">${sub}</div>` : ''}
          </div>
        </div>
      `;
    },

    // 屏幕震动（Boss 战用）
    screenShake() {
      const b = document.body;
      b.classList.remove('screen-shake');
      void b.offsetWidth;
      b.classList.add('screen-shake');
      setTimeout(() => b.classList.remove('screen-shake'), 800);
    },

    // 胜利彩带
    confetti(count = 60) {
      let wrap = document.querySelector('.xx-confetti-wrap');
      if (!wrap) {
        wrap = document.createElement('div');
        wrap.className = 'xx-confetti-wrap';
        document.body.appendChild(wrap);
      }
      const colors = ['#f5c97a','#ff9ec6','#b288ff','#6ed5e0','#8ce28c','#ffe6a3'];
      for (let i = 0; i < count; i++) {
        const p = document.createElement('div');
        p.className = 'xx-confetti-piece';
        p.style.left = (Math.random() * 100) + 'vw';
        p.style.background = colors[i % colors.length];
        p.style.animationDelay = (Math.random() * 0.6) + 's';
        p.style.animationDuration = (2.4 + Math.random() * 1.6) + 's';
        p.style.width = (5 + Math.random() * 6) + 'px';
        p.style.height = (10 + Math.random() * 10) + 'px';
        p.style.opacity = 0.7 + Math.random() * 0.3;
        wrap.appendChild(p);
      }
      setTimeout(() => wrap.remove(), 4500);
    },

    // 击中十字光
    hitCross(el) {
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const cross = document.createElement('div');
      cross.className = 'hit-cross';
      cross.style.position = 'fixed';
      cross.style.left = (rect.left + rect.width / 2) + 'px';
      cross.style.top  = (rect.top + rect.height / 2) + 'px';
      document.body.appendChild(cross);
      setTimeout(() => cross.remove(), 600);
    },

  };

  // 场景渐变背景
  function _cgSceneBg(scene) {
    const map = {
      sect_gate:  'background: linear-gradient(180deg, rgba(178,136,255,0.18), rgba(20,18,42,0.6)), radial-gradient(circle at 50% 90%, rgba(245,201,122,0.24), transparent 60%);',
      boss_arena: 'background: linear-gradient(180deg, rgba(226,91,91,0.32), rgba(20,18,42,0.6)), radial-gradient(circle at 50% 70%, rgba(255,158,198,0.28), transparent 60%);',
      shrine:     'background: linear-gradient(180deg, rgba(245,201,122,0.22), rgba(20,18,42,0.6)), radial-gradient(circle at 50% 100%, rgba(255,230,163,0.35), transparent 55%);',
      library:    'background: linear-gradient(180deg, rgba(140,226,140,0.16), rgba(20,18,42,0.6)), radial-gradient(circle at 50% 80%, rgba(110,213,224,0.24), transparent 60%);',
      mountain:   'background: linear-gradient(180deg, rgba(110,213,224,0.18), rgba(20,18,42,0.7)), radial-gradient(circle at 50% 95%, rgba(178,136,255,0.22), transparent 60%);',
      cave:       'background: linear-gradient(180deg, rgba(20,10,30,0.5), rgba(178,136,255,0.24));',
      sky:        'background: linear-gradient(180deg, rgba(178,136,255,0.24), rgba(110,213,224,0.18)), radial-gradient(circle at 50% 20%, rgba(255,255,255,0.15), transparent 40%);',
      battle_win: 'background: linear-gradient(180deg, rgba(245,201,122,0.28), rgba(178,136,255,0.18)), radial-gradient(circle at 50% 50%, rgba(255,230,163,0.35), transparent 55%);',
    };
    return map[scene] || '';
  }

  // 全局：突破特效自动监听
  if (typeof window !== 'undefined' && global.Game) {
    global.Game.on('breakthrough', realm => UI.breakthrough(realm));
  }
  document.addEventListener('DOMContentLoaded', () => {
    if (global.Game && !global.Game._uiBound) {
      global.Game.on('breakthrough', realm => UI.breakthrough(realm));
      global.Game.on('bossDrop', drop => {
        UI.toast(`✨ 掉落：${drop.icon} · ${drop.name}`, 'success', 3200);
      });
      // v4.0 FIX: 突破后属性成长提示
      global.Game.on('statsGrown', d => {
        UI.toast(`✨ 道基成长！HP+${d.hpGain} MP+${d.mpGain} ⚔+${d.atkGain} 🛡+${d.defGain}`, 'success', 3500);
      });
      // v4.0 FIX: 领悟功法提示（保证可见）
      global.Game.on('manualMastered', d => {
        UI.toast(`📖 参悟成功！+${d.expGain} 修为 +${d.shiGain} 灵石`, 'success', 3500);
      });
      global.Game.on('proficiencyMilestone', d => {
        UI.toast(`🌟 熟练度达“${d.label}”！+${d.reward.exp} 修为 +${d.reward.shi} 灵石`, 'success', 3200);
      });
      global.Game._uiBound = true;
    }
  });

  global.UI = UI;

})(typeof window !== 'undefined' ? window : this);
