# 《问道修仙学院》v4.0 · Bug 修复批次 (2026-07-03)

> 本次更新是 v4.0 的 **稳定性修复批次**，版本号保持 v4.0（不再频繁大版本迭代）。
> 
> 重点解决用户反馈的 4 大痛点：
> 1. **功法无法领悟** —— 题做了、怪打了，就是没触发参悟成功
> 2. **道具/兽宠境界限制说了不算** —— 提示"需元婴"但凡人也能装
> 3. **学习/打怪奖励没有随修为上升而指数增加** —— 后期收益太低，无法冲更高境界
> 4. **玩家属性没有随修为成长** —— 突破了几十层但 HP 还是 100

## 🐛 修复清单

### 一、功法领悟系统（核心修复）
- **[FIX] UI.openBattle 接口不匹配** —— 沉浸式学习模块 (Immersive) 传的是 `{question, sect, monsterName, difficulty, onDone}`，但 openBattle 只认 `{enemy, getQuestion, onWin, onLose, onClose}`。新增兼容层自动转换。
- **[FIX] 试炼通过条件放宽** —— 原来必须 3 题答对 2 题，改为答对 ≥ 1 题即可参悟（不再"题做了没领悟"）。
- **[FIX] 试炼战斗回调防重入** —— onWin/onLose/onClose 三重触发只算一次，避免统计错乱。
- **[FIX] answerReport 补齐奖励入账** —— 原本只做记录不给修为/灵石，现在改为内部调用 submitAnswer 走完整奖励流程。
- **[FIX] 参悟成功后 modal 关闭顺序修正**

### 二、奖励曲线指数化
- **[FIX] 新增 `Game.getRealmMultiplier()`** —— 前 30 层线性 + 后期指数（1.045^(id-30)）
  - 凡人：1×
  - 炼气一层：1.05×
  - 筑基一层：约 2.6×
  - 金丹一层：约 6×
  - 元婴一层：约 30×
  - 化神一层：约 200×
  - 渡劫一层：约 1500×
- **[FIX] 答题 submitAnswer 奖励** × 境界倍率
- **[FIX] 参悟功法首悟大奖** × 境界倍率
- **[FIX] 功法精进奖励** 使用统一境界倍率（原来只是 1+id×0.01）
- **[FIX] 洞府打坐奖励** × 境界倍率（修为 + HP/MP 恢复）
- **[FIX] 秘境探索所有事件奖励** × 境界倍率
- **[FIX] 每日任务奖励** × 境界倍率
- **[FIX] 斩妖场胜利额外奖励** × 境界倍率

### 三、玩家属性成长
- **[FIX] 新增 `_growStatsOnBreakthrough(realmId)`** —— 每次突破自动加：
  - HP +15×(1+layer×0.02)
  - MP +8×(1+layer×0.02)  
  - ATK +3×(1+layer×0.02)（保底 +2）
  - DEF +1.5×(1+layer×0.02)（保底 +1）
  - 每 10 层 CRIT +1%
  - 突破后 HP/MP 满血
- **[FIX] 新增 `_catchUpStats()`** —— 老存档打开时自动追赶属性
  - 已达高境界但属性还是初始值 → 按境界层数重新计算 HP/MP/ATK/DEF/CRIT
  - 正确计入已装备装备的加成
  - 只增不减，安全无副作用

### 四、道具/兽宠境界限制
- **[FIX] 新增 `Game.checkRealmReq(item)` 通用检查**
- **[FIX] GEAR_DATA / PILL_DATA / PET_DATA 全部加 realmReq 字段**
  - 精品装备：需炼气中期 (realmId ≥ 11)
  - 稀有装备：需筑基 (≥ 31)
  - 史诗装备：需元婴 (≥ 91)
  - 传说装备：需渡劫 (≥ 181)
- **[FIX] equipGear / usePill / assignPet 装配前校验**
  - 修为不足会明确提示"需筑基方可解锁使用"

### 五、精进冷却随境界降低
- **[FIX] `Game.getRefineCooldown()` 动态冷却**
  - 凡人~炼气~筑基：30 分钟
  - 金丹：15 分钟
  - 元婴：5 分钟
  - 化神：2 分钟
  - 渡劫+：1 分钟
- 让高境界玩家有更强的学习节奏

### 六、可见性提示
- **[FIX] statsGrown Toast** —— 突破后立刻显示 "道基成长！HP+X MP+X ⚔+X 🛡+X"
- **[FIX] manualMastered Toast** —— 参悟成功显式提示奖励入账
- **[FIX] proficiencyMilestone Toast** —— 熟练度里程碑提示

## 📁 修改文件清单

| 文件 | 主要修改 |
|------|---------|
| `assets/game-core.js` | 全部核心修复：奖励倍率、属性成长、境界限制、动态冷却、答题上报、属性追赶 |
| `assets/ui-components.js` | openBattle 兼容层、事件订阅 Toast 提示 |
| `assets/subject-page.js` | 试炼通过条件放宽、斩妖场奖励用境界倍率 |
| `assets/immersive-learning.js` | 试炼通过条件放宽、防重入回调 |
| `index.html` | 更新说明文案（保留 v4.0 版本号） |

## 🔒 兼容性
- 老 v4.0 存档 → **自动追赶属性**，无需操作
- v1-v3 存档 → 一如既往兼容
- 版本号保持 v4.0，不冒进
