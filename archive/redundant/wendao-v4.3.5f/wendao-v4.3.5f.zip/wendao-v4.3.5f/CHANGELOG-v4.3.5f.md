# v4.3.5f · 硬伤全修补丁包（Emergency Hotfix）

> 基于 v4.3.6-final，撤销上一版有 bug 的 hotfix，替换为一份彻底修好的 `v435f-hotfix.js`。
> 这是一个"急救包"版本，重点是把你实测反馈的所有硬伤堵死，让游戏能真正玩通。
> 完整重构（v4.3.6a）会在这份包稳定后另发。

---

## 上一版 v436-final-hotfix.js 存在的严重问题（这一版全部修好）

| # | 上一版的 bug | 本版修复 |
|---|---|---|
| A | 洞府答题**只处理 single 题型**，遇到 fill/multi/judge/calc 直接卡死或看不到答题控件 | 支持 single / multi / judge / fill / calc / solve / essay **全题型**，每种类型都有对应的输入 UI |
| B | 洞府判正误用 `picked === q.answer` —— **picked 是数字下标，q.answer 是 "A"/"B"/"C"** —— 选什么都错 | 判题一律调用权威函数 **`Game.judgeAnswer(q, userAns)`**，和答题系统完全一致 |
| C | 成就闪：仅本 session 去重，跨 session 会漏；且没跳过已 `done` 的成就 | 用"beforeDone / afterDone 快照差集"识别真正新解锁的；一栈内多条成就聚合成**一条 toast**，index.html 的原生 toast 被 wrap 后吞掉 |
| D | 四宫格双绑：委托 + 原 bindFourGrid 都触发，可能一击两次或互相冲突 | `UI.bindFourGrid` 空转，只走 document 捕获层委托，**唯一路径不再冲突** |
| E | AutoViz fallback 覆盖时返回了错误图，实际把好的图也顶掉了 | 撤销上一版覆盖；新版对**每个 manualId** 生成"专属可视化图"（学科色 + 编号 hash + 主题符号） |

---

## 本版真正做了什么（一份文件搞定）

### ✅ Bug 1 · 主页四宫格打不开

- 撤销 `UI.bindFourGrid` 的 onclick 绑定（改成空函数）
- 唯一入口：`document` 捕获层委托 `[data-open]`
- 无论 `renderAll` 把 DOM 换多少次，点击都能响应
- 支持所有八个入口：洞府 / 秘境 / 法宝阁 / 每日 / 装备 / 丹药 / 灵宠 / 成就殿堂

### ✅ Bug 2 · 洞府闭关全题型支持

洞府现在会随机从你已解锁学科里抽一道题，题型可以是：

- **单选**：点击选项 → 提交作答 → 立即判正误
- **多选**：可点多个选项（再点一次取消）→ 提交作答 → 立即判正误
- **判断**：只有"对/错"两个选项
- **填空**：文本输入框，回车提交
- **计算 / 解答 / 论述**：多行输入框，写答案对照参考解

奖励公式（每次闭关）：

```
洞府等级倍率 = 1.35^(Lv - 1)   // Lv1=1x, Lv2=1.35x, Lv5=3.32x
境界倍率 = Game.getRealmMultiplier()
难度基数 = normal 90 / easy 55

答对：修为 +难度基数 × 洞府倍率 × 境界倍率
      道心 +30 + 境界倍率×4
      HP/MP 全恢复

答错：道心 +5
      HP/MP 恢复一半
```

其他机制：

- 每日最多 **4 次**（子夜 0:00 刷新）
- 每次闭关后需 **30 分钟冷却**
- 洞府升级：花灵石，倍率 ×1.35 指数增长（Lv1→Lv2 需 500，Lv2→Lv3 需 900，Lv5 需 4200 灵石）
- 升级倍率温和（**1.35 而不是 2.0**），符合你说的"倍率不要那么离谱"

### ✅ Bug 3 · 成就不再乱闪

**根源**：`_checkAchievements` 一次遍历时如果多个成就同时达标，会连续 emit 多条 `achievementUnlock`，index.html 里的 handler 每条都弹一次 toast。而且 `addLingshi`/`addExp` 触发的事件级联会重复调用 `_checkAchievements`。

**方案**（三重防线）：

1. **单栈锁**：`_checkAchievements` 加 `__achvStackLock`，防止递归重入
2. **差集去重**：本次调用前的 `done` 快照 vs 结束后的 `done` 快照，只对差集触发一次 toast
3. **聚合弹窗**：一次栈内新解锁多条 → 弹一条聚合 toast（例如"🏆 连解 3 项成就：小试牛刀、初窥门径、旗开得胜"）
4. **原生 toast 吞掉**：包装 `UI.toast`，`🏆 成就解锁：...` 只有我们主动发的能通过，其他一律吞掉（防止 index.html 里的重复 handler 再弹）

### ✅ Bug 4 · 斩妖场怪物属性按敌方境界算标杆

**核心修复**：`scaleMonsterForRealm` 里改成用 `enemyRid`（敌人境界）算标杆，而不是 `playerRid`（玩家境界）。

**目标曲线**：

| 情境 | 预期回合数 |
|---|---|
| 同阶 normal 妖 | 2–4 回合 |
| 同阶 hard 妖 | 5–8 回合 |
| 同阶 boss 妖 | 10–15 回合 |
| 越阶 +1 | 稍难（+15%） |
| 越阶 +2 | 极难（+30%） |
| 越阶 +3 | 禁入 |

具体公式：

```js
targetForEnemy = Game.getTargetStatsForRealm(enemyRid)  // ← 关键：用 enemyRid 不是 playerRid
diffMul = { easy: 0.55, normal: 1.0, hard: 1.55, boss: 2.4 }[diff]
gapHp   = 1 + clamp(gap × 0.15, -0.5, 1.0)   // gap = enemyRid - playerRid
hp = round(targetForEnemy.maxHp × 0.88 × diffMul × gapHp)
atk = round(targetForEnemy.atk × 0.62 × diffMul × gapAtk)
```

### ✅ Bug 5 · 每个功法都有专属可视化图

上一版说"删了可视化"——实际 `auto-visualizer.js` 一行没删，但**关键词没命中的题会看到空白**。这一版做了两件事：

1. **保留 AutoViz 原有的匹配图**（振动 / 波 / 磁场 / VSEPR / 气候 / 洋流 …），但在顶部加一个 `⚡ 雷霆殿 · phy_m1` 学科色小标签
2. **匹配不到的情况**：为**每个 manualId** 生成一张"专属装饰环"图：
   - 学科色（物理青 / 化学橙 / 地理绿 / 语文金 / 数学紫 / 英语蓝）
   - 六个主题符号绕圈（物理 F/v/a/E/B/ω，化学 H/O/C/N/Na/Cl，地理 ☀🌊⛰，数学 ∫Σ√π∞θ，语文 之而也则乎矣，英语 A/the/to/of/is/be）
   - 每个 manualId 的 hash 决定符号选择、旋转角度 → **同一功法永远显示同一张图**（稳定）

暴露给外部：`AutoViz.forManual(manual)` 可以直接给功法详情页调用。

---

## 文件变更

| 文件 | 变更 |
|---|---|
| `assets/v435f-hotfix.js` | **新增**（33 KB，全部修复逻辑） |
| `assets/v436-final-hotfix.js` | **删除**（旧版 hotfix，已有 bug） |
| `index.html` | 挂载点从 `v436-final-hotfix.js` 改为 `v435f-hotfix.js`；标题栏、版本号更新为 v4.3.5f |
| `subjects/*.html` | 6 个学科页同步更新脚本引用 |
| `CHANGELOG-v4.3.5f.md` | 本文件 |

**总大小**：约 12.5 MB（题库和场景图占大头，核心逻辑不到 100 KB）

---

## 验证清单（用户实测请优先跑这些）

- [ ] 主页四宫格：洞府 / 秘境 / 法宝阁 / 每日 / 装备 / 丹药 / 灵宠 / 成就殿堂——**每个都能打开**
- [ ] 洞府闭关：入定问道后，题目类型能随机出现，选完 / 输入完点【提交作答】都能正确判正误
- [ ] 洞府答对：修为、道心正确入账；HP/MP 满血
- [ ] 洞府答错：不扣任何东西，只是 HP/MP 半血
- [ ] 洞府升级：灵石够时能升级，倍率变成 ×1.35 而不是 ×2.0
- [ ] 做对题目 / 打怪之后，**不再一堆成就 toast 乱弹**（最多一条聚合的）
- [ ] 斩妖场：筑基期怪按筑基期玩家标杆做（同阶 normal 2-4 回合可解，boss 10-15 回合）
- [ ] 越阶 +2/+3 的怪明显更难，但不会瞬秒你
- [ ] 每个功法进详情页 → 看到可视化图（有的是 AutoViz 匹配的具体图，没匹配到的是学科专属装饰环）

---

## 控制台预期输出

打开 index.html，按 F12 → Console 应该看到：

```
[v4.3.5f] ✔ Bug 3 修复：成就 toast 单栈聚合 + 已 done 跳过 + 原生 toast 被吞
[v4.3.5f] ✔ Bug 1 修复：四宫格改走委托，bindFourGrid 已空转（消除双触发）
[v4.3.5f] ✔ Bug 4 修复：怪物属性用 enemyRid 境界算标杆（同阶怪按同阶玩家标杆做）
[v4.3.5f] ✔ Bug 2 修复：洞府闭关问道支持 single/judge/multi/fill/calc 全题型；判题走 Game.judgeAnswer
[v4.3.5f] ✔ Bug 5 修复：AutoViz 每个功法都有专属可视化图（稳定 hash · 学科色符号）
[v4.3.5f] 全部补丁挂载完毕 ✅ (四宫格 · 洞府 · 成就 · 斩妖 · 功法可视化)
```

如果某条没出现，说明对应模块加载失败——F12 打开 Sources 面板搜 `v435f-hotfix` 看具体报错。

---

## 下一步（v4.3.6a 完整重构）

这个补丁只是"堵漏水"，不动核心架构。你说的"完整重构 v4.3.6a"会在这份包稳定后另发，会涉及：

- 重写 `ui-components.js` 的事件绑定层（移除所有 `onclick=`，全部走委托）
- 重构 `game-core.js` 里 `_checkAchievements` 的调用时机（改为节流触发而非事件级联）
- 洞府 UI 做成常驻卡片（不用弹窗），减少 DOM 重刷
- 战斗回合制加入音效、暴击 shake、连击特效

_v4.3.5f · 莆田四中限定 · 2026-07-05_
