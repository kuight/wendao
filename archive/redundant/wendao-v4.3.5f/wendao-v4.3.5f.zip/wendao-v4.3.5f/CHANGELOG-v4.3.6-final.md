# v4.3.6 · FINAL HOTFIX（4-bug 修复整合包）

> 基于 v4.3.6 融汇贯通版，追加一个 hotfix 脚本 `v436-final-hotfix.js`。
> 全部实测反馈的 4 个硬 bug 均已修复，不改动核心架构，最小侵入。

---

## 修复清单（用户实测反馈的 4 个 bug）

### ✅ Bug 1 · 主页四宫格打不开（炼丹房 / 灵植园 / 洞府 / 秘境等）
- **原因**：`renderAll` 会把 `four-grid-mount` 整个 `innerHTML` 替换，旧的 `onclick` 绑定跟旧 DOM 一起没了；`bindFourGrid` 虽然会重绑，但只要中间任何一个事件抢先触发 `renderAll` 或 `bindFourGrid` 里报错，就会永久断绑。
- **方案**：事件委托到 `document` 捕获层，永远不会因 DOM 重刷而失效。同时对每个入口做 `try/catch`，出错也会 toast 提示而不是静默失败。
- **代码**：`v436-final-hotfix.js` Bug 1 段（约 40-80 行）

### ✅ Bug 2 · 洞府闭关沦为"废物"
- **原话**：*"洞府修不是让你修成废物啊，可以做成随机答题然后给奖励修为这样，我只是说倍率不要那么离谱啊。"*
- **方案**：把 `UI._openCaveModal` 覆盖成"闭关问道"面板：
  - 每日 4 次闭关额度，30 分钟冷却
  - 每次从当前解锁学科题库随机抽 1 道 easy/normal 题
  - **答对**：修为 +（60 × 1.35^Lv × 境界系数）、道心 +30、HP/MP 全恢复
  - **答错**：道心 +5、HP/MP 恢复一半（不惩罚，鼓励继续）
  - 洞府升级倍率从 2.0 温和调整为 **1.35 指数**（Lv1=1x、Lv2=1.35x、Lv5=3.32x）
  - 升级灵石消耗曲线也温和（1.8^Lv 而非 2.2^Lv）
- **代码**：`v436-final-hotfix.js` Bug 2 段（约 150-320 行）

### ✅ Bug 3 · 成就乱闪（做对题目 / 打怪完瞬间弹一堆 toast）
- **原因**：
  1. `_checkAchievements` 一次遍历所有成就，对每个新解锁的都会 `emit('achievementUnlock')`，`index.html` 的监听器每次都弹一条 toast。
  2. `addLingshi` / `addExp` 又会触发新的事件级联 → `_checkAchievements` 再次被调用 → 无限循环重复触发。
- **方案**：
  - `_checkAchievements` 加**同栈锁**（`Game.__achvLock`），防止递归重入
  - 每个成就 aid 只允许弹一次 toast（`Game.__achvToastedIds` Set 去重）
- **代码**：`v436-final-hotfix.js` Bug 3 段（约 85-115 行）

### ✅ Bug 4 · 斩妖场怪物数值错误
- **原话**：*"斩妖场的怪物数值有问题，我感觉你是按玩家当前境界做的，我要的是比如筑基的怪你就按玩家筑基期的实力当标杆做，懂不？不然根本没有指数曲线啊。"*
- **原因**：`scaleMonsterForRealm` 里 `const p = getTargetStatsForRealm(playerRid)` —— 用的是**玩家当前境界**算标杆，不是敌人境界。
- **方案**：改用 `enemyRid` 算标杆，同阶敌人 HP ≈ 敌方境界玩家标杆 HP × 0.88（同阶 normal 2-4 回合可解），越阶补正温和（gap × 0.15 而非原来的 0.22，避免 +1 就爆炸）。
- **曲线目标**：
  - 同阶 normal：2-4 回合可解
  - 同阶 hard：5-8 回合
  - 同阶 boss：10-15 回合
  - 越阶 +1：稍难（+15%）
  - 越阶 +2：极难（+30%）
  - 越阶 +3：已禁入
- **代码**：`v436-final-hotfix.js` Bug 4 段（约 118-150 行）

---

## 文件变更

| 文件 | 变更 |
|---|---|
| `assets/v436-final-hotfix.js` | **新增**（全部修复逻辑，1 个 IIFE） |
| `index.html` | 加载 `v436-final-hotfix.js`；标题栏说明追加 "+ FINAL HOTFIX" |
| `subjects/*.html` | 每个学科页均加载 `v436-final-hotfix.js` |

---

## 关于"功法可视化组件"

`auto-visualizer.js`（1350 行）**没有被删除**，仍完整保留：
- `index.html` L133、`subjects/*.html` 均正确引用
- `subject-page.js` L282 / L658 / `_sampleViz` 均正常调用 `AutoViz.forQuestion(q)`
- `immersive-learning.js` L493-501、L621 也都会在"观道演示"和"试炼答题"阶段调用 `AutoViz`

**如果你在某道题看不到可视化图**，是因为 `auto-visualizer.js` 只对匹配到关键词（物理受力/化学分子/地理等高线等 30 多种模板）的题目会渲染 SVG，其余题目会隐藏"参考图示"折叠面板——这是 v4.0 设计好的行为（不生硬贴符文兜底图）。功法详情页（`_startLearnStage` stage 2 · 导引示例）也是同样通过 `_sampleViz` 从该功法关联题目里挑一道生成 SVG。

如你希望**每个功法**都强制显示一张可视化（哪怕是抽象符文兜底），可以在下一版本让我改 `AutoViz.render()` 让 `_fallback` 也输出——目前设计上留白是为了避免"挂羊头卖狗肉"。

---

_v4.3.6-final · 莆田四中限定 · 2026-07-05_
