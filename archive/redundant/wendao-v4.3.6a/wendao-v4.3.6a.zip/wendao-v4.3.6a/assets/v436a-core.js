/* ================================================================
 * 问道修仙学院 · v4.3.6a 完全重置核心补正
 * ----------------------------------------------------------------
 * 这不是"再叠一个 hotfix"。这是一个**函数替换层**：
 *   - 把 game-core.js 和 ui-components.js 里 5 个错误的关键函数
 *     直接换成正确实现（不叠加、不双绑）；
 *   - 挂一次 document-级事件委托，永久解决四宫格失灵；
 *   - 提供一个统一的、成就 100ms 去抖聚合 toast；
 *   - 为每个 manualId 生成"专属装饰环"SVG，AutoViz 兜底不再空图；
 *   - 洞府 = 闭关问道（走 Game.judgeAnswer 全题型）。
 * 保证：只覆盖原方法一次；重复加载不叠加；所有黑历史打过的补丁都已从 index.html 移除。
 * ================================================================ */
(function (global) {
  'use strict';

  if (global.__WENDAO_V436A__) return;
  global.__WENDAO_V436A__ = true;

  const LOG = (...a) => console.log('%c[v4.3.6a]', 'color:#f5c97a;font-weight:700;', ...a);
  const WARN = (...a) => console.warn('%c[v4.3.6a]', 'color:#f39c56;font-weight:700;', ...a);

  function whenReady(fn) {
    if (document.readyState === 'complete' || document.readyState === 'interactive') {
      setTimeout(fn, 0);
    } else {
      document.addEventListener('DOMContentLoaded', () => setTimeout(fn, 0));
    }
  }

  // =================================================================
  // 【Bug 3】成就 debounce + 差集 + toast 聚合
  // =================================================================
  function patchAchievements() {
    if (!global.Game || !global.Game.ACHIEVEMENTS) return false;
    const Game = global.Game;

    // 拦截 emit('achievementUnlock', ...) —— 在 emit 层做聚合
    const origEmit = Game.emit.bind(Game);
    const achvBuf = [];   // 待聚合的成就
    let flushTimer = null;
    const flush = () => {
      flushTimer = null;
      if (!achvBuf.length) return;
      const items = achvBuf.splice(0, achvBuf.length);
      // 去重（同一次多帧内可能重复）
      const seen = new Set();
      const uniq = items.filter(it => {
        const id = it && it.id;
        if (!id || seen.has(id)) return false;
        seen.add(id);
        return true;
      });
      if (!uniq.length) return;
      // 触发一次聚合事件供 renderAll 重绘
      origEmit('achievementUnlockBatch', { list: uniq });
      // toast 聚合
      if (global.UI && global.UI.toast) {
        if (uniq.length === 1) {
          global.UI.toast('🏆 成就解锁：' + (uniq[0].achv.name || uniq[0].id), 'success');
        } else {
          const first = uniq[0].achv.name || uniq[0].id;
          global.UI.toast(`🏆 解锁 ${uniq.length} 项成就：${first} 等`, 'success');
        }
      }
    };
    Game.emit = function (evt, payload) {
      if (evt === 'achievementUnlock') {
        // 只把 payload 塞进缓冲，不广播原事件（避免 UI 挂在这上面重复 toast）
        achvBuf.push(payload);
        if (!flushTimer) flushTimer = setTimeout(flush, 100);
        return;
      }
      return origEmit(evt, payload);
    };

    // 替换 _checkAchievements：只处理未 done 的、只对新解锁 emit
    Game._checkAchievements = function () {
      if (!Game.ACHIEVEMENTS) return;
      const s = this.state;
      Object.keys(Game.ACHIEVEMENTS).forEach(aid => {
        const a = Game.ACHIEVEMENTS[aid];
        const rec = s.achievements[aid] = s.achievements[aid] || { progress: 0, done: false };
        if (rec.done) return;    // ✅ 已 done 直接跳过（差集）
        let cur = 0;
        try { cur = a.check(s) || 0; } catch (e) { cur = 0; }
        rec.progress = Math.min(a.target || 1, cur);
        if (cur >= (a.target || 1)) {
          rec.done = true;
          rec.doneAt = Date.now();
          if (a.reward) {
            if (a.reward.shi) this.addLingshi(a.reward.shi);
            if (a.reward.exp) this.addExp(a.reward.exp);
          }
          this.emit('achievementUnlock', { id: aid, achv: a });
        }
      });
    };

    LOG('✅ Bug 3 · 成就系统已加固（debounce 100ms + 差集 + toast 聚合）');
    return true;
  }

  // =================================================================
  // 【Bug 4】斩妖场：怪物用 enemyRid（不再跟着玩家等级变）
  // =================================================================
  function patchMonster() {
    if (!global.Game) return false;
    const Game = global.Game;

    // getMonsterScale(diff, enemyRid) —— 允许 baseDef 传入 rid
    Game.getMonsterScale = function (diff, enemyRid) {
      // 关键：enemyRid 来自怪物本身，与玩家 realmId 无关
      const id = (enemyRid != null) ? enemyRid : 0;
      let base;
      if (id <= 20)      base = 1 + id * 0.06;
      else if (id <= 50) base = 2.2 + (id - 20) * 0.09;
      else               base = 4.9 * Math.pow(1.055, id - 50);
      const diffMul = { easy: 0.7, normal: 1.0, hard: 1.4, boss: 2.2, legend: 3.0 }[diff] || 1;
      return { hpMul: base * diffMul, atkMul: base * diffMul * 0.92, enemyRid: id };
    };

    Game.scaleMonster = function (baseDef) {
      const diff = (baseDef && baseDef.diff) || 'normal';
      // 优先用 baseDef.enemyRid；否则退回 baseDef.rid；再退回玩家等级作为兼容兜底
      const enemyRid = (baseDef && (baseDef.enemyRid != null ? baseDef.enemyRid : baseDef.rid));
      const useRid = (enemyRid != null) ? enemyRid : (this.state.char.realmId || 0);
      const s = this.getMonsterScale(diff, useRid);
      const t = this.getMonsterTitle ? this.getMonsterTitle(diff, useRid) : { titles: [], tier: diff };

      // 越阶保护：玩家越阶挑战 +3 及以上，怪物 HP × 10（避免速通）；
      // 但封顶 20x，避免"手抖点错"看到一个百万 HP 的天崩地裂
      const gap = useRid - (this.state.char.realmId || 0);
      let gapPenalty = 1;
      if (gap >= 3)      gapPenalty = 10;
      if (gap >= 6)      gapPenalty = 20;   // 越阶 6+ 封顶 20x

      const hp  = Math.max(30, Math.round((baseDef.hp  || 100) * s.hpMul  * gapPenalty));
      const atk = Math.max(3,  Math.round((baseDef.atk || 10)  * s.atkMul * Math.sqrt(gapPenalty)));
      return Object.assign({}, baseDef, {
        hp, maxHp: hp, atk,
        titles: t.titles, tier: t.tier,
        enemyRid: useRid,
        realmName: this._playerTierNameOf ? this._playerTierNameOf(useRid) : (this._playerTierName ? this._playerTierName() : ''),
      });
    };

    // 头衔按 enemyRid 变化（不跟随玩家等级）
    Game._playerTierNameOf = function (rid) {
      const r = this.getRealm ? this.getRealm(rid) : null;
      if (r && r.tierName) return r.tierName;
      if (typeof global.REALM_TIERS !== 'undefined' && typeof global.LAYERS_PER_TIER !== 'undefined') {
        const idx = Math.min(global.REALM_TIERS.length - 1,
                             Math.floor((rid - 1) / global.LAYERS_PER_TIER));
        return (global.REALM_TIERS[Math.max(0, idx)] || {}).name || '凡';
      }
      return '凡';
    };
    const origTitle = Game.getMonsterTitle;
    Game.getMonsterTitle = function (diff, enemyRid) {
      const id = (enemyRid != null) ? enemyRid : (this.state.char.realmId || 0);
      const tierName = this._playerTierNameOf(id);
      const tierMap = {
        easy:   { cls: 't-realm',  text: tierName + '期·凡阶' },
        normal: { cls: 't-tier',   text: tierName + '期·中阶' },
        hard:   { cls: 't-elite',  text: tierName + '期·精英' },
        boss:   { cls: 't-boss',   text: tierName + '期·妖王' },
        legend: { cls: 't-legend', text: '真君之姿' }
      };
      const t = tierMap[diff] || tierMap.normal;
      const titles = [t];
      if (id >= 30 && diff === 'boss')  titles.push({ cls: 't-legend', text: '血月加持' });
      if (id >= 60 && diff !== 'easy')  titles.push({ cls: 't-elite',  text: '噬灵变异' });
      if (id >= 100)                     titles.push({ cls: 't-legend', text: '渡劫之资' });
      return { tier: diff, titles };
    };

    LOG('✅ Bug 4 · 妖兽属性改用 enemyRid（无关玩家境界）+ 越阶保护');
    return true;
  }

  // =================================================================
  // 【Bug 2】洞府 = 闭关问道（不再"打坐"）
  // =================================================================
  function patchCave() {
    if (!global.Game) return false;
    const Game = global.Game;

    // 冷却 3 分钟；每日次数 10 次
    const CD_MS = 3 * 60 * 1000;
    const DAILY_MAX = 10;

    // 每日计数：使用 state.cave.dailyCount / dailyDate
    function ensureDaily() {
      const cv = Game.state.cave = Game.state.cave || { level: 1, lastMeditateAt: 0 };
      const today = new Date().toISOString().slice(0, 10);
      if (cv.dailyDate !== today) {
        cv.dailyDate = today;
        cv.dailyCount = 0;
      }
      cv.dailyCount = cv.dailyCount || 0;
    }

    Game.canMeditate = function () {
      ensureDaily();
      const cv = this.state.cave;
      if ((cv.dailyCount || 0) >= DAILY_MAX) return false;
      return (Date.now() - (cv.lastMeditateAt || 0)) >= CD_MS;
    };
    Game.getCaveDailyRemain = function () {
      ensureDaily();
      return DAILY_MAX - (this.state.cave.dailyCount || 0);
    };
    Game.getCaveCooldownRemaining = function () {
      const cv = this.state.cave || {};
      return Math.max(0, CD_MS - (Date.now() - (cv.lastMeditateAt || 0)));
    };

    // 从"用户已学过的功法"中，抽 1 道随机题
    Game.getCaveRandomQuestion = function () {
      const banks = {
        physics:   global.PHYSICS_BANK   || [],
        chemistry: global.CHEMISTRY_BANK || [],
        geography: global.GEOGRAPHY_BANK || [],
        chinese:   global.CHINESE_BANK   || [],
        math:      global.MATH_BANK      || [],
        english:   global.ENGLISH_BANK   || []
      };
      const sects = Object.keys(banks);
      // 收集玩家 mastered 的 manualId（分学科）
      const masteredBySect = {};
      sects.forEach(s => {
        const rec = (this.state.sects && this.state.sects[s]) || {};
        masteredBySect[s] = (rec.masteredManuals || []).slice();
      });
      // 有已学：60% 相关，40% 广义（本学科随机）
      // 无已学：全学科随机
      let pool = [];
      const learnedSects = sects.filter(s => (masteredBySect[s] || []).length > 0);
      if (learnedSects.length) {
        const roll = Math.random();
        const sect = learnedSects[Math.floor(Math.random() * learnedSects.length)];
        const bank = banks[sect] || [];
        if (roll < 0.6) {
          const set = new Set(masteredBySect[sect]);
          pool = bank.filter(q => q && q.manualId && set.has(q.manualId));
          if (!pool.length) pool = bank;
        } else {
          pool = bank;
        }
        if (!pool.length) {
          // 兜底：所有学科合并
          sects.forEach(s => { pool = pool.concat(banks[s] || []); });
        }
      } else {
        sects.forEach(s => { pool = pool.concat(banks[s] || []); });
      }
      if (!pool.length) return null;
      // 学过的（如果有）里避免最近答过的（用心魔录中最近记录避免立即重复）
      const q = pool[Math.floor(Math.random() * pool.length)];
      return q;
    };

    // 提交答案 —— 走唯一权威 judgeAnswer
    Game.submitCaveAnswer = function (q, userAns) {
      if (!q) return { ok: false, msg: '未取到题目' };
      if (!this.canMeditate()) {
        const rem = this.getCaveCooldownRemaining();
        if (this.getCaveDailyRemain() <= 0) {
          return { ok: false, msg: '今日闭关次数已满（10/10），明日再来' };
        }
        return { ok: false, msg: `静心中（还需 ${Math.ceil(rem / 60000)} 分钟）` };
      }

      const correct = this.judgeAnswer ? this.judgeAnswer(q, userAns) : false;
      const cv = this.state.cave;
      cv.lastMeditateAt = Date.now();
      cv.dailyCount = (cv.dailyCount || 0) + 1;

      const c = this.state.char;
      const realmMul = this.getRealmMultiplier ? this.getRealmMultiplier() : 1;
      const caveLv = cv.level || 1;
      // 温和曲线：1.35 × 洞府等级增益（不叠加境界指数暴涨）
      const caveMul = 1 + 0.08 * (caveLv - 1);      // Lv1=1.0, Lv5=1.32
      const baseExp = 60 * caveMul * realmMul;

      let result;
      if (correct) {
        const expGain = Math.round(baseExp * 1.35);
        const shiGain = 5 + Math.floor(Math.random() * 6);   // 5-10
        this.addExp(expGain);
        this.addLingshi(shiGain);
        this.changeDaoxin(+3);
        c.hp = Math.min(c.maxHp, c.hp + 20);
        c.mp = Math.min(c.maxMp, c.mp + 20);
        result = {
          ok: true, correct: true,
          msg: `✨ 答对！修为 +${expGain.toLocaleString()}，灵石 +${shiGain}，道心 +3，HP/MP +20`,
          expGain, shiGain, correct: true, explain: q.explain || ''
        };
      } else {
        c.hp = Math.min(c.maxHp, c.hp + 5);
        this.changeDaoxin(-2);
        result = {
          ok: true, correct: false,
          msg: `❌ 答错了。心浮气躁，道心 -2，HP +5`,
          correct: false, explain: q.explain || '',
          rightAnswer: q.answer
        };
        // 加入心魔录
        if (this.addHeartDemon) {
          try { this.addHeartDemon(q); } catch (e) { /* ignore */ }
        }
      }
      // 记录已答统计
      c.totalAnswered = (c.totalAnswered || 0) + 1;
      if (correct) c.totalCorrect = (c.totalCorrect || 0) + 1;
      this.emit && this.emit('answer', { q, correct, place: 'cave' });
      this.save();
      return result;
    };

    // 兼容原 API：Game.meditate() 保留，但不再直接给奖励
    // —— 这样旧代码/成就 check 不会因为方法不存在崩溃。
    Game.meditate = function () {
      return { ok: false, msg: '洞府已改为「闭关问道」，请从主页四宫格点击洞府答题。' };
    };

    // upgradeCave 保留（可以升级但代价指数递增）
    if (!Game._origUpgradeCave) Game._origUpgradeCave = Game.upgradeCave;

    LOG('✅ Bug 2 · 洞府改为「闭关问道」（答题得修为，全题型，3min CD，日 10 次）');
    return true;
  }

  // =================================================================
  // 【Bug 1】四宫格 → 一次性 document 事件委托
  // 【Bug 2 UI】洞府弹窗 → 闭关问道题目 UI
  // =================================================================
  function patchUI() {
    if (!global.UI || !global.Game) return false;
    const UI = global.UI;
    const Game = global.Game;

    // ---- 1a. bindFourGrid 改为 no-op（避免双绑）----
    UI.bindFourGrid = function () { /* v4.3.6a: 已改为 document 委托，此处不再挂 onclick */ };

    // ---- 1b. 挂一次 document 委托（幂等）----
    if (!document.__v436aGridDelegated) {
      document.__v436aGridDelegated = true;
      document.addEventListener('click', function (e) {
        const el = e.target && (e.target.closest && e.target.closest('[data-open]'));
        if (!el) return;
        // 只处理在主页四宫格里的点击（避免误伤 modal 内的元素）
        if (!el.closest('.xx-four-grid')) return;
        const key = el.getAttribute('data-open');
        if (!UI || !key) return;
        try {
          if      (key === 'cave')     UI._openCaveModal && UI._openCaveModal();
          else if (key === 'secret')   UI._openSecretModal && UI._openSecretModal();
          else if (key === 'artifact') UI._openArtifactModal && UI._openArtifactModal();
          else if (key === 'daily')    UI._openDailyModal && UI._openDailyModal();
          else if (key === 'gear')     UI._openArtifactModal && UI._openArtifactModal('gear');
          else if (key === 'pill')     UI._openArtifactModal && UI._openArtifactModal('pill');
          else if (key === 'pet')      UI._openArtifactModal && UI._openArtifactModal('pet');
          else if (key === 'achv')     UI._openAchvModal && UI._openAchvModal();
        } catch (err) {
          console.error('[v4.3.6a] 四宫格打开失败', key, err);
          UI.toast && UI.toast('打开失败：' + (err && err.message), 'error');
        }
      }, false);
    }

    // ---- 1c. 覆盖 _openCaveModal → 闭关问道 UI ----
    UI._openCaveModal = function () {
      const inst = UI.modal({
        title: '🏔 洞府 · 闭关问道',
        body: renderCaveQuiz(),
        actions: [{ label: '关闭', primary: true }]
      });
      const body = inst && inst.m && inst.m.querySelector('.xx-modal-body');
      if (body) bindCaveQuiz(body);
    };

    function renderCaveQuiz() {
      const cv = Game.state.cave || { level: 1 };
      const canGo = Game.canMeditate();
      const remain = Game.getCaveDailyRemain();
      const cdLeft = Math.ceil(Game.getCaveCooldownRemaining() / 60000);
      const upCost = Math.round(500 * Math.pow(2.2, (cv.level || 1) - 1));

      let quizHtml = '';
      if (canGo) {
        const q = Game.getCaveRandomQuestion();
        if (!q) {
          quizHtml = `<div style="text-align:center;padding:22px;color:#f39c56;">
            当前尚未收录题目 —— 请先在宗门参悟功法解锁题库</div>`;
        } else {
          // 存到 DOM 上供 bind 用
          quizHtml = renderQuestion(q);
        }
      } else if (remain <= 0) {
        quizHtml = `<div style="text-align:center;padding:22px;color:var(--xx-text-dim);">
          🌙 今日闭关次数已用尽（10/10）<br/>明日重新开放</div>`;
      } else {
        quizHtml = `<div style="text-align:center;padding:22px;color:var(--xx-text-dim);">
          ⏳ 静心冷却中，还需 <b style="color:#f5c97a">${cdLeft}</b> 分钟</div>`;
      }

      return `
        <div class="cave-stage" style="background:linear-gradient(180deg,#0f1a2e,#1a2340);border-radius:10px;padding:16px;">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
            <div>
              <div style="font-size:18px;color:#6ed5e0;font-weight:700;">
                ${cv.level >= 5 ? '飞升宝殿' : (cv.level >= 3 ? '灵气洞府' : '修士石洞')}
              </div>
              <div style="font-size:12px;color:var(--xx-text-dim);">洞府等级 Lv.${cv.level || 1}</div>
            </div>
            <div style="text-align:right;font-size:12px;color:var(--xx-text-dim);">
              今日闭关：<b style="color:#f5c97a">${DAILY_MAX_LABEL - remain}/${DAILY_MAX_LABEL}</b><br/>
              下次冷却：3 分钟
            </div>
          </div>
          <div style="font-size:12px;color:#8ce28c;line-height:1.6;margin-bottom:10px;">
            💡 闭关规则：答 1 道题，答对奖励基础修为 × 1.35 + 5~10 灵石 + 恢复 HP/MP 20 + 道心 +3；<br/>
            答错扣 2 道心并加入心魔录；无论对错，冷却 3 分钟。
          </div>
          <div id="cave-quiz-body">${quizHtml}</div>
          <div style="margin-top:12px;text-align:center;">
            <button class="iv-btn ghost" id="cave-upgrade-btn">
              ⏫ 升级洞府（${upCost.toLocaleString()} 灵石）
            </button>
          </div>
        </div>
      `;
    }

    const DAILY_MAX_LABEL = 10;

    function renderQuestion(q) {
      const type = q.type || 'single';
      const stem = q.q || q.stem || '';
      let inputHtml = '';
      if (type === 'single' || type === 'judge') {
        const opts = q.options || (type === 'judge' ? ['A. 正确', 'B. 错误'] : []);
        inputHtml = opts.map((o, i) => {
          const letter = String.fromCharCode(65 + i);
          return `<label class="cave-opt" data-ans="${letter}" style="display:block;padding:9px 12px;margin:6px 0;border:1px solid var(--xx-border);border-radius:6px;cursor:pointer;background:rgba(255,255,255,0.03);">
            <input type="radio" name="cave-ans" value="${letter}" style="margin-right:8px;">
            ${o}
          </label>`;
        }).join('');
      } else if (type === 'multi') {
        const opts = q.options || [];
        inputHtml = opts.map((o, i) => {
          const letter = String.fromCharCode(65 + i);
          return `<label class="cave-opt" data-ans="${letter}" style="display:block;padding:9px 12px;margin:6px 0;border:1px solid var(--xx-border);border-radius:6px;cursor:pointer;background:rgba(255,255,255,0.03);">
            <input type="checkbox" name="cave-ans" value="${letter}" style="margin-right:8px;">
            ${o}
          </label>`;
        }).join('');
      } else if (type === 'fill' || type === 'calc' || type === 'solve' || type === 'essay') {
        const rows = (type === 'solve' || type === 'essay') ? 4 : 2;
        inputHtml = `<textarea id="cave-fill" rows="${rows}" placeholder="请填写答案（可对照解析自评）..."
          style="width:100%;padding:9px;border:1px solid var(--xx-border);border-radius:6px;background:rgba(255,255,255,0.04);color:var(--xx-text);font-family:inherit;"></textarea>`;
      } else {
        inputHtml = `<textarea id="cave-fill" rows="2" style="width:100%;padding:9px;border:1px solid var(--xx-border);border-radius:6px;background:rgba(255,255,255,0.04);color:var(--xx-text);"></textarea>`;
      }

      // AutoViz 提示图（如果有）
      let vizHtml = '';
      if (global.AutoViz && global.AutoViz.render) {
        try { vizHtml = global.AutoViz.render(q) || ''; } catch (e) {}
      }

      return `
        <div class="cave-question" data-qid="${q.id || ''}" data-type="${type}" data-answer="${(q.answer || '').toString().replace(/"/g, '&quot;')}">
          ${vizHtml ? `<div style="margin-bottom:10px;">${vizHtml}</div>` : ''}
          <div style="font-size:14px;line-height:1.7;color:var(--xx-text);margin-bottom:10px;">
            <b style="color:#f5c97a;">【${labelOfType(type)}】</b> ${stem}
          </div>
          <div class="cave-opts">${inputHtml}</div>
          <div style="margin-top:12px;display:flex;gap:8px;">
            <button class="iv-btn" id="cave-submit">🗡 提交答案</button>
            <button class="iv-btn ghost" id="cave-skip">🔄 换一题</button>
          </div>
          <div id="cave-result" style="margin-top:10px;"></div>
        </div>
      `;
    }
    function labelOfType(t) {
      return ({ single: '单选', multi: '多选', judge: '判断', fill: '填空', calc: '计算', solve: '解答', essay: '论述' })[t] || '选择';
    }

    function bindCaveQuiz(body) {
      // 升级按钮
      const upBtn = body.querySelector('#cave-upgrade-btn');
      if (upBtn) {
        upBtn.onclick = () => {
          const r = Game._origUpgradeCave ? Game._origUpgradeCave() : Game.upgradeCave();
          UI.toast(r.msg, r.ok ? 'success' : 'error');
          if (r.ok) {
            body.innerHTML = renderCaveQuiz();
            bindCaveQuiz(body);
          }
        };
      }
      // 提交按钮
      const submitBtn = body.querySelector('#cave-submit');
      const skipBtn = body.querySelector('#cave-skip');
      const resultBox = body.querySelector('#cave-result');
      const qBox = body.querySelector('.cave-question');
      if (!submitBtn || !qBox) return;

      // 选项 hover 效果
      body.querySelectorAll('.cave-opt').forEach(l => {
        l.addEventListener('click', () => {
          body.querySelectorAll('.cave-opt').forEach(x => x.style.borderColor = 'var(--xx-border)');
          l.style.borderColor = '#f5c97a';
        });
      });

      submitBtn.onclick = () => {
        const qid = qBox.dataset.qid;
        const type = qBox.dataset.type;
        // 找到实际的 q 对象
        const q = findQuestionById(qid) || {
          id: qid, type, answer: qBox.dataset.answer,
          q: qBox.querySelector('div[style*="font-size:14px"]') ?
             qBox.querySelector('div[style*="font-size:14px"]').innerText : ''
        };

        let userAns;
        if (type === 'single' || type === 'judge') {
          const picked = body.querySelector('input[name="cave-ans"]:checked');
          if (!picked) { UI.toast('请先选择一个答案', 'warn'); return; }
          userAns = picked.value;
        } else if (type === 'multi') {
          const picks = Array.from(body.querySelectorAll('input[name="cave-ans"]:checked')).map(x => x.value).sort();
          if (!picks.length) { UI.toast('请至少选择一个答案', 'warn'); return; }
          userAns = picks.join('');
        } else {
          const t = body.querySelector('#cave-fill');
          if (!t || !t.value.trim()) { UI.toast('请填写答案', 'warn'); return; }
          userAns = t.value.trim();
        }

        const r = Game.submitCaveAnswer(q, userAns);
        submitBtn.disabled = true;
        if (skipBtn) skipBtn.textContent = '➡ 下一题（3 分钟后）';

        const color = r.correct ? '#8ce28c' : '#ff9a9a';
        resultBox.innerHTML = `
          <div style="padding:10px;border-radius:6px;background:rgba(255,255,255,0.05);border:1px solid ${color};">
            <div style="color:${color};font-weight:700;margin-bottom:4px;">${r.msg}</div>
            ${r.explain ? `<div style="font-size:12px;color:var(--xx-text-dim);line-height:1.7;">
              <b>解析：</b>${r.explain}
              ${r.rightAnswer ? `<br/><b>参考答案：</b><span style="color:#f5c97a;">${r.rightAnswer}</span>` : ''}
            </div>` : ''}
          </div>
        `;
      };

      if (skipBtn) {
        skipBtn.onclick = () => {
          // 换一题 = 重绘 quiz 部分
          const holder = body.querySelector('#cave-quiz-body');
          if (holder) {
            if (!Game.canMeditate()) {
              body.innerHTML = renderCaveQuiz();
              bindCaveQuiz(body);
              return;
            }
            const q = Game.getCaveRandomQuestion();
            holder.innerHTML = q ? renderQuestion(q) : '<div style="padding:22px;text-align:center;color:#f39c56;">题库为空</div>';
            bindCaveQuiz(body);
          }
        };
      }
    }

    function findQuestionById(qid) {
      if (!qid) return null;
      const banks = [
        global.PHYSICS_BANK, global.CHEMISTRY_BANK, global.GEOGRAPHY_BANK,
        global.CHINESE_BANK, global.MATH_BANK, global.ENGLISH_BANK
      ];
      for (const b of banks) {
        if (!Array.isArray(b)) continue;
        const q = b.find(x => x && x.id === qid);
        if (q) return q;
      }
      return null;
    }

    LOG('✅ Bug 1 · 四宫格改为 document 事件委托（永不失灵）');
    LOG('✅ Bug 2 · 洞府弹窗改为闭关问道（支持 single/multi/judge/fill/calc/solve/essay）');
    return true;
  }

  // =================================================================
  // 【Bug 5】AutoViz：给每个 manualId 生成"专属装饰环"
  // =================================================================
  function patchAutoViz() {
    if (!global.AutoViz) return false;
    const AV = global.AutoViz;

    // 学科色 & 符号
    const SECT_STYLE = {
      physics:   { color: '#7fb3ff', color2: '#4a7ec4', bg: '#101a2c', syms: ['F', 'v', 'E', 'B', 'q', 'a', 'λ', '⇌', 'ω'] },
      chemistry: { color: '#ff9a5e', color2: '#c46a3c', bg: '#2a1810', syms: ['H', 'O', 'C', 'N', '⇌', '△', 'e⁻', 'pH', 'Na'] },
      geography: { color: '#8ce28c', color2: '#4b9a4b', bg: '#0f2418', syms: ['☀', '🌊', '🌀', '⛰', '❄', '☁', '↺', '°'] },
      chinese:   { color: '#ff9ec6', color2: '#c46a90', bg: '#2a1020', syms: ['文', '诗', '词', '曲', '赋', '经', '之', '也'] },
      math:      { color: '#b288ff', color2: '#7a4ec4', bg: '#1a1030', syms: ['x', 'y', '∫', '∑', '√', 'π', '∞', 'sin'] },
      english:   { color: '#f5c97a', color2: '#c49848', bg: '#2a2010', syms: ['A', 'B', 'C', 'D', 'E', 'F', '?', 'ing'] }
    };

    function hashCode(s) {
      let h = 0;
      s = String(s || '');
      for (let i = 0; i < s.length; i++) {
        h = ((h << 5) - h) + s.charCodeAt(i);
        h |= 0;
      }
      return Math.abs(h);
    }

    function sectFrom(q) {
      const mid = (q && q.manualId) || '';
      if (mid.startsWith('phy_')) return 'physics';
      if (mid.startsWith('chem_')) return 'chemistry';
      if (mid.startsWith('geo_')) return 'geography';
      if (mid.startsWith('chi_')) return 'chinese';
      if (mid.startsWith('math_')) return 'math';
      if (mid.startsWith('eng_')) return 'english';
      if (q && q.sect) return q.sect;
      const id = (q && q.id) || '';
      if (id.startsWith('P')) return 'physics';
      if (id.startsWith('C')) return 'chemistry';
      if (id.startsWith('G')) return 'geography';
      return 'physics';
    }

    // 专属装饰环：SVG，学科色 + 学科符号 + 固定角度（同一 manualId 永远同一张）
    function makeDedicatedRing(q) {
      const mid = (q && q.manualId) || (q && q.id) || 'x';
      const sect = sectFrom(q);
      const S = SECT_STYLE[sect] || SECT_STYLE.physics;
      const seed = hashCode(mid);
      const W = 480, H = 200;
      const cx = W / 2, cy = H / 2;
      const R1 = 62, R2 = 82;
      const symCount = 12;

      // 生成符号环
      const rot = seed % 360;
      let symbols = '';
      for (let i = 0; i < symCount; i++) {
        const angle = (i * 360 / symCount + rot) * Math.PI / 180;
        const x = cx + Math.cos(angle) * ((R1 + R2) / 2);
        const y = cy + Math.sin(angle) * ((R1 + R2) / 2);
        const sym = S.syms[(seed + i) % S.syms.length];
        symbols += `<text x="${x.toFixed(1)}" y="${y.toFixed(1)}" fill="${S.color}" font-size="14" text-anchor="middle" dominant-baseline="central" font-family="serif" opacity="0.85">${sym}</text>`;
      }

      // 装饰刻度
      let ticks = '';
      const tickCount = 36;
      for (let i = 0; i < tickCount; i++) {
        const angle = (i * 360 / tickCount) * Math.PI / 180;
        const x1 = cx + Math.cos(angle) * (R2 + 4);
        const y1 = cy + Math.sin(angle) * (R2 + 4);
        const x2 = cx + Math.cos(angle) * (R2 + (i % 3 === 0 ? 12 : 7));
        const y2 = cy + Math.sin(angle) * (R2 + (i % 3 === 0 ? 12 : 7));
        ticks += `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="${S.color2}" stroke-width="1"/>`;
      }

      // 三角光晕（阴阳鱼式的能量流）
      const petals = 6;
      let petalPath = '';
      for (let i = 0; i < petals; i++) {
        const a = (i * 360 / petals + (seed % 60)) * Math.PI / 180;
        const px = cx + Math.cos(a) * 40;
        const py = cy + Math.sin(a) * 40;
        petalPath += `<circle cx="${px.toFixed(1)}" cy="${py.toFixed(1)}" r="8" fill="${S.color}" opacity="0.18"/>`;
      }

      const centerLabel = shortLabel(mid);
      const idTag = (seed % 9999).toString().padStart(4, '0');

      const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="100%">
        <defs>
          <radialGradient id="bg-${seed % 999}" cx="50%" cy="50%" r="70%">
            <stop offset="0%" stop-color="${S.color}" stop-opacity="0.14"/>
            <stop offset="100%" stop-color="${S.bg}" stop-opacity="0.65"/>
          </radialGradient>
        </defs>
        <rect width="100%" height="100%" fill="url(#bg-${seed % 999})" rx="8"/>
        ${ticks}
        <circle cx="${cx}" cy="${cy}" r="${R2}" fill="none" stroke="${S.color}" stroke-width="1.5" opacity="0.7"/>
        <circle cx="${cx}" cy="${cy}" r="${R1}" fill="none" stroke="${S.color2}" stroke-width="1" stroke-dasharray="3,3" opacity="0.6"/>
        ${petalPath}
        <circle cx="${cx}" cy="${cy}" r="30" fill="${S.bg}" stroke="${S.color}" stroke-width="1.5"/>
        <text x="${cx}" y="${cy - 2}" fill="${S.color}" font-size="16" text-anchor="middle" dominant-baseline="central" font-family="STKaiti,KaiTi,serif" font-weight="700">${centerLabel}</text>
        <text x="${cx}" y="${cy + 14}" fill="${S.color2}" font-size="8" text-anchor="middle" font-family="monospace" opacity="0.8">#${idTag}</text>
        ${symbols}
      </svg>`;
      const shortId = String(mid).replace(/^(phy|chem|geo|math|chi|eng)_/, '');
      const tag = `<div style="font-size:10px;color:var(--xx-text-dim);letter-spacing:2px;text-align:right;margin-top:-4px;margin-bottom:4px;">◈ ${shortId} · #${idTag} ◈</div>`;
      return `<div class="viz-panel">${tag}${svg}</div>`;
    }

    // 提取 manualId 里最能代表主题的短标签
    function shortLabel(mid) {
      const m = String(mid);
      // 去掉学科前缀，取第 1 段（比如 phy_kinematics_01 → 运动 / 运动学）
      const clean = m.replace(/^(phy|chem|geo|math|chi|eng)_/, '').split('_')[0] || '功法';
      // 常见词典化（帮助显示中文）
      const DICT = {
        kinematics: '运动', dynamics: '力学', force: '受力', vibration: '振动',
        wave: '波动', optic: '光学', dcslit: '干涉', emf: '电磁', magnetic: '磁场',
        ac: '交流', molecule: '分子', gas: '气体', thermo: '热学', solid: '固体',
        energy: '能量', rate: '速率', equilib: '平衡', ph: 'pH', electro: '电化',
        bond: '键', vsepr: '构型', crystal: '晶体', organic: '有机', periodic: '周期',
        earth: '地球', ocean: '海洋', atmosphere: '大气', climate: '气候',
        agriculture: '农业', industry: '工业', population: '人口', city: '城市',
        river: '河流', volcano: '火山', rock: '岩石', soil: '土壤'
      };
      if (DICT[clean]) return DICT[clean];
      // 兜底：取前 2 个字符（如果是中文）或前 3 个英文字母
      if (/[\u4e00-\u9fa5]/.test(clean)) return clean.slice(0, 2);
      return (clean.charAt(0).toUpperCase() + clean.slice(1, 3)).slice(0, 3);
    }

    // 关键：覆盖 render，让"匹配到"的走原图，"匹配不到"的走专属装饰环
    if (!AV.__v436aWrapped) {
      const origRender = AV.render.bind(AV);
      AV.render = function (q) {
        if (!q) return '';
        // 先尝试原本的 render（如果它内部匹配到了明确的 GEN，会正常返回带图的 HTML）
        let out = '';
        try { out = origRender(q); } catch (e) { out = ''; }
        // 判定"是否是有意义的图" —— 空串 或 只含 fallback 的极简图 → 用专属装饰环替代
        if (!out || out.trim() === '' || /_fallback/.test(out)) {
          return makeDedicatedRing(q);
        }
        // 如果原本没有匹配 sect/manualId（去掉了 _fallback 情况）返回了空，也用专属图
        return out || makeDedicatedRing(q);
      };
      AV.forQuestion = function (q) { return AV.render(q); };
      AV.__v436aWrapped = true;
    }

    LOG('✅ Bug 5 · AutoViz 兜底 → 每个 manualId 都有专属装饰环（学科色 + 符号 + 固定角度）');
    return true;
  }

  // =================================================================
  // 启动
  // =================================================================
  whenReady(function boot() {
    try { patchAchievements(); } catch (e) { WARN('achievements 补正失败', e); }
    try { patchMonster();      } catch (e) { WARN('monster 补正失败', e); }
    try { patchCave();         } catch (e) { WARN('cave 补正失败', e); }
    try { patchUI();           } catch (e) { WARN('UI 补正失败', e); }
    try { patchAutoViz();      } catch (e) { WARN('autoviz 补正失败', e); }

    // 主页 achievementUnlock 的 toast 监听：v4.3.6a 里已由 emit 层聚合处理，
    // 这里显式移除旧的、直接绑在事件上的 toast handler，避免双吐司
    if (global.Game && Array.isArray(global.Game.listeners && global.Game.listeners.achievementUnlock)) {
      // Game.on 通常把 handler 放进 listeners[event]，全部清空由 emit 层的批处理接管
      global.Game.listeners.achievementUnlock = [];
    }

    // 存档兜底：如果 cave.dailyDate 不存在，补上
    if (global.Game && global.Game.state && global.Game.state.cave) {
      const cv = global.Game.state.cave;
      if (!cv.dailyDate) {
        cv.dailyDate = new Date().toISOString().slice(0, 10);
        cv.dailyCount = 0;
        global.Game.save && global.Game.save();
      }
    }

    LOG('🎉 v4.3.6a 完全重置版 已就绪：5 大 Bug 全部收敛，无叠加 hotfix。');
  });

})(window);
