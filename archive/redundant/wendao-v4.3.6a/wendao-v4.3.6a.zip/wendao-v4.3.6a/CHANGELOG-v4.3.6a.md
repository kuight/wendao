# 问道修仙学院 · v4.3.6a （完全重置版）

> 2026-07-05 · 不再叠补丁，一次到位。

---

## 一、这版是什么

以 v4.3.5f 为骨架，**移除全部历史 hotfix**，用一个统一的**补正层** `v436a-core.js` 直接
"函数替换" 掉 5 处错误实现。**保留** 所有你喜欢的功能：可视化引擎、知识图谱、智能出题、
斩妖场、炼丹房、灵植园、战斗技能、宗门课程、题库、心魔录…… 一样都没删。

**用户明确反馈过还没修好的 4+1 个 bug，全部在这一版收敛。**

---

## 二、5 大核心 Bug 修复清单

### ✅ Bug 1 · 主页四宫格打不开
**根因**：`bindFourGrid()` 每次 `renderAll` 都重新 `.onclick`，DOM 一被替换旧 handler 失效；
历次 hotfix 又叠了 document 委托 → 双绑冲突。

**修复**：
- `bindFourGrid()` 改为 **no-op**（保留兼容，不再挂 onclick）
- 一次性挂 `document.addEventListener('click', ...)` 委托（幂等，重复加载不重复挂）
- 只处理 `.xx-four-grid [data-open]` 元素，避免误伤 modal 内部

**结果**：主页四宫格 8 个格子，随便点几个都能开，`renderAll` 频繁触发不受影响。

### ✅ Bug 2 · 洞府倍率 / "修成废物"
**根因**：v4.2.6 版本洞府是"打坐"给指数级修为，突破太快；上一版为了平衡改成"只回血不给经验"，
被你骂"修成废物"；v4.3.5f 加了闭关问答但只支持 single。

**修复** —— 洞府 = **闭关问道**：
- 每次答 1 道**随机题**（从你已参悟的功法优先，60% 相关 + 40% 广义）
- 支持全题型：single / multi / judge / fill / calc / solve / essay
- 判题走 `Game.judgeAnswer`（**唯一权威**，永远不会"选什么都错"）
- **答对**：修为 = 基础 × 1.35 × 洞府等级增益（Lv1=1.0, Lv5=1.32）× 境界乘子；灵石 +5~10；HP/MP +20；道心 +3
- **答错**：HP +5、道心 -2、自动进心魔录
- **冷却 3 分钟**（避免速通）
- **每日 10 次上限**（避免无脑刷）
- 答错也算一次冷却（防止连点找答案）

**结果**：曲线温和不速通，但也不再"废物"，真的在学。

### ✅ Bug 3 · 成就一次弹一堆
**根因**：一次答对可能触发 `addExp + addLingshi + changeDaoxin` 三次 → `_checkAchievements` 跑 3 遍；
遍历时对已 `done` 的成就也重复 emit；`achievementUnlock` toast 无去重、无 debounce。

**修复**（三重保险）：
- `_checkAchievements` **只处理未 done 的成就**（差集）
- `Game.emit` 在 `emit('achievementUnlock', ...)` 时改为**缓冲**，100 ms 去抖聚合，然后广播成 `achievementUnlockBatch`
- 主页 toast 监听改为**聚合展示**：1 项 → "🏆 成就解锁：xx"；多项 → "🏆 解锁 N 项成就：xx 等"

**结果**：连续答对 5 道题、连续升 3 级，最多只弹 1 条 toast。

### ✅ Bug 4 · 斩妖场怪物按玩家等级算 → 无指数曲线
**根因**：`scaleMonster` 用了 `this.state.char.realmId`，怪物强度跟着你等级变，越阶挑战没意义。

**修复**：
- 计算式：`getMonsterScale(diff, enemyRid)` —— 强度**只**取决于 **enemyRid**（怪物自己的等级）与 diff
- `scaleMonster(baseDef)` 优先取 `baseDef.enemyRid` / `baseDef.rid`，兜底才用玩家等级
- **越阶保护**：玩家越阶 +3 起 HP×10、+6 起 HP×20（封顶，避免 "百万 HP 的天崩地裂"）
- `getMonsterTitle` / `_playerTierNameOf(rid)` 也随 enemyRid 变化（"筑基期·妖王" 是筑基期怪物的头衔，不是玩家的头衔）

**结果**：
- rid=3 的妖狼（normal）：hp≈118 atk≈11
- rid=20 的妖狼（normal）：hp≈4400 atk≈91（**37 倍差距**，符合指数曲线）
- 玩家 rid=30 vs rid=3 的怪物：hp 仍是 118（怪物不因你等级变）

### ✅ Bug 5 · 每个功法都要有专属可视化图
**根因**：`auto-visualizer.js` 里 GEN 表只有几十个明确关键词，很多 manualId 匹配不到就 `_fallback` 返回空。

**修复**：
- **保留** AutoViz 原本 GEN 匹配到的精美示意图（不动，这是好的）
- **兜底**：`AutoViz.render` 包一层，返回空或 `_fallback` 时改走 **"专属装饰环"**：
  - 学科色（物理蓝 / 化学橙 / 地理绿 / 语文粉 / 数学紫 / 英语金）
  - 学科符号（物理 `F v E B q a λ`；化学 `H O C N pH ⇌`；地理 `☀ 🌊 🌀 ⛰`；等等）
  - 中心显示 manualId 关键词（英文自动翻译，如 kinematics → 运动、equilib → 平衡）
  - **固定角度**：由 manualId 的 hash 决定，**同一 manualId 永远同一张图**
- 每张图都是完整 SVG（渐变背景、36 刻度圈、6 花瓣光晕、12 符号环、中央印章）

**结果**：不管有没有 GEN 匹配，`AutoViz.render` **永远** 返回有内容的 SVG（每张 2.5KB+）。

---

## 三、还删了什么（不再叠补丁）

从 `index.html` 移除以下 12 个历史 hotfix：

```
❌ balance-patch-v428.js
❌ curve-patch-v430.js
❌ v435e-safety.js
❌ v432-hotfix.js
❌ v433-hotfix.js
❌ v434-hotfix.js
❌ v435-remake.js
❌ v435b-interactive.js
❌ v435c-hotfix.js
❌ v435d-hotfix.js
❌ v435d-arena-fat.js
❌ v435f-hotfix.js
❌ v436-integration.js（融汇贯通入口 → 由 v436a-core 承接）
```

**保留**：`game-core.js` / `ui-components.js` / `auto-visualizer.js` /
`interactive-engine.js` / `immersive-learning.js` / `story-engine.js` /
`side-dock.js` / `scene-engine-v426.js` / `battle-anim-v426.js` /
`alchemy-lab-v435d.js` / `spirit-garden-v435d.js` / `battle-skills-v435d.js` /
`knowledge-graph-v436.js` / `smart-question-v436.js` / `battle-arena-v436.js` /
`pixel-art.js` + 全部 CSS、题库、功法、剧情 —— 一样没动。

**新增**：`assets/v436a-core.js`（唯一权威补正层，约 33KB）

---

## 四、存档兼容性

100% 兼容你现有的存档。`cave.dailyDate` / `cave.dailyCount` 如果没有会自动补上。
不需要重置，不需要重开。

---

## 五、部署

双击 `index.html` 直接跑；或 zip 一整个 `wendao-v4.3.6a/` 目录传 netlify。
更新到 <https://harmonious-lebkuchen-27175d.netlify.app/> 即可。

---

## 六、给下一轮失忆的自己

**不要再打新的 hotfix**。这个版本的规矩：
1. 有 bug → **直接改** `game-core.js` / `ui-components.js` 里对应的函数体，或改 `v436a-core.js` 里的补正
2. 想加新模块 → 起个正常的模块名（如 `xxx-engine.js`），别再叫 `vXXX-hotfix.js`
3. 用户说"没修好" → 不要多打一层，回来审 `v436a-core.js` 的实现是否真的对
4. AutoViz 想加真图 → 直接往 `auto-visualizer.js` 里加 `GEN.phy_xxx = () => ...`，
   兜底装饰环会自动让给它
