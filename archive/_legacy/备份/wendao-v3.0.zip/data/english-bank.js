/* ===================================================
 * 译灵堂·英语妖兽题库 v1.0
 * =================================================== */

window.ENGLISH_BANK = [

  // ===== en_m1 时态语态 =====
  { id:'en_q1_1', manualId:'en_m1', type:'single', difficulty:'easy', monster:'时态小妖',
    q:'— Where is Tom? — He ____ to the library.',
    options:[
      {k:'A', v:'has gone'},
      {k:'B', v:'has been'},
      {k:'C', v:'went'},
      {k:'D', v:'goes'}
    ],
    answer:'A',
    explain:'has gone to = "已经去了某地（现在不在)"，has been to = "曾经去过(现在已回来)"。Tom 不在所以用 has gone to。'
  },
  { id:'en_q1_2', manualId:'en_m1', type:'single', difficulty:'normal', monster:'过去完成妖',
    q:'By the time he arrived, the meeting ____.',
    options:[
      {k:'A', v:'has ended'},
      {k:'B', v:'had ended'},
      {k:'C', v:'ended'},
      {k:'D', v:'was ending'}
    ],
    answer:'B',
    explain:'by the time + 过去时从句 → 主句用过去完成时（表示"过去的过去"——他到达之前会议已经结束了）。'
  },
  { id:'en_q1_3', manualId:'en_m1', type:'single', difficulty:'normal', monster:'被动妖',
    q:'The bridge ____ next year.',
    options:[
      {k:'A', v:'will build'},
      {k:'B', v:'will be built'},
      {k:'C', v:'is built'},
      {k:'D', v:'was built'}
    ],
    answer:'B',
    explain:'桥是被建造的（被动）+ next year 将来时 → will be built。'
  },

  // ===== en_m2 从句 =====
  { id:'en_q2_1', manualId:'en_m2', type:'single', difficulty:'normal', monster:'定语从句妖',
    q:'This is the house ____ I lived ten years ago.',
    options:[
      {k:'A', v:'which'},
      {k:'B', v:'that'},
      {k:'C', v:'where'},
      {k:'D', v:'when'}
    ],
    answer:'C',
    explain:'live in the house，从句缺地点状语 → 用 where。如选 which/that，则原句应为 "the house which I lived <b>in</b>"。'
  },
  { id:'en_q2_2', manualId:'en_m2', type:'single', difficulty:'normal', monster:'名词从句妖',
    q:'____ surprised me most was his attitude.',
    options:[
      {k:'A', v:'That'},
      {k:'B', v:'What'},
      {k:'C', v:'Which'},
      {k:'D', v:'It'}
    ],
    answer:'B',
    explain:'主语从句，从句缺主语（surprised 缺主语）→ 用 what（=the thing that）。that 引导主语从句时不能省略且本身不作成分。'
  },
  { id:'en_q2_3', manualId:'en_m2', type:'single', difficulty:'hard', monster:'同位语妖',
    q:'The news ____ our team won the championship excited everyone.',
    options:[
      {k:'A', v:'that'},
      {k:'B', v:'which'},
      {k:'C', v:'what'},
      {k:'D', v:'whether'}
    ],
    answer:'A',
    explain:'解释 news 的具体内容，是同位语从句，用 that（仅作连接，不充当成分）。后面 our team won 是完整句子。'
  },

  // ===== en_m3 非谓语 =====
  { id:'en_q3_1', manualId:'en_m3', type:'single', difficulty:'normal', monster:'分词妖',
    q:'____ down the street, I met an old friend.',
    options:[
      {k:'A', v:'Walked'},
      {k:'B', v:'Walking'},
      {k:'C', v:'To walk'},
      {k:'D', v:'Walk'}
    ],
    answer:'B',
    explain:'主语 I 在 walk（主动），用现在分词 walking 作伴随状语。'
  },
  { id:'en_q3_2', manualId:'en_m3', type:'single', difficulty:'normal', monster:'过去分词妖',
    q:'The book ____ on the table is mine.',
    options:[
      {k:'A', v:'lying'},
      {k:'B', v:'lay'},
      {k:'C', v:'laying'},
      {k:'D', v:'lain'}
    ],
    answer:'A',
    explain:'book 自己"躺"在桌上（主动+正在）→ lying（lie 不及物动词的现在分词）。注意 lay 是 lay-laid-laid（放置），lie 是 lie-lay-lain（躺）。'
  },
  { id:'en_q3_3', manualId:'en_m3', type:'single', difficulty:'hard', monster:'remember妖',
    q:'I remember ____ him at the party. He looked great.',
    options:[
      {k:'A', v:'to see'},
      {k:'B', v:'seeing'},
      {k:'C', v:'see'},
      {k:'D', v:'saw'}
    ],
    answer:'B',
    explain:'remember doing = 记得已经做过的事；remember to do = 记得要去做。后句说"他看起来很棒"——是已经见过的回忆，所以 seeing。'
  },

  // ===== en_m4 词汇 =====
  { id:'en_q4_1', manualId:'en_m4', type:'single', difficulty:'normal', monster:'词性妖',
    q:'His ____ helped me a lot.（advice/advise）',
    options:[
      {k:'A', v:'advice'},
      {k:'B', v:'advise'},
      {k:'C', v:'advices'},
      {k:'D', v:'advising'}
    ],
    answer:'A',
    explain:'空格前 his (形容词性物主代词)，后跟名词。advice 是名词（不可数），advise 是动词。所以选 advice。'
  },
  { id:'en_q4_2', manualId:'en_m4', type:'single', difficulty:'normal', monster:'易混词妖',
    q:'All the students ____ Tom went to the park.',
    options:[
      {k:'A', v:'accept'},
      {k:'B', v:'except'},
      {k:'C', v:'expect'},
      {k:'D', v:'expert'}
    ],
    answer:'B',
    explain:'except = 除……之外（介词）；accept = 接受（动词）；expect = 期待；expert = 专家。"除了Tom以外，所有学生都去了"。'
  },
  { id:'en_q4_3', manualId:'en_m4', type:'fill', difficulty:'normal', monster:'词形变化妖',
    q:'用 perform 适当形式填空：His ____ in the school play impressed everyone.（提示：作主语）',
    answer:'performance',
    explain:'空格作主语，需要名词形式。perform → performance（n. 表演）。'
  },

  // ===== en_m5 阅读理解 =====
  { id:'en_q5_1', manualId:'en_m5', type:'single', difficulty:'normal', monster:'细节妖',
    q:'阅读理解做"细节题"最关键的方法是：',
    options:[
      {k:'A', v:'凭语感选最顺眼的'},
      {k:'B', v:'用关键词定位回原文，找同义改写'},
      {k:'C', v:'选最长的选项'},
      {k:'D', v:'选包含原文原词最多的选项'}
    ],
    answer:'B',
    explain:'细节题正确选项往往是原文核心句的"同义改写"（synonym paraphrase）。D是常见误区——原文原词照搬反而可能是迷惑项。'
  },
  { id:'en_q5_2', manualId:'en_m5', type:'judge', difficulty:'easy', monster:'推理妖',
    q:'判断：阅读理解中遇到 infer / suggest / imply 等词，表明是推理判断题。',
    answer:'A',
    explain:'正确。这是推理题的典型标志词。正确答案要"基于原文但又超出原文一点点"。'
  },

  // ===== en_m6 写作 =====
  { id:'en_q6_1', manualId:'en_m6', type:'single', difficulty:'easy', monster:'开头妖',
    q:'下列哪个句子最适合作为"邀请信"的开头：',
    options:[
      {k:'A', v:'I am writing to apologize for my behavior.'},
      {k:'B', v:'I am writing to apply for the position.'},
      {k:'C', v:'I am writing to invite you to my birthday party.'},
      {k:'D', v:'I am writing to complain about the service.'}
    ],
    answer:'C',
    explain:'C是邀请信。A是道歉信、B是申请信、D是投诉信。'
  },
  { id:'en_q6_2', manualId:'en_m6', type:'judge', difficulty:'normal', monster:'续写妖',
    q:'判断：读后续写为了拿高分，应该"灵魂出窍"——大胆开脑洞，写出意想不到的剧情。',
    answer:'B',
    explain:'错误。续写得分点之一是"情节合理、呼应前文"。脑洞太大反而扣分。要"顺接+升华"。'
  },

  // ===== en_m7 听力 =====
  { id:'en_q7_1', manualId:'en_m7', type:'single', difficulty:'normal', monster:'场景妖',
    q:'听到 "I\'d like to make a reservation for two at 7pm"，最可能的场景是：',
    options:[
      {k:'A', v:'in a hospital'},
      {k:'B', v:'in a restaurant'},
      {k:'C', v:'in an airport'},
      {k:'D', v:'in a library'}
    ],
    answer:'B',
    explain:'make a reservation for two = 预订两人座位，典型餐厅场景。reservation 在餐厅和酒店最常见。'
  },
  { id:'en_q7_2', manualId:'en_m7', type:'single', difficulty:'normal', monster:'信号词妖',
    q:'听力中以下哪个词后面最可能是答案重点：',
    options:[
      {k:'A', v:'because'},
      {k:'B', v:'and'},
      {k:'C', v:'but/however'},
      {k:'D', v:'also'}
    ],
    answer:'C',
    explain:'but / however / actually 是转折信号词，后面通常是说话者真正的观点或重点。出题点常常落在这里。'
  },

];
