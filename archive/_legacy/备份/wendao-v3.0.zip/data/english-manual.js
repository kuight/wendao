/* ===================================================
 * 译灵堂·英语功法秘籍 v1.0
 * 范围：必修一到必修三 Unit 3 / 选必一到选必三 Unit 3
 * =================================================== */

window.ENGLISH_MANUALS = [

  // ========== 语法基础 ==========
  {
    id: 'en_m1',
    tier: '通用',
    tag: '时态语态',
    title: '《时光真经》',
    summary: '16种时态核心用法 + 主动/被动语态的转换规律。',
    content: `
      <p><b>核心8时态记忆口诀</b>：</p>
      <ul>
        <li>一般现在：do/does — 经常性动作、客观真理 (The sun rises in the east.)</li>
        <li>一般过去：did — 过去发生的动作 (He <b>went</b> to school yesterday.)</li>
        <li>一般将来：will/be going to — 将要发生</li>
        <li>现在进行：am/is/are doing — 此刻正在 / 近期计划</li>
        <li>过去进行：was/were doing — 过去某时正在</li>
        <li>现在完成：have/has done — 对现在产生影响 (常配 already/yet/just/ever/never/since/for)</li>
        <li>过去完成：had done — "过去的过去"（常配 by the time / before）</li>
        <li>现在完成进行：have/has been doing — 从过去某时一直持续到现在</li>
      </ul>
      <p><b>被动语态</b>：be + 过去分词（done）</p>
      <ul>
        <li>一般现在被动：is/are done — (The book is written by Lu Xun.)</li>
        <li>一般过去被动：was/were done</li>
        <li>情态动词被动：can/should/must + be done</li>
        <li>完成时被动：have/has been done</li>
      </ul>
      <p><b>时态判断关键词</b>：</p>
      <ul>
        <li>now / at this moment → 现在进行</li>
        <li>yesterday / ago / last week → 一般过去</li>
        <li>since / for / already / yet → 现在完成</li>
        <li>by the time / before / when (从句过去时) → 过去完成</li>
      </ul>
    `,
    formula: '时态 = 时间(过去/现在/将来) × 状态(一般/进行/完成/完成进行)',
    tips: '看到 since 1990 / for 5 years，立刻条件反射 → 现在完成时（has/have done）。',
    example: 'By the time I got to the station, the train <b>had already left</b>. （到我到达车站，火车已经走了——"过去的过去"用过去完成时 had left）'
  },

  {
    id: 'en_m2',
    tier: '通用',
    tag: '从句',
    title: '《长句拆解诀》',
    summary: '定语从句、名词性从句、状语从句三大从句的引导词与规则。',
    content: `
      <p><b>定语从句</b>（修饰名词）：</p>
      <ul>
        <li>that / which：先行词是物，which在介词后必用which (the city in <b>which</b> I live)</li>
        <li>who / whom：先行词是人</li>
        <li>whose：表所属</li>
        <li>when：时间状语；where：地点状语；why：原因状语（只用于reason）</li>
        <li>只用 that 不用 which 的情况：先行词被all/the only/序数词修饰、先行词是 anything/everything 等不定代词</li>
      </ul>
      <p><b>名词性从句</b>（充当主/宾/表/同位语）：</p>
      <ul>
        <li>that：陈述句变从句（无意义，不能省作主语从句）</li>
        <li>whether/if：一般疑问句变从句（=是否；if 不能引导主语从句和介词后宾语从句）</li>
        <li>what/who/which/where/when/why/how：特殊疑问句变从句</li>
        <li>同位语从句：用 that 解释抽象名词 (the fact <b>that</b>...)</li>
      </ul>
      <p><b>状语从句</b>：</p>
      <ul>
        <li>时间：when, while, as, before, after, since, until, as soon as, the moment</li>
        <li>地点：where, wherever</li>
        <li>原因：because, since, as, now that</li>
        <li>目的：so that, in order that</li>
        <li>结果：so/such...that, so that</li>
        <li>条件：if, unless, as long as, on condition that</li>
        <li>让步：though/although, even if/though, no matter wh-, whatever/wherever</li>
        <li>方式：as, as if, as though</li>
        <li>比较：than, as...as</li>
      </ul>
    `,
    formula: '定语从句 = 先行词 + 关系词 + 不完整句子；名词从句 = 引导词 + 完整意义',
    tips: '区分定语从句 vs 同位语从句：定语用 that 时句子在 that 后缺主/宾/状（不完整）；同位语 that 后是完整句子，that 只是连词。',
    example: 'The news <b>that he passed the exam</b> made us happy. （that 后是完整句"他通过考试"，that 是同位语从句标志，解释 news 的内容）'
  },

  {
    id: 'en_m3',
    tier: '通用',
    tag: '非谓语动词',
    title: '《分词玄章》',
    summary: '动名词、不定式、现在分词、过去分词的用法区分。',
    content: `
      <p><b>非谓语三大形式</b>：</p>
      <ul>
        <li><b>doing</b>（动名词/现在分词）：主动 + 进行/经常</li>
        <li><b>to do</b>（不定式）：未完成/将要发生</li>
        <li><b>done</b>（过去分词）：被动 + 完成</li>
      </ul>
      <p><b>常见搭配</b>：</p>
      <ul>
        <li>only + to do：表意外结果 (He came back only <b>to find</b> the door locked.)</li>
        <li>finish/enjoy/avoid/practice/mind/suggest + doing</li>
        <li>want/hope/plan/decide/promise + to do</li>
        <li>stop to do（停下来去做）vs stop doing（停止正在做）</li>
        <li>remember to do（记得要做）vs remember doing（记得做过）</li>
        <li>forget to do（忘了要做）vs forget doing（忘了做过）</li>
      </ul>
      <p><b>分词作状语</b>：</p>
      <ul>
        <li>逻辑主语必须与主句主语一致</li>
        <li>分词与逻辑主语主动关系→现在分词；被动→过去分词</li>
        <li>例：<b>Walking</b> down the street, I met an old friend. （I 在 walk，主动）</li>
        <li>例：<b>Surprised</b> by the news, she cried. （she 被 surprise，被动）</li>
      </ul>
      <p><b>悬垂分词错误</b>：分词的逻辑主语必须存在且与主句主语一致。</p>
    `,
    formula: '主动 + 主动 → doing；被动 + 完成 → done；将要做 → to do',
    tips: '看到选项有"doing/done/to do"，第一步判主被动：主语能不能主动做这个动作？能→doing/to do，不能→done。',
    example: 'The boy <b>injured</b> in the accident was sent to hospital. （boy 被 injure，过去分词作定语）'
  },

  // ========== 词汇 ==========
  {
    id: 'en_m4',
    tier: '通用',
    tag: '高频词汇',
    title: '《字根字源经》',
    summary: '常见词根词缀 + 高考3500词高频派生关系。',
    content: `
      <p><b>常见前缀</b>：</p>
      <ul>
        <li>un-/in-/im-/dis-：否定（happy→unhappy, possible→impossible）</li>
        <li>re-：再/重新（write→rewrite）</li>
        <li>pre-：前（view→preview）</li>
        <li>over-：过度（eat→overeat）</li>
        <li>under-：在下/不足（estimate→underestimate）</li>
      </ul>
      <p><b>常见后缀</b>：</p>
      <ul>
        <li>名词：-tion/-sion (action, decision), -ment (development), -ness (kindness), -er/-or (teacher, actor), -ist (artist)</li>
        <li>形容词：-able/-ible (comfortable), -ful (helpful), -less (useless), -ous (famous), -ive (active)</li>
        <li>动词：-ize/-ise (modernize), -en (strengthen), -ify (simplify)</li>
        <li>副词：-ly (quickly)</li>
      </ul>
      <p><b>易混词</b>：</p>
      <ul>
        <li>affect (动词，影响) vs effect (名词，影响/效果)</li>
        <li>accept (接受) vs except (除……以外)</li>
        <li>advice (n.建议) vs advise (v.建议)</li>
        <li>raise (vt.举起) vs rise (vi.升起)</li>
        <li>lay (vt.放置) vs lie (vi.躺/位于) vs lie (vi.说谎)</li>
      </ul>
    `,
    formula: '词性派生：动→名(+tion/ment) → 形(+al/ive) → 副(+ly)',
    tips: '完形+语法填空：题目给个原词让你填空格里的派生词。第一步看空格前后判词性（the前是名词、be后是形容词、动词后是副词等）。',
    example: 'He performed well. (good→well 副词修饰动词)；His performance was great. (动名词作主语)'
  },

  // ========== 阅读理解 ==========
  {
    id: 'en_m5',
    tier: '通用',
    tag: '阅读技巧',
    title: '《阅微心法》',
    summary: '高考阅读理解四大题型解题技巧：细节、推理、主旨、词义猜测。',
    content: `
      <p><b>题型1：细节题</b>（占比最大，约一半）</p>
      <ul>
        <li>定位关键词（人名、数字、专有名词）→ 回原文找句子 → 选项对比</li>
        <li>错误选项常见类型：偷换数字、张冠李戴、过度引申、绝对化</li>
      </ul>
      <p><b>题型2：推理判断题</b></p>
      <ul>
        <li>关键词：infer / suggest / imply / probably / most likely</li>
        <li>"基于原文但又超出原文一点点"——不能选完全=原文（那是细节题选项）</li>
        <li>也不能选过度引申/无中生有的</li>
      </ul>
      <p><b>题型3：主旨大意题</b></p>
      <ul>
        <li>关键词：main idea / best title / mainly about / purpose</li>
        <li>看首段+末段+每段首句</li>
        <li>标题要求：1) 涵盖全文 2) 言简意赅 3) 醒目吸引</li>
      </ul>
      <p><b>题型4：词义猜测题</b></p>
      <ul>
        <li>看上下文：标点（破折号、冒号常表解释）、同义词复现、反义词对比、举例</li>
        <li>把生词当成 X，根据语境推断 X 是褒/贬/中性</li>
      </ul>
      <p><b>阅读时间管理</b>：每篇 7-8 分钟，先读题再读文（细节定位），最后通读把握主旨。</p>
    `,
    formula: '细节→定位；推理→基于+不过度；主旨→首末段；猜词→标点+同反义',
    tips: '正确选项往往是原文核心句的"同义改写"（synonym paraphrase）——找到那个改写版本就对了。',
    example: '原文 "He was extremely furious." 选项 "He was very angry." 这就是典型同义改写——furious=very angry。'
  },

  // ========== 写作 ==========
  {
    id: 'en_m6',
    tier: '通用',
    tag: '应用文写作',
    title: '《妙文生章经》',
    summary: '高考应用文（邀请信、建议信、申请信、投诉信、通知）和续写要点。',
    content: `
      <p><b>应用文通用结构</b>（3段法）：</p>
      <ol>
        <li>开头段：表明写信目的（1-2句）</li>
        <li>主体段：具体内容（3-5句，分2-3个要点）</li>
        <li>结尾段：礼貌结束 + 期待回复</li>
      </ol>
      <p><b>高频开头句</b>：</p>
      <ul>
        <li>邀请信：I am writing to invite you to...</li>
        <li>建议信：I am writing to offer some suggestions on...</li>
        <li>申请信：I am writing to apply for...</li>
        <li>感谢信：I am writing to express my sincere gratitude for...</li>
        <li>道歉信：I am writing to apologize for...</li>
      </ul>
      <p><b>高频结尾句</b>：</p>
      <ul>
        <li>I am looking forward to your reply.</li>
        <li>I would appreciate it if you could...</li>
        <li>Your prompt reply would be highly appreciated.</li>
      </ul>
      <p><b>读后续写得分点</b>：</p>
      <ol>
        <li>情节合理：续写情节要顺接前文，不要"灵魂出窍"</li>
        <li>呼应前文：用前文出现的人物/物品/情感线索</li>
        <li>语言升级：用高级词汇（替换 good→excellent, said→remarked）、长短句结合、定语从句+分词作状语</li>
        <li>结构清晰：两段，每段紧扣段首句</li>
        <li>情感升华：结尾要有"启示/感悟"</li>
      </ol>
    `,
    formula: '应用文：1表目的→2讲细节→3致结尾；续写：续情节+用线索+升语言+提主题',
    tips: '应用文千万别堆砌长难句——逻辑清晰+用词准确就够拿高分。读后续写则反过来——必须有高级表达。',
    example: '邀请信开头：I am writing to extend my warmest invitation to you to attend our school\'s English speech contest, which will be held next Friday.'
  },

  // ========== 听力 ==========
  {
    id: 'en_m7',
    tier: '通用',
    tag: '听力',
    title: '《通灵耳诀》',
    summary: '听力理解三大题型策略。',
    content: `
      <p><b>听力题型</b>：</p>
      <ul>
        <li>短对话（10题）：场景对话，问关系/地点/职业等</li>
        <li>长对话/独白（5+5题）：每段配3题，需做笔记</li>
      </ul>
      <p><b>核心策略</b>：</p>
      <ol>
        <li><b>读题在前</b>：拿到题立刻用30秒预读选项，圈关键词</li>
        <li><b>预测内容</b>：根据题干和选项推测对话场景（医院/餐厅/银行/学校）</li>
        <li><b>抓"信号词"</b>：but, however, actually 后是重点；first/second/finally 是顺序</li>
        <li><b>同义替换</b>：选项几乎不会用原文原话——会换说法</li>
      </ol>
      <p><b>高频场景词汇</b>：</p>
      <ul>
        <li>医院：appointment, prescription, surgery, symptoms</li>
        <li>餐厅：reservation, menu, waiter, bill, tip</li>
        <li>机场：boarding pass, gate, customs, baggage claim</li>
        <li>学校：assignment, deadline, lecture, semester</li>
      </ul>
    `,
    formula: '听力得分公式 = 词汇基础 + 预读速度 + 抓信号词 + 同义辨认',
    tips: '听不懂时不要纠结上一题——立刻放弃，集中精神听下一题。一道丢了别让它拖累三道。',
    example: '听到 "I\'d like to make an appointment for Dr. Smith"，问场景，选 "in a hospital/clinic"（不会出现"hospital"原词，要靠同义替换）。'
  },

];
