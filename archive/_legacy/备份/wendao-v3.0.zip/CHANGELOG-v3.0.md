# 📜 CHANGELOG · v3.0

> 版本代号：**「大地图·战斗·装备三合一」**
> 发布日期：2026-07-01
> 相对基准：v2.2.2-hotfix

---

## 🎯 v3.0 一句话说明

**从"答题背单词"进化为一个真正的 RPG**：大地图导航 · 全屏战斗 · 装备/宠物/丹药系统 · 30 项成就 · 全新剧情线，同时**完全兼容 v1/v2 存档**（自动迁移，缺字段自动补）。

---

## ✨ 新特性

### 1. ⚔ 战斗系统 · 全屏 RPG 战斗
- **HP / MP 双资源**：答对进攻，答错受伤，MP 消耗用于施展法术
- **4 大技能**
  - `⚔ 平取` 免费·1.0×基础伤害
  - `⚡ 天雷诀` 20 MP·2.0×伤害
  - `🔥 火球术` 15 MP·1.5×伤害
  - `💚 小循环` 10 MP·恢复 30 HP
- **暴击 / 连击 / 伤害飘字 / 法术粒子特效**
- 每个学科页新增 Tab「🔥 斩妖场·v3」，可对战 4 阶妖兽（含妖王）

### 2. 🗺 大地图导航
- 8 节点 SVG 大地图取代宗门列表，成为主入口
- 云雾山脉 · 星辰路径动画
- 访问节点触发对应剧情（`map_start / map_cave / map_secret / map_treasure / map_tower`）

### 3. 🎒 装备槽系统
- **4 部位**：武器 / 衣袍 / 法器 / 头冠
- **20 件装备**，凡→仙 5 阶品阶（灰→白→蓝→紫→金）
- 装备加成实时联动学科奖励

### 4. 🐉 灵宠系统
- **6 只灵宠**（青鳞蛇 / 玄铁鼠 / 三尾狐 / 玉衡狮 / 幽冥鸦 / 天火凤）
- 每答对一题灵宠 +1 经验，升级加攻
- 战斗中灵宠协战飘字 `+petAtk 零伤`

### 5. ⚗ 丹药系统
- **6 种丹药**：回气丹 / 凝神丹 / 培元丹 / 大还丹 / 心宁丹 / 慧根丹
- 服用后立即生效（HP / MP / 道心 / 修为 buff）
- 秘境探索 · 每日任务掉落

### 6. 🏅 30 项成就系统
- 分 6 大类：初心 / 修行 / 战斗 / 收藏 / 学霸 / 隐藏
- 达成解锁 → toast 提示 → 额外灵石奖励 → 专属称号
- 通过 `Game.emit` 事件驱动，自动侦测

### 7. 📅 每日任务
- 6 种任务类型：答题 / 正确 / 战斗 / 胜利 / 突破 / 打坐 / 秘境
- 每日 0 点自动刷新
- 完成后一键领奖

### 8. 🎭 8 段新剧情
- 5 段大地图节点剧情
- 4 段境界突破剧情（炼气 5 / 10 / 15 / 20）
- 1 段成就殿堂开启剧情

---

## 🔧 架构改动

### 事件系统
新增 `Game.on(evt, fn)` / `Game.emit(evt, payload)`

监听的 6 种事件：
- `answer`：每次答题
- `battle_end`：战斗结束
- `master_manual`：掌握功法
- `breakthrough`：突破境界
- `secret_realm`：进入秘境
- `meditate`：打坐

由 `AchievementListener.hookup()` 一次性挂钩到 `_checkAchievements` + `_dailyProgress`。

### 剧情行支持新字段
```javascript
{
  speaker:'...', avatar:'👤', text:'...',
  hpDelta: +20,     // 加 HP
  mpDelta: -10,     // 扣 MP
  daoxinDelta: +5,  // 改道心
  pill: 'huqi',     // 直接给丹药
  gear: 'iron_sword', // 直接给装备
  pet: 'qinglin',   // 直接给灵宠
  achievement: 'first_master' // 直接解锁成就
}
```

### 存档兼容
- v3 core 有 `_ensureV2Fields()` 自动为老存档补齐 `hp / mp / gear / pets / pills / achievements / map` 字段
- v1 / v2 存档打开 v3 后 100% 平滑升级，不会白屏

---

## 📁 文件清单

```
v3.0/
├── index.html                      # 主入口（大地图 + 8 快捷入口）
├── assets/
│   ├── game-core.js         v3.0   # 核心 + 战斗/装备/宠物/丹药/成就
│   ├── ui-components.js     v2.0   # UI + 战斗场景 + 大地图 SVG
│   ├── style.css            v3.0   # 全新视觉（金/紫/青/丹砂红/翡翠绿）
│   ├── story-engine.js      v3.0   # 剧情 + AchievementListener
│   ├── subject-page.js      v3.0   # 学科页 + 斩妖场 + 修士背包
│   └── interactive-engine.js v2.0  # 交互演道（继承 v2.2.2）
├── data/
│   ├── story-data.js        v3.0   # 35 段剧情
│   ├── physics-*.js
│   ├── chemistry-*.js
│   ├── geography-*.js
│   ├── chinese-*.js
│   ├── math-*.js
│   └── english-*.js
└── subjects/
    ├── physics.html         v3.0
    ├── chemistry.html       v3.0
    ├── geography.html       v3.0
    ├── chinese.html         v3.0
    ├── math.html            v3.0
    └── english.html         v3.0
```

---

## 📊 数据规模（v3.0 冒烟测试）

| 项目 | 数量 |
|---|---|
| JS 文件加载成功 | 17/17 |
| 装备条目 | 20 件 |
| 丹药配方 | 6 种 |
| 灵宠 | 6 只 |
| 成就 | 30 项 |
| 剧情场景 | 35 段 |
| 物理功法 | 18 篇 |
| 物理题库 | 100 题 |
| API 完整性检查 | 34/34 通过 |

---

## 🐛 修复

- 修复 v2.2 UI.modal 在 v3 API 下调用 `.querySelector` 报错（openPanel helper）
- 修复答题事件未派发导致成就无法自动检测的 bug
- 修复地图节点访问时未记录 `visitedNodes` 的 bug
- 修复剧情行的 `hpDelta / mpDelta` 未生效

---

## 🚀 下一版预告（v3.1）

- 宗门大比大厅 UI 大改
- 六科通天塔多学科混合考核
- 灵宠孵化站（可自定义外观）
- 成就殿堂 3D 展示柜
- 高考飞升大典完整剧情线

—— *「问道于天，求道于学。」*
