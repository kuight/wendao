/* ===================================================
 * 《问道修仙学院》学科页通用逻辑 v3.0
 *
 * v3.0 升级要点（相对 v2.2.2）：
 *  + 新 Tab「⚔ 斩妖场」：调用 UI.openBattle 全屏战斗，含 HP/MP、技能、暴击、飘字
 *  + 新 Tab「🎒 修士背包」：装备 / 丹药 / 灵宠 三合一，随时切换
 *  + 灵宠协战：答对后若有出战宠物，额外飘字 +petAtk
 *  + 装备属性联动：答对奖励 × (1 + gearBoost)
 *  + 每次答题派发 Game.emit('answer',{correct,sect,diff}) 触发成就
 *  + 战斗结束派发 Game.emit('battle_end') 用于宗门进度 & 成就
 *  + 心魔录一键悬赏（用当前技能一次性斩杀所有心魔）
 *  + 保留 v2.2 三步证道、闯关塔、Boss 警告等
 *
 * 用法：SubjectPage.init({ sect:'physics', manuals: PHYSICS_MANUALS, bank: PHYSICS_BANK, introScene:'physics_intro' })
 * =================================================== */

(function (global) {
  'use strict';

  // ===== 工具：把 v2.0 题目选项数组转成统一 {k,v} 数组 =====
  function normalizeOptions(q) {
    if (!q.options) return [];
    const opts = q.options;
    // 已是对象数组
    if (opts.length && typeof opts[0] === 'object' && opts[0] && 'k' in opts[0]) {
      return opts;
    }
    // 字符串数组（v2.0 格式："A. xxx"）
    return opts.map(s => {
      const m = String(s).match(/^([A-Z])[.、:：]\s*(.+)$/);
      if (m) return { k: m[1], v: m[2] };
      return { k: '?', v: String(s) };
    });
  }

  // ===== 工具：判断题选项规范化 =====
  function judgeOptions() {
    return [{ k:'对', v:'正确' }, { k:'错', v:'错误' }];
  }

  const SubjectPage = {
    sect: '',
    manuals: [],
    bank: [],
    currentTab: 'manual',
    introScene: '',
    streak: 0,        // v2.0 连击计数

    init(opts) {
      this.sect = opts.sect;
      this.manuals = opts.manuals || [];
      this.bank = opts.bank || [];
      this.introScene = opts.introScene || '';

      Game.init();
      // v2.0：灵气粒子背景
      if (UI.initQiParticles) UI.initQiParticles();

      this._mount();
      this._maybePlayIntro();

      window.addEventListener('hashchange', () => this._handleHash());
      this._handleHash();
    },

    _maybePlayIntro() {
      if (this.introScene && global.STORY_DATA && !Story.seen(this.introScene)) {
        Story.play(this.introScene, STORY_DATA, () => UI.refreshTopbar({ backHref: '../index.html' }));
      }
    },

    _mount() {
      document.body.innerHTML = '';
      const top = document.createElement('div');
      top.innerHTML = UI.renderTopbar({ backHref: '../index.html' });
      document.body.appendChild(top.firstElementChild);

      const c = document.createElement('div');
      c.className = 'xx-container';
      c.id = 'sub-root';
      document.body.appendChild(c);

      this._render();
    },

    _render() {
      const root = document.getElementById('sub-root');
      const sectName = { physics:'⚡ 雷霆殿 · 物理', chemistry:'⚗ 丹鼎峰 · 化学', geography:'🌏 山河阁 · 地理',
                         chinese:'📜 文渊阁 · 语文', math:'🔢 推衍宫 · 数学', english:'🌐 译灵堂 · 英语' };
      const st = Game.state.sects[this.sect];
      root.innerHTML = `
        <div style="margin-bottom:18px;">
          <h2 class="xx-section-title" style="font-size:26px;">${sectName[this.sect] || this.sect}</h2>
          <div class="xx-section-sub">
            已参悟功法 <b style="color:var(--xx-gold);">${st.masteredManuals.length}</b> / ${this.manuals.length} ·
            已斩妖兽 <b style="color:var(--xx-red);">${st.defeatedQuests.length}</b> / ${this.bank.length}
          </div>
        </div>

        <div class="xx-tabs">
          <button class="xx-tab ${this.currentTab==='manual'?'active':''}" data-tab="manual">📖 功法秘籍</button>
          <button class="xx-tab ${this.currentTab==='quest'?'active':''}" data-tab="quest">⚔ 妖兽试炼</button>
          <button class="xx-tab ${this.currentTab==='arena'?'active':''}" data-tab="arena">🔥 斩妖场·v3</button>
          <button class="xx-tab ${this.currentTab==='demon'?'active':''}" data-tab="demon">😈 心魔录</button>
          <button class="xx-tab ${this.currentTab==='tower'?'active':''}" data-tab="tower">🏯 闯关塔</button>
          <button class="xx-tab ${this.currentTab==='bag'?'active':''}" data-tab="bag">🎒 修士背包</button>
        </div>

        <div id="tab-body"></div>
      `;

      root.querySelectorAll('.xx-tab').forEach(btn => {
        btn.onclick = () => {
          this.currentTab = btn.dataset.tab;
          this._render();
        };
      });

      const body = document.getElementById('tab-body');
      if (this.currentTab === 'manual')      body.innerHTML = this._renderManuals();
      else if (this.currentTab === 'quest')  this._renderQuestList(body);
      else if (this.currentTab === 'arena')  this._renderArena(body);
      else if (this.currentTab === 'demon')  body.innerHTML = this._renderDemons();
      else if (this.currentTab === 'tower')  body.innerHTML = this._renderTower();
      else if (this.currentTab === 'bag')    this._renderBag(body);

      if (this.currentTab === 'manual') {
        body.querySelectorAll('.manual-card').forEach(card => {
          card.onclick = () => this._openManual(card.dataset.id);
        });
      }
    },

    // ===== 功法秘籍列表 =====
    _renderManuals() {
      if (!this.manuals.length) {
        return `<div class="xx-empty">此宗功法暂未录入，敬请期待 📜</div>`;
      }
      // v2.0：按 tier/chapter 分组显示
      const groups = {};
      this.manuals.forEach(m => {
        const k = m.tier || '其他';
        (groups[k] = groups[k] || []).push(m);
      });

      let html = `<div class="xx-tip">💡 v2.2 升级：每篇功法必经<b style="color:var(--xx-purple);">三步证道</b>才算掌握。先阅读·看动画·再亲答小测，全对才能解锁姟兽试炼。</div>`;

      Object.keys(groups).forEach(tier => {
        html += `<div class="xx-section-title" style="font-size:15px;margin:18px 0 10px;color:var(--xx-cyan);letter-spacing:3px;">📜 ${tier}</div>`;
        html += `<div class="manual-list">`;
        groups[tier].forEach(m => {
          const mastered = Game.isManualMastered(this.sect, m.id);
          const proven = Game.hasFlag ? Game.hasFlag(`proved_${m.id}`) : false;
          const cls = `manual-card ${mastered ? 'mastered' : ''} ${proven ? 'proven' : ''}`;
          html += `
            <div class="${cls}" data-id="${m.id}">
              <div class="manual-title">${m.title} ${proven ? '✦' : (mastered ? '◎' : '')}</div>
              <div class="manual-tier">
                <span class="badge">${m.tier || ''}</span>
                <span>${m.chapter || m.tag || ''}</span>
                ${m.interactive ? '<span style="color:var(--xx-cyan);font-size:11px;">🔬交互演道</span>' : ''}
                ${m.proving && m.proving.length ? '<span style="color:var(--xx-purple);font-size:11px;">✦三步证道</span>' : ''}
              </div>
              <div class="manual-summary">${m.summary || ''}</div>
            </div>
          `;
        });
        html += `</div>`;
      });
      return html;
    },

    _openManual(id) {
      const m = this.manuals.find(x => x.id === id);
      if (!m) return;
      const mastered = Game.isManualMastered(this.sect, m.id);
      const proven = Game.hasFlag ? Game.hasFlag(`proved_${m.id}`) : false;

      // v2.0：内容 + 公式 + 关键要点 + 交互动画占位 + 三步证道按钮
      let body = `
        <div style="font-size:12px;color:var(--xx-text-dim);letter-spacing:2px;">${m.tier || ''} · ${m.chapter || m.tag || ''}</div>
        <div style="margin-top:14px;line-height:1.85;font-size:14.5px;">${m.content || m.summary || ''}</div>
      `;

      // 公式
      const formula = m.formulas || m.formula;
      if (formula) {
        const fstr = Array.isArray(formula)
          ? formula.map(f => typeof f === 'object' ? `<b style="color:var(--xx-cyan);">${f.formula || f.name}</b> — ${f.desc || f.meaning || ''}` : f).join('<br>')
          : formula;
        body += `<div class="xx-tip" style="margin-top:14px;"><b style="color:var(--xx-cyan);">📐 关键公式/法则：</b><br>${fstr}</div>`;
      }

      // keyPoints
      if (m.keyPoints && m.keyPoints.length) {
        body += `<div class="quest-explain" style="margin-top:14px;"><b>💡 核心要点：</b><ul style="margin:6px 0 0 18px;line-height:1.8;">${m.keyPoints.map(k=>`<li>${k}</li>`).join('')}</ul></div>`;
      }

      if (m.example) {
        body += `<div class="quest-explain" style="margin-top:10px;border-color:var(--xx-cyan);background:rgba(110,213,224,0.08);"><b style="color:var(--xx-cyan);">🌰 经典示例：</b><br>${m.example}</div>`;
      }

      // v2.0：交互演道占位
      if (m.interactive) {
        body += `
          <div class="xx-tip" style="margin-top:14px;background:rgba(178,136,255,0.08);border-color:var(--xx-purple);">
            <b style="color:var(--xx-purple);">🔬 交互演道：</b>${m.interactive.title || '动手参悟下方动画，调参观察 →'}
          </div>
          <div id="iv-stage-${m.id}" class="iv-stage"></div>
        `;
      }

      // 操作按钮（v2.2 重构）
      // 逻辑：所有功法必须走"三步证道"才算 mastered。没有 proving 字段的，自动生成一道基于功法内容的问题。
      const actions = [];
      // 保证总有 proving
      const provingQs = (m.proving && m.proving.length) ? m.proving : this._autoGenProving(m);

      if (!mastered) {
        actions.push({ label: '先闭卷思考' });
        actions.push({ label: '✦ 开始三步证道 → 掌握此功法', primary: true, onClick: () => {
          // 选打开中验证阶段后才给予掌握状态与奖励
          m._provingQs = provingQs;
          setTimeout(() => this._startProving(m), 100);
        }});
      } else if (mastered && !proven && provingQs.length) {
        actions.push({ label: '稍后再说' });
        actions.push({ label: '✦ 重新证道（领悟加深）', primary: true, onClick: () => {
          m._provingQs = provingQs;
          setTimeout(() => this._startProving(m), 100);
        }});
      } else if (proven) {
        actions.push({ label: '已证道 ✦，关闭', primary: true });
      } else {
        actions.push({ label: '已掌握，关闭', primary: true });
      }

      const modal = UI.modal({ title: `📖 ${m.title}`, body, actions });

      // 渲染交互动画
      if (m.interactive && global.IE) {
        setTimeout(() => {
          const stage = document.getElementById(`iv-stage-${m.id}`);
          if (stage) {
            try { IE.render(stage, m.interactive); }
            catch (e) { stage.innerHTML = `<div class="xx-empty">交互动画加载失败：${e.message}</div>`; }
          }
        }, 50);
      }
    },

    // ===== v2.0 新增：三步证道（v2.2.1 彻底重写） =====
    //   目标：无论功法自带多少 proving，“三步证道”至少有 3 道真实题（而不是“是否认真读过”这种水题）。
    //   策略：从 keyPoints 里依次抽取 3 个不同要点，干扰项优先从同一本功法的其他 keyPoint / formula 里取，实在不够才用通用干扰。
    _autoGenProving(m) {
      const title = m.title || '本功法';
      const kp = (m.keyPoints || []).filter(Boolean);
      const fx = (m.formulas || []).filter(Boolean);
      const qs = [];

      // 通用干扰库（只当本功法信息不够时才用，避免“与考试无关”这种开玩笑的干扰）
      const genericDistractors = [
        '它仅在理想状态下成立，高考不设实际情境',
        '其适用前提与本篇所讲相反',
        '只适用于选择题，大题不考',
        '本篇仅介绍历史背景，不涉及考点'
      ];

      // 小工具：从数组里抽 n 个不同于 correct 的干扰项
      function pickDistractors(pool, correct, n) {
        const rest = pool.filter(x => x && x !== correct).slice();
        // 洗牌
        for (let i = rest.length - 1; i > 0; i--) {
          const j = Math.floor(Math.random() * (i + 1));
          [rest[i], rest[j]] = [rest[j], rest[i]];
        }
        const out = rest.slice(0, n);
        while (out.length < n) out.push(genericDistractors[out.length % genericDistractors.length]);
        return out;
      }

      // 题 1：从 keyPoints[0] 选出正确要点
      if (kp.length >= 1) {
        const correct = kp[0];
        const dists = pickDistractors(kp.slice(1).concat(genericDistractors), correct, 3);
        qs.push({
          type: 'single',
          q: `【${title}】以下哪项是本篇强调的核心要点？`,
          options: ['A. ' + correct, 'B. ' + dists[0], 'C. ' + dists[1], 'D. ' + dists[2]],
          answer: 'A',
          explain: '原文关键要点：' + correct
        });
      }

      // 题 2：从 keyPoints[1] 选出（若有），换个角度
      if (kp.length >= 2) {
        const correct = kp[1];
        const dists = pickDistractors(kp.filter((_,i)=>i!==1).concat(genericDistractors), correct, 3);
        qs.push({
          type: 'single',
          q: `【${title}】下列关于本篇内容的描述，正确的是？`,
          options: ['A. ' + dists[0], 'B. ' + correct, 'C. ' + dists[1], 'D. ' + dists[2]],
          answer: 'B',
          explain: '原文关键要点：' + correct
        });
      } else if (fx.length >= 1) {
        // 无第二个 keyPoint 但有公式：考公式识别
        const correct = fx[0];
        qs.push({
          type: 'single',
          q: `【${title}】下列公式/关系属于本篇重点的是？`,
          options: ['A. ' + correct, 'B. 仅在真空中成立，空气中失效', 'C. 与本篇主题无关的不相关式', 'D. 已被新课标删除'],
          answer: 'A',
          explain: '本篇核心关系：' + correct
        });
      }

      // 题 3：多选 / 判断 —— 优先多选（从 keyPoints 里抽 2 个真命题 + 1-2 个假命题）
      if (kp.length >= 2) {
        // 选出 2 个关键点作为正确选项，混入 2 个干扰
        const t1 = kp[0], t2 = kp[kp.length - 1];
        const f1 = genericDistractors[0];
        const f2 = genericDistractors[1];
        qs.push({
          type: 'multi',
          q: `【${title}】以下关于本功法的说法正确的有：`,
          options: ['A. ' + t1, 'B. ' + f1, 'C. ' + t2, 'D. ' + f2],
          answer: 'AC',
          explain: 'A、C 均为原文明确提到的要点；B、D 与本篇无关。'
        });
      } else if (m.summary) {
        // 保底判断题：把原文 summary 里的关键句拿出来变成判断（不再问“是否读过”）
        const s = String(m.summary).replace(/\s+/g, ' ').slice(0, 60);
        qs.push({
          type: 'judge',
          q: `【${title}】判断：“${s}” —— 这一描述符合本篇主旨。`,
          answer: '对',
          explain: '为本篇 summary 的直接描述，可作为总诀。'
        });
      }

      // 兼容底线：实在抽不出题（功法字段都缺失），也至少给 3 道接近真实的模拟题
      while (qs.length < 3) {
        const idx = qs.length + 1;
        qs.push({
          type: 'judge',
          q: `【${title}】判断（领悟题 ${idx}）：掌握本篇需先理解其概念/原理，再套公式/方法。`,
          answer: '对',
          explain: '先理解后套用是高中学科学习的基本方法论。'
        });
      }

      return qs;
    },

    _startProving(manual) {
      const proving = manual._provingQs || manual.proving || [];
      if (!proving.length) { UI.toast('该功法无证道小测', 'info'); return; }

      // 关闭可能存在的功法弹窗
      document.querySelectorAll('.xx-modal').forEach(m => m.remove());

      this._provingStep(manual, proving, 0, { right: 0, wrong: 0 });
    },

    _provingStep(manual, queue, idx, stat) {
      // 完成
      if (idx >= queue.length) {
        const passed = stat.right === queue.length;
        const root = document.getElementById('tab-body');
        root.innerHTML = `
          <div class="xx-card" style="text-align:center;padding:40px 20px;">
            <div style="font-family:var(--xx-font-art);font-size:30px;color:${passed?'var(--xx-purple)':'var(--xx-red)'};">
              ${passed?'✦ 三步证道 · 圆满':'💔 三步证道 · 未过'}
            </div>
            <div style="margin-top:14px;color:var(--xx-text-soft);">
              ${stat.right} / ${queue.length} 答对
              ${ passed ? '<br>真正参悟了「'+manual.title+'」的真意。' : '<br>需全部答对方算证道。再回去看看功法吧。' }
            </div>
            <div style="margin-top:24px;display:flex;gap:10px;justify-content:center;flex-wrap:wrap;">
              ${ passed
                  ? '<button class="xx-btn xx-btn-primary" id="provingClose">完美收功</button>'
                  : '<button class="xx-btn" id="provingClose">先回去复习</button><button class="xx-btn xx-btn-primary" id="provingRetry">⚔ 重新证道</button>'
              }
            </div>
          </div>
        `;
        if (passed) {
          // v2.2: 三步证道通过 = 同时授予 mastered + proved，并发放完整奖励
          const wasFresh = !Game.isManualMastered(this.sect, manual.id);
          if (wasFresh) {
            // 首次证道：+20 修为 +15 灵石（原参悟奖励）+ 证道奖励 +15 修为 +10 灵石 +5 道心
            Game.masterManual(this.sect, manual.id, 20, 15);
          }
          if (Game.setFlag) Game.setFlag(`proved_${manual.id}`);
          Game.addExp(15);
          Game.addLingshi(10);
          if (Game.state && Game.state.char) Game.state.char.daoxin = Math.min(100, (Game.state.char.daoxin||0) + 5);
          Game.save();
          UI.refreshTopbar({ backHref: '../index.html' });
          if (global.STORY_DATA && Story && !Story.seen('proving_passed')) {
            setTimeout(() => Story.play('proving_passed', STORY_DATA), 800);
          }
        }
        root.querySelector('#provingClose').onclick = () => { this.currentTab = 'manual'; this._render(); };
        const retry = root.querySelector('#provingRetry');
        if (retry) retry.onclick = () => this._startProving(manual);
        return;
      }

      const q = queue[idx];
      // 把证道小测题"伪装"成普通题进入战斗渲染
      const fakeQ = {
        id: `prove_${manual.id}_${idx}`,
        manualId: manual.id,
        type: q.type || 'single',
        difficulty: 'normal',
        q: q.q,
        options: q.options,
        answer: q.answer,
        explain: q.explain,
        monster: '✦ 证道试问',
        _isProving: true
      };
      this._renderQuest(document.getElementById('tab-body'), fakeQ, queue.length, idx, stat, queue);
      // 接管下一战
      const root = document.getElementById('tab-body');
      const obs = setInterval(() => {
        const nextBtn = root.querySelector('#nextQ');
        if (nextBtn) {
          nextBtn.onclick = () => this._provingStep(manual, queue, idx+1, stat);
          clearInterval(obs);
        }
      }, 100);
    },

    // ===== 妖兽试炼（题库）=====
    _renderQuestList(container) {
      if (!this.bank.length) {
        container.innerHTML = `<div class="xx-empty">妖兽数据加载中，敬请期待 ⚔</div>`;
        return;
      }
      const st = Game.state.sects[this.sect];
      const groups = {};
      this.bank.forEach(q => {
        const k = q.manualId || '未分类';
        (groups[k] = groups[k] || []).push(q);
      });

      let html = `<div class="xx-tip">⚔ 妖兽试炼：必须先参悟对应功法，才能挑战该章妖兽。题型有单选/多选/判断/填空，全部含详细解析。<b style="color:var(--xx-red);">遇 boss 难度妖兽前会有警告。</b></div>`;

      // 按 manualId 在 manuals 中的顺序显示
      const orderedMids = this.manuals.map(m => m.id).filter(id => groups[id]);
      // 加上不在 manuals 中的
      Object.keys(groups).forEach(k => { if (!orderedMids.includes(k)) orderedMids.push(k); });

      for (const mid of orderedMids) {
        const m = this.manuals.find(x => x.id === mid);
        const locked = m && !Game.isManualMastered(this.sect, mid);
        const arr = groups[mid];
        const beaten = arr.filter(q => st.defeatedQuests.includes(q.id)).length;
        const hasBoss = arr.some(q => q.difficulty === 'boss');
        html += `
          <div class="xx-card" style="margin-bottom:14px;${locked?'opacity:0.55;':''}">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
              <div>
                <div style="font-family:var(--xx-font-art);font-size:17px;color:var(--xx-gold);">
                  ${locked ? '🔒 ' : '⚔ '} ${m ? m.title : mid}
                  ${hasBoss ? '<span style="color:var(--xx-red);font-size:12px;margin-left:6px;">含 🐉 妖王</span>' : ''}
                </div>
                <div style="font-size:12px;color:var(--xx-text-dim);margin-top:4px;">
                  共 ${arr.length} 只妖兽 · 已斩 ${beaten}
                </div>
              </div>
              <div>
                ${ locked
                   ? '<span style="color:var(--xx-text-dim);font-size:12px;">需先参悟此功法</span>'
                   : `<button class="xx-btn xx-btn-primary xx-btn-sm" data-start="${mid}">开始挑战 ▶</button>`
                }
              </div>
            </div>
          </div>
        `;
      }
      container.innerHTML = html;
      container.querySelectorAll('[data-start]').forEach(btn => {
        btn.onclick = () => this._startBattle(btn.dataset.start);
      });
    },

    _startBattle(manualId) {
      const qs = this.bank.filter(q => q.manualId === manualId);
      if (!qs.length) { UI.toast('该章无可用题目', 'error'); return; }
      // 打乱顺序
      const queue = qs.slice().sort(() => Math.random() - 0.5);
      this.streak = 0;
      this._battleStep(queue, 0, { right: 0, wrong: 0 });
    },

    _battleStep(queue, idx, stat) {
      const root = document.getElementById('tab-body');
      if (idx >= queue.length) {
        root.innerHTML = `
          <div class="xx-card" style="text-align:center;padding:40px 20px;">
            <div style="font-family:var(--xx-font-art);font-size:32px;color:var(--xx-gold);">⚔ 战斗结束</div>
            <div style="margin-top:14px;color:var(--xx-text-soft);">
              本轮共战 ${queue.length} 妖 · 斩 <b style="color:var(--xx-green);">${stat.right}</b> · 失手 <b style="color:var(--xx-red);">${stat.wrong}</b>
            </div>
            <div style="margin-top:24px;">
              <button class="xx-btn xx-btn-primary" id="battleAgain">⚔ 再战一轮</button>
              <button class="xx-btn" id="battleBack">📜 返回</button>
            </div>
          </div>
        `;
        root.querySelector('#battleAgain').onclick = () => this._startBattle(queue[0].manualId);
        root.querySelector('#battleBack').onclick = () => { this.currentTab = 'quest'; this._render(); };
        return;
      }
      const q = queue[idx];
      // v2.0：boss 出现前警告（且未看过则插剧情）
      if (q.difficulty === 'boss' && global.STORY_DATA && Story && !Story.seen('boss_warning')) {
        Story.play('boss_warning', STORY_DATA, () => {
          this._renderQuest(root, q, queue.length, idx, stat, queue);
        });
        return;
      }
      this._renderQuest(root, q, queue.length, idx, stat, queue);
    },

    _renderQuest(root, q, total, idx, stat, queue) {
      const diffMap = { easy:'小妖', normal:'妖兽', hard:'大妖', boss:'妖王' };
      const diffIcon = { easy:'👻', normal:'👹', hard:'😈', boss:'🐉' };
      const beaten = Game.isQuestDefeated ? Game.isQuestDefeated(this.sect, q.id) : false;
      const typeMap = { single:'单选', multi:'多选', judge:'判断', fill:'填空' };
      const isProving = q._isProving;

      // 选项渲染（兼容 v1 {k,v} 与 v2 字符串数组）
      let optHtml = '';
      if (q.type === 'single' || q.type === 'judge') {
        const opts = q.type === 'judge' ? judgeOptions() : normalizeOptions(q);
        optHtml = `<div class="quest-options">` + opts.map(o => `
          <div class="quest-opt" data-k="${o.k}">
            <span class="opt-label">${o.k}.</span>
            <span>${o.v}</span>
          </div>
        `).join('') + `</div>`;
      } else if (q.type === 'multi') {
        const opts = normalizeOptions(q);
        optHtml = `<div class="quest-options">` + opts.map(o => `
          <div class="quest-opt multi" data-k="${o.k}">
            <span class="opt-label">${o.k}.</span>
            <span>${o.v}</span>
          </div>
        `).join('') + `</div><div class="xx-tip">多选题：点选多个选项后按"提交"。</div>`;
      } else if (q.type === 'fill') {
        optHtml = `<input type="text" class="quest-fill-input" placeholder="请输入答案，多空用 / 分隔" id="fillInput" autocomplete="off"/>`;
      }

      root.innerHTML = `
        <div class="quest-stage ${isProving?'proving-mode':''}">
          <div class="quest-monster">
            <div class="quest-monster-icon">${isProving?'✦':diffIcon[q.difficulty || 'normal']}</div>
            <div style="flex:1;">
              <div class="quest-monster-name">${q.monster || diffMap[q.difficulty || 'normal']}${q.tag==='local_fj'?' <span class="badge-local">🏯 福建/莆田本地题</span>':''}${q.tag==='gaokao'?' <span class="badge-gaokao">🎯 高考真题</span>':''}</div>
              <div class="quest-monster-tier">第 ${idx+1} / ${total} 战 · ${typeMap[q.type] || q.type} · ${beaten?'(曾击败)':'(新妖)'}</div>
              <div class="monster-hp-bar"><div class="monster-hp-fill" id="hpBar"></div></div>
            </div>
          </div>
          <div class="quest-q">
            <span class="q-tag">${typeMap[q.type] || ''}</span>
            ${q.q}
          </div>
          ${optHtml}
          <div class="quest-actions">
            ${q.type === 'multi' || q.type === 'fill'
              ? `<button class="xx-btn xx-btn-primary" id="submitBtn">⚔ 出招 (提交)</button>`
              : ''
            }
            ${ isProving ? '' : '<button class="xx-btn" id="skipBtn">⏭ 跳过</button>' }
          </div>
          <div id="explainArea"></div>
        </div>
      `;

      let selected = null;
      const multiPicks = new Set();

      const opts = root.querySelectorAll('.quest-opt');
      opts.forEach(el => {
        el.onclick = () => {
          if (el.classList.contains('disabled')) return;
          if (q.type === 'multi') {
            const k = el.dataset.k;
            if (multiPicks.has(k)) { multiPicks.delete(k); el.classList.remove('selected'); }
            else { multiPicks.add(k); el.classList.add('selected'); }
          } else {
            selected = el.dataset.k;
            opts.forEach(o => o.classList.remove('selected'));
            el.classList.add('selected');
            setTimeout(() => doSubmit(), 150);
          }
        };
      });

      const submitBtn = root.querySelector('#submitBtn');
      if (submitBtn) submitBtn.onclick = () => doSubmit();
      const skipBtn = root.querySelector('#skipBtn');
      if (skipBtn) skipBtn.onclick = () => this._battleStep(queue, idx + 1, stat);

      const doSubmit = () => {
        let userAns;
        if (q.type === 'multi') userAns = Array.from(multiPicks).sort().join('');
        else if (q.type === 'fill') userAns = root.querySelector('#fillInput').value;
        else userAns = selected;

        if ((q.type === 'multi' && multiPicks.size === 0) ||
            (q.type === 'fill' && !userAns) ||
            ((q.type === 'single' || q.type === 'judge') && !selected)) {
          UI.toast('请先作答', 'error', 1500);
          return;
        }

        const isCorrect = Game.judgeAnswer(q, userAns);

        // v2.0：答题特效
        if (UI.showAnswerFx) UI.showAnswerFx(isCorrect);

        // 记录答题 / 战斗结果
        let r = { expGain: 0, shiGain: 0, daoxinGain: 0, streak: 0 };
        if (!isProving) {
          // 正常题入题库统计 + 心魔录
          if (Game.submitAnswer) r = Game.submitAnswer(this.sect, q.id, isCorrect, q.difficulty || 'normal');
          else if (Game.recordAnswer) r = Game.recordAnswer(this.sect, q.id, isCorrect, q.difficulty || 'normal');
        }
        // v3.0：派发答题事件（供成就/每日任务听）
        if (Game.emit) Game.emit('answer', { sect: this.sect, correct: isCorrect, difficulty: q.difficulty || 'normal', qid: q.id, isProving });
        // v3.0：宝物协战 — 若已出战宠物且答对，追加飘字
        try {
          const pet = Game.state.char.activePet;
          if (isCorrect && !isProving && pet && Game.PET_DATA && Game.PET_DATA[pet.id]) {
            const petDef = Game.PET_DATA[pet.id];
            const dmg = (petDef.atk || 5) + (pet.level || 1) * 2;
            if (Game.petGainExp) Game.petGainExp(1);
            if (UI.toast) UI.toast(`🐲 ${petDef.name} 协战！+${dmg} 零伤`, 'info', 1500);
          }
        } catch(e){}

        if (isCorrect) this.streak++; else this.streak = 0;
        if (this.streak >= 3 && UI.showCombo) UI.showCombo(`${this.streak} COMBO!`);

        // 标记选项颜色
        opts.forEach(el => {
          el.classList.add('disabled');
          const k = el.dataset.k;
          const ansArr = Array.isArray(q.answer) ? q.answer.map(String) : String(q.answer).split('');
          if (ansArr.includes(k)) el.classList.add('correct');
          if (el.classList.contains('selected') && !ansArr.includes(k)) el.classList.add('wrong');
        });

        if (submitBtn) submitBtn.style.display = 'none';

        const hp = root.querySelector('#hpBar');
        if (hp) hp.style.width = isCorrect ? '0%' : '70%';

        const explainHtml = `
          <div class="quest-explain">
            <b>${isCorrect ? (isProving?'✦ 此问已答!':'⚔ 妖兽已斩！') : (isProving?'💔 此问未明':'😱 你被妖兽反伤！')}</b><br>
            <span class="ans">参考答案：${Array.isArray(q.answer) ? q.answer.join('') : q.answer}</span><br>
            ${q.explain ? `<div style="margin-top:8px;">${q.explain}</div>` : ''}
          </div>
          ${ !isProving && isCorrect
              ? `<div class="xx-tip" style="background:rgba(140,226,140,0.12);border-color:var(--xx-green);">
                  +${r.expGain} 修为 +${r.shiGain} 灵石 +${r.daoxinGain} 道心 · 连击 ${r.streak||this.streak} 🔥
                </div>`
              : (!isProving && !isCorrect
                  ? `<div class="xx-tip" style="background:rgba(226,91,91,0.12);border-color:var(--xx-red);">
                      心魔生于一念之间——此题已加入「心魔录」，请来日重战。
                    </div>`
                  : '')
          }
          <div style="text-align:right;margin-top:14px;">
            <button class="xx-btn xx-btn-primary" id="nextQ">${isProving?'下一问 ▶':'下一战 ▶'}</button>
          </div>
        `;
        root.querySelector('#explainArea').innerHTML = explainHtml;
        UI.refreshTopbar({ backHref: '../index.html' });
        if (isCorrect) stat.right++; else stat.wrong++;

        root.querySelector('#nextQ').onclick = () => {
          this._battleStep(queue, idx + 1, stat);
        };
      };
    },

    // ===== 心魔录 =====
    _renderDemons() {
      const all = (Game.heartDemons ? Game.heartDemons() : (Game.state.heartDemons || []))
                  .filter(d => d.sect === this.sect);
      if (!all.length) return `<div class="xx-empty">心境澄澈，此宗无心魔 🌿</div>`;

      let html = `<div class="xx-tip">😈 心魔录：你在此宗错过的妖兽。点击重新挑战，答对即可清除心魔，并获得额外道心。</div>`;
      html += '<div class="heart-demon-list">';
      all.forEach(d => {
        const q = this.bank.find(x => x.id === d.qid);
        const desc = q ? (q.q.length > 60 ? q.q.slice(0, 60) + '…' : q.q) : '(题目缺失)';
        html += `
          <div class="heart-demon-item" data-qid="${d.qid}">
            ${desc}
            <div style="font-size:11px;color:var(--xx-text-dim);margin-top:4px;">
              失手 ${d.wrongCount} 次 · 最近 ${new Date(d.lastWrongAt).toLocaleString('zh-CN')}
            </div>
          </div>
        `;
      });
      html += '</div>';
      setTimeout(() => {
        document.querySelectorAll('.heart-demon-item').forEach(it => {
          it.onclick = () => {
            const qid = it.dataset.qid;
            const q = this.bank.find(x => x.id === qid);
            if (!q) return;
            this.streak = 0;
            this._battleStep([q], 0, { right:0, wrong:0 });
          };
        });
      }, 0);
      return html;
    },

    // ===== 闯关塔（综合考核）=====
    _renderTower() {
      const st = Game.state.sects[this.sect];
      const layers = [
        { layer: 1, name: '一层·气感',    need: 3,  count: 5,  reward:{exp:30,  shi:20}, diff:['easy','normal'] },
        { layer: 2, name: '二层·灵脉',    need: 6,  count: 5,  reward:{exp:50,  shi:40}, diff:['easy','normal'] },
        { layer: 3, name: '三层·筑基',    need: 10, count: 8,  reward:{exp:80,  shi:70}, diff:['normal','normal','hard'] },
        { layer: 4, name: '四层·金丹',    need: 16, count: 10, reward:{exp:140, shi:120},diff:['normal','hard'] },
        { layer: 5, name: '五层·元婴',    need: 24, count: 12, reward:{exp:220, shi:200},diff:['hard','hard','boss'] },
        { layer: 6, name: '六层·化神',    need: 36, count: 15, reward:{exp:380, shi:330},diff:['hard','boss'] },
        { layer: 7, name: '七层·渡劫·宗门大比',  need: 50, count: 20, reward:{exp:680, shi:600},diff:['hard','boss'] },
      ];
      const beaten = st.defeatedQuests.length;

      let html = `<div class="xx-tip">🏯 闯关塔：综合测试。每层随机抽题，需击败一定数量妖兽方可挑战。每层只奖励一次。<b style="color:var(--xx-purple);">七层 = 宗门大比，期末考冲刺！</b></div>`;
      layers.forEach(L => {
        const unlocked = beaten >= L.need;
        const cleared = Game.hasFlag && Game.hasFlag(`tower_${this.sect}_${L.layer}_cleared`);
        html += `
          <div class="xx-card" style="margin-bottom:12px;${unlocked?'':'opacity:0.5;'}">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;">
              <div>
                <div style="font-family:var(--xx-font-art);font-size:17px;color:var(--xx-gold);">
                  ${unlocked?'':'🔒 '}🏯 ${L.name}
                </div>
                <div style="font-size:12px;color:var(--xx-text-dim);margin-top:4px;">
                  解锁条件：累计斩 ${L.need} 妖（当前 ${beaten}） · 共 ${L.count} 战 · 通关奖励 +${L.reward.exp} 修为 +${L.reward.shi} 灵石
                </div>
              </div>
              <div>
                ${ cleared ? '<span style="color:var(--xx-green);font-size:13px;">✓ 已通关</span>'
                  : (unlocked
                      ? `<button class="xx-btn xx-btn-primary xx-btn-sm" data-layer="${L.layer}">挑战 ▶</button>`
                      : '<span style="color:var(--xx-text-dim);font-size:12px;">未解锁</span>') }
              </div>
            </div>
          </div>
        `;
      });
      setTimeout(() => {
        document.querySelectorAll('[data-layer]').forEach(b => {
          b.onclick = () => {
            const L = layers.find(x => x.layer === parseInt(b.dataset.layer));
            this._startTowerLayer(L);
          };
        });
      }, 0);
      return html;
    },

    _startTowerLayer(L) {
      const pool = this.bank.slice();
      const prefer = pool.filter(q => L.diff.includes(q.difficulty || 'normal'));
      const fallback = pool.filter(q => !L.diff.includes(q.difficulty || 'normal'));
      const queue = (prefer.length >= L.count ? prefer : prefer.concat(fallback))
                    .sort(() => Math.random() - 0.5).slice(0, L.count);
      if (!queue.length) { UI.toast('题库不足，无法挑战此层', 'error'); return; }
      this.streak = 0;
      this._battleStepTower(queue, 0, { right:0, wrong:0 }, L);
    },

    _battleStepTower(queue, idx, stat, L) {
      if (idx >= queue.length) {
        const passRate = stat.right / queue.length;
        const pass = passRate >= 0.6;
        const root = document.getElementById('tab-body');
        if (pass && Game.hasFlag && !Game.hasFlag(`tower_${this.sect}_${L.layer}_cleared`)) {
          Game.setFlag(`tower_${this.sect}_${L.layer}_cleared`);
          Game.addExp(L.reward.exp);
          Game.addLingshi(L.reward.shi);
        }
        root.innerHTML = `
          <div class="xx-card" style="text-align:center;padding:40px 20px;">
            <div style="font-family:var(--xx-font-art);font-size:30px;color:${pass?'var(--xx-gold)':'var(--xx-red)'};">
              ${ pass ? `🏯 ${L.name} · 通关！` : `💔 ${L.name} · 闯关失败` }
            </div>
            <div style="margin-top:14px;color:var(--xx-text-soft);">
              ${stat.right} / ${queue.length} 战胜（正确率 ${(passRate*100).toFixed(0)}%）
              ${ pass ? `<br>+${L.reward.exp} 修为 +${L.reward.shi} 灵石` : '<br>需达到 60% 正确率方可通关。' }
            </div>
            <div style="margin-top:24px;">
              <button class="xx-btn" id="towerBack">返回闯关塔</button>
            </div>
          </div>
        `;
        UI.refreshTopbar({ backHref: '../index.html' });
        document.querySelector('#towerBack').onclick = () => { this.currentTab = 'tower'; this._render(); };
        return;
      }
      const q = queue[idx];
      this._renderQuest(document.getElementById('tab-body'), q, queue.length, idx, stat, queue);
      const root = document.getElementById('tab-body');
      const obs = setInterval(() => {
        const nextBtn = root.querySelector('#nextQ');
        if (nextBtn) {
          nextBtn.onclick = () => this._battleStepTower(queue, idx+1, stat, L);
          clearInterval(obs);
        }
      }, 100);
    },

    // ============================================================
    //  v3.0 新增：斩妖场（全屏战斗）
    //  调用 UI.openBattle，制造一只题目与难度匹配的妖兽
    // ============================================================
    _renderArena(container) {
      // 选择本宗已解锁功法对应的题组
      const st = Game.state.sects[this.sect];
      const mastered = st.masteredManuals || [];
      const availableQs = this.bank.filter(q => mastered.includes(q.manualId));
      const totalUnlocked = availableQs.length;
      const monsters = [
        { name:'青鳞小妖',   emoji:'🐉', hp:80,  atk:10, diffs:['easy','normal'],  reward:{exp:30,  shi:20} },
        { name:'麦荒鬼将',   emoji:'👺', hp:150, atk:14, diffs:['normal','hard'],  reward:{exp:60,  shi:45} },
        { name:'血鬄妖伯',   emoji:'🧛', hp:220, atk:18, diffs:['hard','hard'],    reward:{exp:110, shi:90} },
        { name:'🐲 妖王·轮回兽', emoji:'👹', hp:320, atk:24, diffs:['hard','boss'],    reward:{exp:200, shi:180}, boss:true },
      ];
      let html = `
        <div class="xx-tip" style="background:linear-gradient(135deg,rgba(226,91,91,0.10),rgba(178,136,255,0.10));border-color:var(--xx-red);">
          🔥 <b style="color:var(--xx-red);">斩妖场</b> — v3 全屏战斗模式！妖兽有 HP，你有 HP/MP，可施展 ⚡ 天雷诀 / 🔥 火球术 / 💚 小循环。<br>
          已解锁题库：<b style="color:var(--xx-gold);">${totalUnlocked}</b> 道 · 尝试前建议先去背包装备。
        </div>`;
      if (!totalUnlocked) {
        html += `<div class="xx-empty">请先到「功法秘籍」参悟任一篇功法，才能开启斩妖场。</div>`;
        container.innerHTML = html;
        return;
      }
      monsters.forEach((m, i) => {
        const bossTag = m.boss ? '<span style="color:var(--xx-red);margin-left:6px;">🐉 妖王</span>' : '';
        html += `
          <div class="xx-card" style="margin-bottom:10px;">
            <div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;">
              <div style="font-size:38px;">${m.emoji}</div>
              <div style="flex:1;min-width:180px;">
                <div style="font-family:var(--xx-font-art);font-size:16px;color:var(--xx-gold);">${m.name} ${bossTag}</div>
                <div style="font-size:12px;color:var(--xx-text-dim);margin-top:4px;">
                  HP ${m.hp} · 攻击 ${m.atk} · 奖励 +${m.reward.exp} 修为 +${m.reward.shi} 灵石
                </div>
              </div>
              <button class="xx-btn xx-btn-primary xx-btn-sm" data-arena-i="${i}">⚔ 开战</button>
            </div>
          </div>`;
      });
      container.innerHTML = html;
      container.querySelectorAll('[data-arena-i]').forEach(b => {
        b.onclick = () => this._launchArena(monsters[+b.dataset.arenaI], availableQs);
      });
    },

    _launchArena(monster, availableQs) {
      const self = this;
      const preferred = availableQs.filter(q => monster.diffs.includes(q.difficulty || 'normal'));
      const pool = preferred.length ? preferred : availableQs.slice();
      // 深拷一份题目（避免重复），洗牌
      const bag = pool.slice().sort(() => Math.random() - 0.5);
      let cursor = 0;

      if (!UI.openBattle) { UI.toast('战斗引擎未就绪', 'error'); return; }

      UI.openBattle({
        enemy: { name: monster.name, emoji: monster.emoji, hp: monster.hp, maxHp: monster.hp, atk: monster.atk },
        getQuestion: () => {
          if (cursor >= bag.length) cursor = 0;
          const q = bag[cursor++];
          if (!q) return null;
          // 适配：battle-scene 只带单选风格选项（字符串数组）
          let opts = [];
          if (q.type === 'judge') {
            opts = ['A. 正确', 'B. 错误'];
          } else if (q.options && q.options.length) {
            opts = q.options.map((o, i) => {
              const s = typeof o === 'string' ? o : `${o.k}. ${o.v}`;
              return s.match(/^[A-Z][.、:：]/) ? s : `${String.fromCharCode(65+i)}. ${s}`;
            });
          } else {
            opts = ['A. 确定', 'B. 否定', 'C. 不确定', 'D. 跳过'];
          }
          // 把答案转为 battle-scene 能读的 A/B/C/D 字母（判断题把 对/错 → A/B）
          let ans = q.answer;
          if (q.type === 'judge') {
            const s = String(ans);
            ans = (s.indexOf('对') >= 0 || s === 'A' || s.toLowerCase() === 'true') ? 'A' : 'B';
          }
          return {
            q: q.q,
            options: opts,
            answer: ans,
            _origQ: q
          };
        },
        onWin: () => {
          Game.addExp(monster.reward.exp);
          Game.addLingshi(monster.reward.shi);
          if (Game.emit) Game.emit('battle_end', { sect: self.sect, win: true, boss: !!monster.boss });
          if (UI.toast) UI.toast(`⚔ ${monster.name} 斩！+${monster.reward.exp}修为 +${monster.reward.shi}灵石`, 'success');
        },
        onLose: () => {
          if (Game.emit) Game.emit('battle_end', { sect: self.sect, win: false, boss: !!monster.boss });
          if (UI.toast) UI.toast('💀 道心崩碎…下次先到洞府打坐恢复。', 'error');
        },
        onClose: () => {
          // 战斗结束后刷新面板
          UI.refreshTopbar({ backHref: '../index.html' });
          self._render();
        }
      });
    },

    // ============================================================
    //  v3.0 新增：修士背包（装备 / 灵宠 / 丹药 三合一）
    // ============================================================
    _renderBag(container) {
      container.innerHTML = `
        <div class="xx-tip">🎒 修士背包：切换下方开关查看装备 / 灵宠 / 丹药。装备与服用后自动发能。</div>
        <div class="xx-tabs" style="margin-bottom:12px;">
          <button class="xx-tab active" data-btab="gear">⚔ 装备</button>
          <button class="xx-tab" data-btab="pet">🐉 灵宠</button>
          <button class="xx-tab" data-btab="pill">⚗ 丹药</button>
        </div>
        <div id="bag-body"></div>
      `;
      const bagBody = container.querySelector('#bag-body');
      const render = (tab) => {
        try {
          if (tab === 'gear' && UI.renderGear)  { bagBody.innerHTML = UI.renderGear();  if (UI.bindGear)  UI.bindGear(bagBody,  () => render('gear')); }
          else if (tab === 'pet' && UI.renderPets) { bagBody.innerHTML = UI.renderPets(); if (UI.bindPets)  UI.bindPets(bagBody,  () => render('pet'));  }
          else if (tab === 'pill' && UI.renderPills){ bagBody.innerHTML = UI.renderPills();if (UI.bindPills) UI.bindPills(bagBody, () => render('pill')); }
          else bagBody.innerHTML = '<div class="xx-empty">此分页未就绪。</div>';
        } catch(e) {
          bagBody.innerHTML = `<div class="xx-empty">背包加载异常：${e.message}</div>`;
        }
      };
      render('gear');
      container.querySelectorAll('[data-btab]').forEach(b => {
        b.onclick = () => {
          container.querySelectorAll('[data-btab]').forEach(x => x.classList.remove('active'));
          b.classList.add('active');
          render(b.dataset.btab);
        };
      });
    },

    // hash 跳转支持
    _handleHash() {
      const h = location.hash;
      if (h.startsWith('#q=')) {
        const qid = decodeURIComponent(h.slice(3));
        const q = this.bank.find(x => x.id === qid);
        if (q) {
          this.currentTab = 'demon';
          this._render();
          setTimeout(() => { this._battleStep([q], 0, {right:0,wrong:0}); }, 200);
          history.replaceState(null, '', location.pathname);
        }
      } else if (h.startsWith('#m=')) {
        // v2.0：从首页直接跳转到某功法
        const mid = decodeURIComponent(h.slice(3));
        this.currentTab = 'manual';
        this._render();
        setTimeout(() => this._openManual(mid), 200);
        history.replaceState(null, '', location.pathname);
      }
    }
  };

  global.SubjectPage = SubjectPage;

})(typeof window !== 'undefined' ? window : this);
