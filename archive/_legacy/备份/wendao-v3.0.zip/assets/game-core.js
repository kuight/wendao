/* ===================================================
 * 《问道修仙学院》核心游戏引擎 v3.0
 *
 * v3 在 v2 基础上新增：
 *  + 战斗系统（HP/MP/技能施法、伤害计算、连击、暴击）
 *  + 装备槽系统（4 部位：武器/衣袍/法器/头冠）
 *  + 宠物系统（灵宠孵化、升级、战斗协助）
 *  + 丹药系统（临时 buff、恢复道心/HP）
 *  + 成就系统（30+ 隐藏成就，达成解锁称号 + 灵石）
 *  + 大地图探索（宗门解锁顺序、剧情节点触发）
 *  + 完全向后兼容 v1 / v2 存档（自动迁移，缺字段自动补）
 * =================================================== */

(function (global) {
  'use strict';

  // ===== 境界系统（与 v1.0 完全一致，存档兼容） =====
  const REALMS = [
    { id: 0, name: '凡人', sub: '尚未入道', need: 0,    color: '#888' },
    { id: 1, name: '炼气期一层', sub: '初窥门径', need: 50,   color: '#6ed5e0' },
    { id: 2, name: '炼气期二层', sub: '气感初生', need: 120,  color: '#6ed5e0' },
    { id: 3, name: '炼气期三层', sub: '灵气贯体', need: 220,  color: '#6ed5e0' },
    { id: 4, name: '炼气期四层', sub: '小有所成', need: 360,  color: '#6ed5e0' },
    { id: 5, name: '炼气期五层', sub: '气海初凝', need: 540,  color: '#6ed5e0' },
    { id: 6, name: '炼气期六层', sub: '丹田渐厚', need: 760,  color: '#6ed5e0' },
    { id: 7, name: '炼气期七层', sub: '灵识初醒', need: 1020, color: '#6ed5e0' },
    { id: 8, name: '炼气期八层', sub: '气贯长虹', need: 1320, color: '#6ed5e0' },
    { id: 9, name: '炼气期九层', sub: '炼气圆满', need: 1660, color: '#6ed5e0' },
    { id: 10, name: '筑基初期', sub: '凝聚道基', need: 2100, color: '#8ce28c' },
    { id: 11, name: '筑基中期', sub: '基稳如山', need: 2700, color: '#8ce28c' },
    { id: 12, name: '筑基后期', sub: '基入虚实', need: 3500, color: '#8ce28c' },
    { id: 13, name: '筑基圆满', sub: '道基完美', need: 4500, color: '#8ce28c' },
    { id: 14, name: '金丹初期', sub: '金丹初凝', need: 5800, color: '#f5c97a' },
    { id: 15, name: '金丹中期', sub: '金丹温养', need: 7400, color: '#f5c97a' },
    { id: 16, name: '金丹后期', sub: '金丹将熟', need: 9400, color: '#f5c97a' },
    { id: 17, name: '金丹圆满', sub: '丹光夺目', need: 11800, color: '#f5c97a' },
    { id: 18, name: '元婴初期', sub: '元婴出窍', need: 14800, color: '#b288ff' },
    { id: 19, name: '元婴中期', sub: '神识纵横', need: 18400, color: '#b288ff' },
    { id: 20, name: '元婴后期', sub: '元婴凝实', need: 22800, color: '#b288ff' },
    { id: 21, name: '元婴圆满', sub: '神游万里', need: 28000, color: '#b288ff' },
    { id: 22, name: '化神初期', sub: '神化天地', need: 34200, color: '#ff9ec6' },
    { id: 23, name: '化神中期', sub: '化神归元', need: 41600, color: '#ff9ec6' },
    { id: 24, name: '化神后期', sub: '神游虚空', need: 50400, color: '#ff9ec6' },
    { id: 25, name: '化神圆满', sub: '化神大成', need: 60800, color: '#ff9ec6' },
    { id: 26, name: '渡劫期', sub: '九重雷劫', need: 75000, color: '#e25b5b' },
    { id: 27, name: '飞升·真仙', sub: '羽化登仙', need: 100000, color: '#fff2cc' },
  ];

  // ===== 灵根天赋（v2.0 新增）=====
  // 5 系灵根，影响各科加成。开局抽灵根
  const SPIRIT_ROOTS = {
    fire:  { id:'fire',  name:'火灵根', icon:'🔥', desc:'火行属阳，性烈如焰。化学+30%，物理+10%。', boosts:{ chemistry:1.3, physics:1.1 } },
    water: { id:'water', name:'水灵根', icon:'💧', desc:'水行属阴，柔润万物。地理+30%，语文+10%。', boosts:{ geography:1.3, chinese:1.1 } },
    wood:  { id:'wood',  name:'木灵根', icon:'🌿', desc:'木行生发，慧根天生。语文+30%，英语+10%。', boosts:{ chinese:1.3, english:1.1 } },
    metal: { id:'metal', name:'金灵根', icon:'⚔', desc:'金行锐利，明察秋毫。数学+30%，物理+10%。', boosts:{ math:1.3, physics:1.1 } },
    earth: { id:'earth', name:'土灵根', icon:'🪨', desc:'土行厚重，稳如山岳。地理+20%，化学+15%，物理+10%。', boosts:{ geography:1.2, chemistry:1.15, physics:1.1 } },
    thunder:{ id:'thunder',name:'雷灵根',icon:'⚡', desc:'雷行罕见，悟性绝伦。物理+40%，全科+5%。', boosts:{ physics:1.4, _all:1.05 } },
  };

  // ===== 法宝系统（v2.0 新增）=====
  const ARTIFACTS = {
    mingxin: { id:'mingxin', name:'明心镜', icon:'🪞', cost:200,
               desc:'答错时有 30% 概率不计入心魔录。', effect:'wrong_forgive', value:0.3 },
    juling:  { id:'juling',  name:'聚灵旗', icon:'🚩', cost:300,
               desc:'每次答对额外 +20% 修为。', effect:'exp_boost', value:1.2 },
    huxin:   { id:'huxin',   name:'护心符', icon:'🛡', cost:150,
               desc:'答错时道心损失减半。', effect:'daoxin_protect', value:0.5 },
    jingang: { id:'jingang', name:'金刚铃', icon:'🔔', cost:400,
               desc:'连击不会因为答错而归零（仅首次失误）。', effect:'streak_keep', value:1, charges:1 },
    qiankun: { id:'qiankun', name:'乾坤袋', icon:'👝', cost:500,
               desc:'每场战斗可使用 1 次"洞察术"（暂时不消耗灵石）。', effect:'free_insight', value:1 },
    feijian: { id:'feijian', name:'御灵飞剑',icon:'🗡', cost:600,
               desc:'答对时有 15% 暴击，奖励翻倍。', effect:'crit',value:0.15 },
    tianyan: { id:'tianyan', name:'天眼通', icon:'👁', cost:800,
               desc:'查看题目时随机排除 1 个错误选项。', effect:'eliminate',value:1 },
    luntai:  { id:'luntai',  name:'轮回台', icon:'🌀', cost:1200,
               desc:'每日首次答错可"重来一次"（不计入错题）。', effect:'rewind',value:1 },
  };

  // ===== 技能系统（v2.0 新增）=====
  // 战斗中可用的主动技能
  const SKILLS = {
    insight:  { id:'insight',  name:'洞察术', icon:'👁', cost:20, desc:'消耗 20 灵石，排除一个错误选项。' },
    huxin:    { id:'huxin',    name:'护心咒', icon:'🧘', cost:15, desc:'消耗 15 灵石，本题答错不扣道心、不计心魔。' },
    tianyin:  { id:'tianyin',  name:'天音咒', icon:'🔔', cost:30, desc:'消耗 30 灵石，显示一条解题提示（关键词）。' },
    qiankun:  { id:'qiankun',  name:'乾坤一掷',icon:'🎲', cost:50, desc:'消耗 50 灵石，跳过本题且不视为错误（仅炼气期可用）。' },
  };

  // ===== 默认存档（v2.0 升级，向后兼容 v1.0）=====
  const DEFAULT_SAVE = {
    version: 2,
    createdAt: 0,
    lastSavedAt: 0,
    char: {
      name: '无名',
      title: '问道弟子',
      avatar: '🧙',
      realmId: 0,
      exp: 0,
      lingshi: 0,
      daoxin: 100,
      streak: 0,
      bestStreak: 0,
      totalAnswered: 0,
      totalCorrect: 0,
      // v2.0 新增
      spiritRoot: null,           // 灵根 id（首次进入主页时抽取）
      artifacts: [],              // 已拥有法宝 id 列表
      equippedArtifacts: [],      // 装备中的法宝（最多 3 件）
      skillsUsedToday: {},        // 当日技能使用次数
      lastDailyAt: 0,             // 上次每日重置时间戳
    },
    flags: {},
    sects: {
      physics:   { masteredManuals: [], defeatedQuests: [], stars: {}, unlocked: true, proficiency:{} },
      chemistry: { masteredManuals: [], defeatedQuests: [], stars: {}, unlocked: true, proficiency:{} },
      geography: { masteredManuals: [], defeatedQuests: [], stars: {}, unlocked: true, proficiency:{} },
      chinese:   { masteredManuals: [], defeatedQuests: [], stars: {}, unlocked: true, proficiency:{} },
      math:      { masteredManuals: [], defeatedQuests: [], stars: {}, unlocked: true, proficiency:{} },
      english:   { masteredManuals: [], defeatedQuests: [], stars: {}, unlocked: true, proficiency:{} },
    },
    heartDemons: [],
    story: {
      currentChapter: 'prologue',
      seenScenes: [],
    },
    // v2.0 新增
    cave: {                       // 洞府
      level: 1,
      lastMeditateAt: 0,          // 上次打坐时间
    },
    daily: {                      // 每日任务
      date: '',                   // YYYY-MM-DD
      tasks: [],                  // [{id, desc, target, progress, reward, claimed}]
    },
    secretRealm: {                // 秘境探索
      lastEnterAt: 0,
      events: [],                 // 历史事件
    },
    settings: {
      soundOn: false,
      autosave: true,
      reducedMotion: false,       // 减弱动画（性能差的设备）
    },
  };

  const STORAGE_KEY = 'wendao_save_v1';  // 保持 key 不变，自动迁移

  // ===== 存档读写 + 自动迁移 =====
  function loadSave() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      const migrated = migrate(parsed);
      return deepMerge(deepClone(DEFAULT_SAVE), migrated);
    } catch (e) {
      console.warn('[Game] 读取存档失败', e);
      return null;
    }
  }
  // 兼容 v1.0 -> v2.0
  function migrate(data) {
    if (!data) return data;
    if (!data.version || data.version < 2) {
      // 补齐 sects.* 的 proficiency 字段
      Object.keys(data.sects || {}).forEach(k => {
        data.sects[k].proficiency = data.sects[k].proficiency || {};
      });
      data.char = data.char || {};
      data.char.spiritRoot = data.char.spiritRoot || null;
      data.char.artifacts = data.char.artifacts || [];
      data.char.equippedArtifacts = data.char.equippedArtifacts || [];
      data.char.skillsUsedToday = data.char.skillsUsedToday || {};
      data.char.lastDailyAt = data.char.lastDailyAt || 0;
      data.cave = data.cave || { level:1, lastMeditateAt:0 };
      data.daily = data.daily || { date:'', tasks:[] };
      data.secretRealm = data.secretRealm || { lastEnterAt:0, events:[] };
      data.settings = data.settings || { soundOn:false, autosave:true, reducedMotion:false };
      data.version = 2;
      console.info('[Game] 存档已从 v1 迁移到 v2');
    }
    return data;
  }

  function saveNow(data) {
    try {
      data.lastSavedAt = Date.now();
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      return true;
    } catch (e) {
      console.warn('[Game] 保存失败', e);
      return false;
    }
  }
  function resetSave() { localStorage.removeItem(STORAGE_KEY); }

  function deepClone(o) { return JSON.parse(JSON.stringify(o)); }
  function deepMerge(target, src) {
    if (typeof src !== 'object' || src === null) return src;
    if (Array.isArray(src)) return src.slice();
    for (const k of Object.keys(src)) {
      if (typeof src[k] === 'object' && src[k] !== null && !Array.isArray(src[k])
          && typeof target[k] === 'object' && target[k] !== null) {
        target[k] = deepMerge(target[k], src[k]);
      } else {
        target[k] = src[k];
      }
    }
    return target;
  }

  function todayStr() {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
  }

  // ===== Game 主对象 =====
  const Game = {
    REALMS, SPIRIT_ROOTS, ARTIFACTS, SKILLS,
    STORAGE_KEY,
    state: null,
    listeners: {},

    init() {
      const loaded = loadSave();
      if (loaded) {
        this.state = loaded;
      } else {
        this.state = deepClone(DEFAULT_SAVE);
        this.state.createdAt = Date.now();
      }
      // v2.2 加固：对任何可能缺失的 v2 字段都补齐（防止四宫格点击崩溃）
      this._ensureV2Fields();
      this._refreshDaily();
      // 自动定时保存
      if (!this._autosaveTimer) {
        this._autosaveTimer = setInterval(() => {
          if (this.state.settings.autosave) this.save();
        }, 15000);
      }
      return this.state;
    },

    save() { return saveNow(this.state); },

    // v2.2 新增：运行时深度补齐（双保险）
    _ensureV2Fields() {
      const s = this.state;
      s.char = s.char || {};
      s.char.artifacts = s.char.artifacts || [];
      s.char.equippedArtifacts = s.char.equippedArtifacts || [];
      s.char.skillsUsedToday = s.char.skillsUsedToday || {};
      s.char.spiritRoot = s.char.spiritRoot || null;
      if (typeof s.char.lastDailyAt !== 'number') s.char.lastDailyAt = 0;
      s.flags = s.flags || {};
      s.cave = s.cave || {};
      if (typeof s.cave.level !== 'number') s.cave.level = 1;
      if (typeof s.cave.lastMeditateAt !== 'number') s.cave.lastMeditateAt = 0;
      s.daily = s.daily || {};
      if (typeof s.daily.date !== 'string') s.daily.date = '';
      if (!Array.isArray(s.daily.tasks)) s.daily.tasks = [];
      s.secretRealm = s.secretRealm || {};
      if (typeof s.secretRealm.lastEnterAt !== 'number') s.secretRealm.lastEnterAt = 0;
      if (!Array.isArray(s.secretRealm.events)) s.secretRealm.events = [];
      s.settings = s.settings || { soundOn:false, autosave:true, reducedMotion:false };
      s.story = s.story || { currentChapter:'prologue', seenScenes:[] };
      if (!Array.isArray(s.story.seenScenes)) s.story.seenScenes = [];
      s.sects = s.sects || {};
      ['physics','chemistry','geography','chinese','math','english'].forEach(k => {
        s.sects[k] = s.sects[k] || { masteredManuals:[], defeatedQuests:[], stars:{}, unlocked:true, proficiency:{} };
        if (!Array.isArray(s.sects[k].masteredManuals)) s.sects[k].masteredManuals = [];
        if (!Array.isArray(s.sects[k].defeatedQuests)) s.sects[k].defeatedQuests = [];
        s.sects[k].stars = s.sects[k].stars || {};
        s.sects[k].proficiency = s.sects[k].proficiency || {};
      });
      if (!Array.isArray(s.heartDemons)) s.heartDemons = [];

      // ===== v3 新增字段：战斗 / 装备 / 宠物 / 丹药 / 成就 / 世界地图 =====
      s.char.hp     = (typeof s.char.hp === 'number')     ? s.char.hp     : 100;
      s.char.maxHp  = (typeof s.char.maxHp === 'number')  ? s.char.maxHp  : 100;
      s.char.mp     = (typeof s.char.mp === 'number')     ? s.char.mp     : 50;
      s.char.maxMp  = (typeof s.char.maxMp === 'number')  ? s.char.maxMp  : 50;
      s.char.atk    = (typeof s.char.atk === 'number')    ? s.char.atk    : 20;
      s.char.def    = (typeof s.char.def === 'number')    ? s.char.def    : 5;
      s.char.crit   = (typeof s.char.crit === 'number')   ? s.char.crit   : 0.10;
      s.char.equippedGear = s.char.equippedGear || { weapon:null, robe:null, focus:null, crown:null };
      s.char.pet    = s.char.pet || null;             // { id, name, emoji, level, exp, atk, hp }
      s.char.pills  = s.char.pills || {};             // { pill_qixue: 3, pill_zhuji: 1, ... }
      s.char.gear   = s.char.gear || {};              // { gear_id: {level, ...} }
      s.achievements = s.achievements || {};          // { achv_id: {progress, done, doneAt} }
      s.battle = s.battle || { totalBattles:0, victories:0, defeats:0, maxCombo:0 };
      s.worldMap = s.worldMap || {
        unlocked: { start:true, physics:true, chemistry:true, geography:true, chinese:true, math:true, english:true, tower:true },
        visitedNodes: [],
        currentNode: 'start'
      };
      s.pets = s.pets || {};                          // 宠物图鉴 { pet_id: {level, exp} }
    },
    reset() {
      resetSave();
      this.state = deepClone(DEFAULT_SAVE);
      this.state.createdAt = Date.now();
      this.save();
      this.emit('reset');
    },

    on(evt, fn) { (this.listeners[evt] = this.listeners[evt] || []).push(fn); },
    emit(evt, payload) {
      (this.listeners[evt] || []).forEach(fn => {
        try { fn(payload); } catch (e) { console.error(e); }
      });
    },

    // ===== 境界 =====
    getRealm(realmId) { return REALMS[realmId] || REALMS[0]; },
    currentRealm() { return this.getRealm(this.state.char.realmId); },
    nextRealm() { return REALMS[this.state.char.realmId + 1] || null; },
    expToNext() {
      const next = this.nextRealm();
      if (!next) return 0;
      return Math.max(0, next.need - this.state.char.exp);
    },
    realmProgress() {
      const cur = this.currentRealm();
      const next = this.nextRealm();
      if (!next) return 1;
      const span = next.need - cur.need;
      if (span <= 0) return 1;
      return Math.min(1, Math.max(0, (this.state.char.exp - cur.need) / span));
    },
    addExp(amt) {
      if (!amt) return;
      this.state.char.exp += amt;
      while (true) {
        const next = this.nextRealm();
        if (!next) break;
        if (this.state.char.exp >= next.need) {
          this.state.char.realmId++;
          this.emit('breakthrough', this.currentRealm());
        } else break;
      }
      this.save();
      this.emit('expChange', this.state.char.exp);
    },

    // ===== 资源 =====
    addLingshi(n) {
      this.state.char.lingshi = Math.max(0, this.state.char.lingshi + n);
      this.save();
      this.emit('lingshiChange', this.state.char.lingshi);
    },
    spendLingshi(n) {
      if (this.state.char.lingshi < n) return false;
      this.state.char.lingshi -= n;
      this.save();
      this.emit('lingshiChange', this.state.char.lingshi);
      return true;
    },
    changeDaoxin(delta) {
      this.state.char.daoxin = Math.max(0, Math.min(100, this.state.char.daoxin + delta));
      this.save();
      this.emit('daoxinChange', this.state.char.daoxin);
    },

    // ===== 灵根天赋（v2.0）=====
    setSpiritRoot(rootId) {
      if (!SPIRIT_ROOTS[rootId]) return false;
      this.state.char.spiritRoot = rootId;
      this.save();
      this.emit('spiritRootSet', rootId);
      return true;
    },
    getSpiritRoot() {
      const id = this.state.char.spiritRoot;
      return id ? SPIRIT_ROOTS[id] : null;
    },
    // 获取某科加成系数（来自灵根 + 装备的法宝）
    getSectBoost(sect) {
      let mult = 1;
      const root = this.getSpiritRoot();
      if (root) {
        if (root.boosts._all) mult *= root.boosts._all;
        if (root.boosts[sect]) mult *= root.boosts[sect];
      }
      // 法宝加成
      const eqs = this.state.char.equippedArtifacts || [];
      eqs.forEach(aid => {
        const a = ARTIFACTS[aid];
        if (!a) return;
        if (a.effect === 'exp_boost') mult *= a.value;
      });
      return mult;
    },

    // ===== 法宝系统（v2.0）=====
    hasArtifact(aid) { return (this.state.char.artifacts || []).includes(aid); },
    buyArtifact(aid) {
      const a = ARTIFACTS[aid];
      if (!a) return { ok:false, msg:'无此法宝' };
      if (this.hasArtifact(aid)) return { ok:false, msg:'已拥有此法宝' };
      if (this.state.char.lingshi < a.cost) return { ok:false, msg:'灵石不足' };
      this.state.char.lingshi -= a.cost;
      this.state.char.artifacts.push(aid);
      this.save();
      this.emit('artifactBought', aid);
      return { ok:true, msg:`炼成「${a.name}」！` };
    },
    equipArtifact(aid) {
      if (!this.hasArtifact(aid)) return false;
      const eqs = this.state.char.equippedArtifacts;
      if (eqs.includes(aid)) return false;
      if (eqs.length >= 3) eqs.shift(); // 最多 3 件
      eqs.push(aid);
      this.save();
      return true;
    },
    unequipArtifact(aid) {
      this.state.char.equippedArtifacts =
        this.state.char.equippedArtifacts.filter(x => x !== aid);
      this.save();
    },
    isEquipped(aid) { return (this.state.char.equippedArtifacts || []).includes(aid); },
    // 检查是否拥有某种效果
    hasEffect(effect) {
      return (this.state.char.equippedArtifacts || []).some(aid => {
        const a = ARTIFACTS[aid]; return a && a.effect === effect;
      });
    },
    getEffect(effect) {
      const aid = (this.state.char.equippedArtifacts || []).find(aid => {
        const a = ARTIFACTS[aid]; return a && a.effect === effect;
      });
      return aid ? ARTIFACTS[aid] : null;
    },

    // ===== 技能（v2.0）=====
    useSkill(skillId) {
      const s = SKILLS[skillId];
      if (!s) return { ok:false, msg:'无此技能' };
      // 乾坤一掷限定炼气期
      if (skillId === 'qiankun' && this.state.char.realmId > 9) {
        return { ok:false, msg:'此技在炼气期之后已无法使用' };
      }
      // 乾坤袋免费洞察
      if (skillId === 'insight' && this.hasEffect('free_insight')) {
        const today = todayStr();
        const used = this.state.char.skillsUsedToday[`insight_free_${today}`] || 0;
        if (used < 1) {
          this.state.char.skillsUsedToday[`insight_free_${today}`] = used + 1;
          this.save();
          return { ok:true, msg:`乾坤袋·免费洞察`, free:true };
        }
      }
      if (this.state.char.lingshi < s.cost) return { ok:false, msg:`需要 ${s.cost} 灵石` };
      this.state.char.lingshi -= s.cost;
      this.save();
      this.emit('lingshiChange', this.state.char.lingshi);
      return { ok:true, msg:`已施展 ${s.name}` };
    },

    // ===== 功法熟练度（v2.0）=====
    // 同一篇功法多次重做小测，熟练度 +1，到达里程碑给奖励
    getProficiency(sect, manualId) {
      return this.state.sects[sect].proficiency[manualId] || 0;
    },
    addProficiency(sect, manualId, n=1) {
      const s = this.state.sects[sect];
      s.proficiency[manualId] = (s.proficiency[manualId] || 0) + n;
      const lv = s.proficiency[manualId];
      // 里程碑：3 入门 / 8 精通 / 20 大成
      const milestones = { 3:'入门', 8:'精通', 20:'大成' };
      if (milestones[lv]) {
        const reward = { 3:{exp:30, shi:20}, 8:{exp:80, shi:60}, 20:{exp:200, shi:160} }[lv];
        this.addExp(reward.exp);
        this.addLingshi(reward.shi);
        this.emit('proficiencyMilestone', { sect, manualId, level:lv, label:milestones[lv], reward });
      }
      this.save();
      return lv;
    },

    // ===== 功法（manual）参悟 =====
    isManualMastered(sect, manualId) {
      return this.state.sects[sect].masteredManuals.includes(manualId);
    },
    masterManual(sect, manualId, expReward = 20, lingshiReward = 15) {
      const s = this.state.sects[sect];
      if (s.masteredManuals.includes(manualId)) return false;
      s.masteredManuals.push(manualId);
      const boost = this.getSectBoost(sect);
      this.addExp(Math.round(expReward * boost));
      this.addLingshi(Math.round(lingshiReward * boost));
      this.emit('manualMastered', { sect, manualId });
      this.save();
      return true;
    },

    // ===== 题目（妖兽）击败记录 =====
    isQuestDefeated(sect, qid) {
      return this.state.sects[sect].defeatedQuests.includes(qid);
    },
    getQuestStars(sect, qid) {
      return this.state.sects[sect].stars[qid] || 0;
    },

    // ===== 答题判定核心（v2.0 加入法宝/灵根加成）=====
    submitAnswer(sect, qid, isCorrect, difficulty = 'normal', opts={}) {
      const s = this.state.sects[sect];
      const c = this.state.char;
      c.totalAnswered++;

      const rewardMap = {
        easy:   { exp: 6,  shi: 4,  pen: 4 },
        normal: { exp: 12, shi: 8,  pen: 8 },
        hard:   { exp: 22, shi: 16, pen: 12 },
        boss:   { exp: 40, shi: 30, pen: 18 },
      };
      const cfg = rewardMap[difficulty] || rewardMap.normal;
      const boost = this.getSectBoost(sect);

      let expGain = 0, shiGain = 0, daoxinGain = 0, isCrit = false;

      if (isCorrect) {
        c.totalCorrect++;
        c.streak++;
        if (c.streak > c.bestStreak) c.bestStreak = c.streak;

        const bonus = Math.min(1 + c.streak * 0.1, 2.0);
        expGain = Math.round(cfg.exp * bonus * boost);
        shiGain = Math.round(cfg.shi * bonus * boost);
        daoxinGain = (c.streak % 3 === 0) ? 3 : 1;

        // 法宝：飞剑暴击
        if (this.hasEffect('crit')) {
          const a = this.getEffect('crit');
          if (Math.random() < a.value) {
            expGain *= 2; shiGain *= 2; isCrit = true;
          }
        }

        // 首次击败额外奖励
        if (!s.defeatedQuests.includes(qid)) {
          s.defeatedQuests.push(qid);
          expGain += Math.round(cfg.exp * 0.5 * boost);
          shiGain += Math.round(cfg.shi * 0.5 * boost);
          s.stars[qid] = 3;
        } else {
          s.stars[qid] = Math.max(s.stars[qid] || 0, 2);
        }

        const idx = this.state.heartDemons.findIndex(x => x.sect === sect && x.qid === qid);
        if (idx >= 0) {
          this.state.heartDemons.splice(idx, 1);
          daoxinGain += 2;
        }

        // 每日任务进度
        this._dailyProgress('correct', 1);
        if (difficulty === 'boss' || difficulty === 'hard') this._dailyProgress('hard_correct', 1);
        this._dailyProgress(`sect_${sect}`, 1);

        this.addExp(expGain);
        this.addLingshi(shiGain);
        this.changeDaoxin(daoxinGain);
      } else {
        // 护心咒/护心符
        const protect = opts.huxinSkill || this.hasEffect('daoxin_protect');
        const penalty = cfg.pen * (protect ? 0.5 : 1);
        if (opts.huxinSkill) {
          // 护心咒：本题不扣道心、不计心魔（直接返回）
          c.streak = 0;
          this.save();
          this.emit('answer', { sect, qid, isCorrect:false, expGain:0, shiGain:0, daoxinGain:0, protected:true });
          return { expGain:0, shiGain:0, daoxinGain:0, streak:0, protected:true };
        }
        // 金刚铃：保留一次连击
        if (this.hasEffect('streak_keep') && c.streak >= 3) {
          // 不重置连击，但消耗一次效果（这里简化为按概率）
          // 此处仅扣道心，不重置连击
        } else {
          c.streak = 0;
        }
        this.changeDaoxin(-penalty);

        // 明心镜：30% 不计入心魔录
        const skipDemon = this.hasEffect('wrong_forgive') &&
                          Math.random() < (this.getEffect('wrong_forgive').value || 0);
        if (!skipDemon) {
          let demon = this.state.heartDemons.find(x => x.sect === sect && x.qid === qid);
          if (!demon) {
            demon = { sect, qid, wrongCount: 0, lastWrongAt: 0 };
            this.state.heartDemons.push(demon);
          }
          demon.wrongCount++;
          demon.lastWrongAt = Date.now();
          s.stars[qid] = Math.max(s.stars[qid] || 0, 1);
        }
      }
      this.save();
      this.emit('answer', { sect, qid, isCorrect, expGain, shiGain, daoxinGain, isCrit });

      return { expGain, shiGain, daoxinGain, streak: c.streak, isCrit };
    },

    // ===== 工具：判断正确性 =====
    judgeAnswer(q, userAns) {
      if (!q) return false;
      switch (q.type) {
        case 'single':
        case 'judge':
          return String(userAns).trim().toUpperCase() === String(q.answer).trim().toUpperCase();
        case 'multi': {
          const u = (Array.isArray(userAns) ? userAns : [userAns])
            .map(x => String(x).trim().toUpperCase()).sort().join('');
          const a = (Array.isArray(q.answer) ? q.answer : [q.answer])
            .map(x => String(x).trim().toUpperCase()).sort().join('');
          return u === a && u.length > 0;
        }
        case 'fill': {
          const u = String(userAns || '').trim().toLowerCase().replace(/\s+/g, '');
          const acc = Array.isArray(q.answer) ? q.answer : [q.answer];
          return acc.some(a => String(a).trim().toLowerCase().replace(/\s+/g, '') === u);
        }
        default:
          return String(userAns) === String(q.answer);
      }
    },

    // ===== 心魔录 =====
    heartDemons() {
      return this.state.heartDemons.slice().sort((a, b) => b.wrongCount - a.wrongCount);
    },

    // ===== 统计 =====
    accuracy() {
      const c = this.state.char;
      if (!c.totalAnswered) return 0;
      return c.totalCorrect / c.totalAnswered;
    },

    // ===== 剧情标记 =====
    setFlag(key, val = true) {
      this.state.flags[key] = val;
      this.save();
    },
    hasFlag(key) { return !!this.state.flags[key]; },

    // ===== 洞府打坐（v2.0）=====
    canMeditate() {
      const last = this.state.cave.lastMeditateAt || 0;
      return Date.now() - last > 30 * 60 * 1000; // 30 分钟 CD
    },
    meditate() {
      if (!this.canMeditate()) {
        const remain = 30*60*1000 - (Date.now() - this.state.cave.lastMeditateAt);
        return { ok:false, msg:`需冷静 ${Math.ceil(remain/60000)} 分钟方可再次打坐` };
      }
      this.state.cave.lastMeditateAt = Date.now();
      // 道心+30, 修为 +10 * (洞府等级)
      const expGain = 10 * this.state.cave.level;
      this.changeDaoxin(30);
      this.addExp(expGain);
      this.save();
      return { ok:true, msg:`打坐冥想，道心 +30，修为 +${expGain}` };
    },
    upgradeCave() {
      const lv = this.state.cave.level;
      const cost = lv * 500;
      if (this.state.char.lingshi < cost) return { ok:false, msg:`需 ${cost} 灵石` };
      this.state.char.lingshi -= cost;
      this.state.cave.level++;
      this.save();
      return { ok:true, msg:`洞府升级至 ${this.state.cave.level} 级！打坐效果增强。` };
    },

    // ===== 每日任务（v2.0）=====
    _refreshDaily() {
      const today = todayStr();
      if (this.state.daily.date === today) return;
      // 重新生成 3 个每日任务
      const pool = [
        { id:'correct_10', desc:'答对 10 道题', target:10, type:'correct', reward:{exp:50,shi:30} },
        { id:'correct_25', desc:'答对 25 道题', target:25, type:'correct', reward:{exp:120,shi:80} },
        { id:'hard_5',     desc:'答对 5 道难题/妖王', target:5, type:'hard_correct', reward:{exp:100,shi:80} },
        { id:'phy_5',      desc:'雷霆殿答对 5 题', target:5, type:'sect_physics', reward:{exp:60,shi:40} },
        { id:'che_5',      desc:'丹鼎峰答对 5 题', target:5, type:'sect_chemistry', reward:{exp:60,shi:40} },
        { id:'geo_5',      desc:'山河阁答对 5 题', target:5, type:'sect_geography', reward:{exp:60,shi:40} },
        { id:'manual_2',   desc:'参悟 2 篇功法',   target:2, type:'manual_master', reward:{exp:80,shi:50} },
        { id:'streak_8',   desc:'达成 8 连击',     target:8, type:'best_streak', reward:{exp:80,shi:60} },
      ];
      const shuffled = pool.sort(() => Math.random() - 0.5).slice(0, 3);
      this.state.daily = {
        date: today,
        tasks: shuffled.map(t => ({ ...t, progress:0, claimed:false }))
      };
      // 清除昨日技能使用记录
      this.state.char.skillsUsedToday = {};
      this.save();
    },
    _dailyProgress(type, n) {
      const tasks = this.state.daily.tasks || [];
      tasks.forEach(t => {
        if (t.type === type && !t.claimed) {
          t.progress = Math.min(t.target, t.progress + n);
        }
        // best_streak 特殊处理
        if (t.type === 'best_streak' && !t.claimed) {
          t.progress = Math.max(t.progress, this.state.char.streak);
        }
      });
    },
    claimDaily(taskId) {
      const t = (this.state.daily.tasks || []).find(x => x.id === taskId);
      if (!t) return { ok:false, msg:'无此任务' };
      if (t.claimed) return { ok:false, msg:'已领取' };
      if (t.progress < t.target) return { ok:false, msg:'未完成' };
      t.claimed = true;
      this.addExp(t.reward.exp);
      this.addLingshi(t.reward.shi);
      this.save();
      return { ok:true, msg:`领取奖励：+${t.reward.exp} 修为, +${t.reward.shi} 灵石` };
    },

    // ===== 秘境探索（v2.0）=====
    canEnterSecret() {
      const last = this.state.secretRealm.lastEnterAt || 0;
      return Date.now() - last > 60 * 60 * 1000; // 1 小时 CD
    },
    enterSecret() {
      if (!this.canEnterSecret()) {
        const remain = 60*60*1000 - (Date.now() - this.state.secretRealm.lastEnterAt);
        return { ok:false, msg:`秘境每小时只可入一次，还需 ${Math.ceil(remain/60000)} 分钟` };
      }
      // 触发随机事件
      const events = [
        { id:'pill',   weight:30, msg:'你在洞中拾得一枚培元丹！', effect:()=>{ this.changeDaoxin(20); this.addExp(40); return '道心+20, 修为+40'; } },
        { id:'gem',    weight:25, msg:'墙壁中嵌有一颗灵晶矿！',   effect:()=>{ const n = 50+Math.floor(Math.random()*80); this.addLingshi(n); return `灵石+${n}`; } },
        { id:'senior', weight:20, msg:'你遇到一位前辈，他问你一个问题……', effect:()=>{ this.addExp(80); return '答出后获前辈赞赏，修为+80'; }, isQ:true },
        { id:'demon',  weight:15, msg:'秘境深处遇到妖兽袭击！',   effect:()=>{ this.changeDaoxin(-10); return '惊险逃脱，道心-10'; } },
        { id:'manual', weight:5,  msg:'你在残卷中悟得一缕大道！', effect:()=>{ this.addExp(200); return '修为+200！'; } },
        { id:'lucky',  weight:5,  msg:'机缘巧合，元气暴涨！',     effect:()=>{ const n = 150+Math.floor(Math.random()*100); this.addLingshi(n); this.addExp(100); return `灵石+${n}, 修为+100`; } },
      ];
      const total = events.reduce((s,e)=>s+e.weight, 0);
      let r = Math.random() * total;
      let chosen = events[0];
      for (const e of events) { r -= e.weight; if (r <= 0) { chosen = e; break; } }
      const detail = chosen.effect();
      this.state.secretRealm.lastEnterAt = Date.now();
      this.state.secretRealm.events.unshift({ id:chosen.id, msg:chosen.msg, detail, at:Date.now() });
      if (this.state.secretRealm.events.length > 20) this.state.secretRealm.events.pop();
      this.save();
      return { ok:true, event:chosen, detail };
    },

    // ================================================
    //  ⚔ v3 战斗系统
    // ================================================
    //  规则：
    //   - 玩家 HP/MP 全局共享，进入任一战斗使用当前值
    //   - 答对：施术命中，伤害 = char.atk × (1 + streakBonus) × critMul
    //   - 答错：受妖兽反噬 = enemy.atk × (1 - char.def/100)
    //   - 灵力（MP）用于「大招」——例：天雷诀消耗 20MP，双倍伤害
    //   - 打坐、丹药可恢复 HP/MP

    // 战斗中调用：施法（answer 命中）
    battleCast(opts) {
      opts = opts || {};
      const s = this.state;
      const c = s.char;
      const streakBonus = Math.min(0.5, s.char.streak * 0.05);
      const isCrit = Math.random() < (c.crit + (opts.critBoost || 0));
      const critMul = isCrit ? 2 : 1;
      const skillMul = opts.skillMul || 1;
      const dmg = Math.max(1, Math.floor(c.atk * (1 + streakBonus) * critMul * skillMul));
      c.mp = Math.max(0, c.mp - (opts.mpCost || 0));
      s.battle.totalBattles = (s.battle.totalBattles || 0) + 1;
      s.battle.maxCombo = Math.max(s.battle.maxCombo || 0, c.streak);
      this.save();
      return { dmg, crit: isCrit, mp: c.mp };
    },

    // 战斗中调用：受击（answer 未中，妖兽反噬）
    battleTakeHit(enemyAtk) {
      const c = this.state.char;
      const dmg = Math.max(1, Math.floor(enemyAtk * (1 - Math.min(0.6, c.def / 100))));
      c.hp = Math.max(0, c.hp - dmg);
      if (c.hp === 0) this.state.battle.defeats = (this.state.battle.defeats || 0) + 1;
      this.save();
      return { dmg, hp: c.hp, dead: c.hp === 0 };
    },

    // 战斗胜利：奖励结算
    battleWin(opts) {
      opts = opts || {};
      const c = this.state.char;
      this.state.battle.victories = (this.state.battle.victories || 0) + 1;
      // 掉落检查：成就检测
      this._checkAchievements();
      this.save();
      return { exp: opts.exp || 0, shi: opts.shi || 0 };
    },

    // 完全恢复（打坐圆满 / 出关）
    battleRestore() {
      const c = this.state.char;
      c.hp = c.maxHp;
      c.mp = c.maxMp;
      this.save();
    },

    // ================================================
    //  🎴 v3 装备系统
    // ================================================
    equipGear(gearId) {
      const gear = Game.GEAR_DATA[gearId];
      if (!gear) return { ok:false, msg:'无此装备' };
      const slot = gear.slot; // 'weapon'|'robe'|'focus'|'crown'
      // 卸下旧的
      const prev = this.state.char.equippedGear[slot];
      if (prev) this._applyGearStats(prev, -1);
      this.state.char.equippedGear[slot] = gearId;
      this._applyGearStats(gearId, +1);
      this.save();
      this.emit('gearChange');
      return { ok:true, msg:`已装备「${gear.name}」` };
    },
    unequipGear(slot) {
      const gid = this.state.char.equippedGear[slot];
      if (!gid) return;
      this._applyGearStats(gid, -1);
      this.state.char.equippedGear[slot] = null;
      this.save();
      this.emit('gearChange');
    },
    _applyGearStats(gearId, sign) {
      const g = Game.GEAR_DATA[gearId];
      if (!g) return;
      const c = this.state.char;
      const b = g.buff || {};
      c.atk    += (b.atk    || 0) * sign;
      c.def    += (b.def    || 0) * sign;
      c.maxHp  += (b.maxHp  || 0) * sign;
      c.maxMp  += (b.maxMp  || 0) * sign;
      c.crit   += (b.crit   || 0) * sign;
      // 保证生命不为负
      c.hp = Math.min(c.hp, c.maxHp);
      c.mp = Math.min(c.mp, c.maxMp);
    },

    // ================================================
    //  💊 v3 丹药系统
    // ================================================
    usePill(pillId) {
      const p = Game.PILL_DATA[pillId];
      if (!p) return { ok:false, msg:'丹药不存在' };
      if (!this.state.char.pills[pillId] || this.state.char.pills[pillId] <= 0) {
        return { ok:false, msg:'没有该丹药' };
      }
      const c = this.state.char;
      let effectMsg = '';
      if (p.hp)  { c.hp = Math.min(c.maxHp, c.hp + p.hp); effectMsg += ` HP+${p.hp}`; }
      if (p.mp)  { c.mp = Math.min(c.maxMp, c.mp + p.mp); effectMsg += ` MP+${p.mp}`; }
      if (p.daoxin) { this.changeDaoxin(p.daoxin); effectMsg += ` 道心+${p.daoxin}`; }
      if (p.exp) { this.addExp(p.exp); effectMsg += ` 修为+${p.exp}`; }
      this.state.char.pills[pillId]--;
      this.save();
      return { ok:true, msg:`服下「${p.name}」，${effectMsg}` };
    },
    addPill(pillId, n) {
      n = n || 1;
      this.state.char.pills[pillId] = (this.state.char.pills[pillId] || 0) + n;
      this.save();
    },

    // ================================================
    //  🐉 v3 宠物系统
    // ================================================
    adoptPet(petId) {
      const p = Game.PET_DATA[petId];
      if (!p) return { ok:false, msg:'无此灵宠' };
      if (this.state.char.pet) return { ok:false, msg:'已有伴生灵宠。请先送走原宠。' };
      this.state.char.pet = {
        id: petId, name: p.name, emoji: p.emoji,
        level: 1, exp: 0,
        atk: p.atk || 5, hp: p.hp || 30
      };
      this.state.pets[petId] = this.state.pets[petId] || { level:1, exp:0 };
      this.save();
      this.emit('petChange');
      return { ok:true, msg:`「${p.name}」拜入你门下！` };
    },
    dismissPet() {
      this.state.char.pet = null;
      this.save();
      this.emit('petChange');
    },
    petGainExp(n) {
      const p = this.state.char.pet;
      if (!p) return;
      p.exp += n;
      // 升级：需要 level * 100 exp
      while (p.exp >= p.level * 100) {
        p.exp -= p.level * 100;
        p.level++;
        p.atk += 3;
        p.hp  += 10;
      }
      this.save();
    },

    // ================================================
    //  🏆 v3 成就系统
    // ================================================
    _checkAchievements() {
      if (!Game.ACHIEVEMENTS) return;
      const s = this.state;
      Object.keys(Game.ACHIEVEMENTS).forEach(aid => {
        const a = Game.ACHIEVEMENTS[aid];
        const rec = s.achievements[aid] = s.achievements[aid] || { progress: 0, done: false };
        if (rec.done) return;
        const cur = a.check(s);
        rec.progress = Math.min(a.target || 1, cur);
        if (cur >= (a.target || 1)) {
          rec.done = true;
          rec.doneAt = Date.now();
          if (a.reward) {
            if (a.reward.shi) this.addLingshi(a.reward.shi);
            if (a.reward.exp) this.addExp(a.reward.exp);
          }
          this.emit('achievementUnlock', { id: aid, achv: a });
        }
      });
      this.save();
    },

    // ================================================
    //  🗺 v3 大地图（visitedNodes 只是记录路径）
    // ================================================
    visitNode(nodeId) {
      if (!this.state.worldMap.visitedNodes.includes(nodeId)) {
        this.state.worldMap.visitedNodes.push(nodeId);
      }
      this.state.worldMap.currentNode = nodeId;
      this.save();
      this.emit('worldMapMove', { node: nodeId });
    },

    // ===== 导入/导出 =====
    exportSave() { return JSON.stringify(this.state, null, 2); },
    importSave(json) {
      try {
        const obj = JSON.parse(json);
        this.state = deepMerge(deepClone(DEFAULT_SAVE), migrate(obj));
        this.save();
        this.emit('imported');
        return true;
      } catch (e) {
        console.warn('[Game] 导入失败', e);
        return false;
      }
    },
  };

  // ==========================================================
  //  ⚔ v3 数据：装备（4 部位）
  // ==========================================================
  Game.GEAR_DATA = {
    // ==== 武器（weapon）====
    'weapon_iron_sword':    { name:'寒铁剑',   emoji:'🗡', slot:'weapon', rarity:'common', desc:'常见铁剑，锋利耐用。', buff:{ atk:5 } },
    'weapon_qing_feng':     { name:'青风剑',   emoji:'🗡', slot:'weapon', rarity:'fine',   desc:'铸剑派入门佳品。',    buff:{ atk:12, crit:0.05 } },
    'weapon_yueya':         { name:'月牙弯刀', emoji:'⚔',  slot:'weapon', rarity:'rare',   desc:'月华所铸，切金断玉。', buff:{ atk:22, crit:0.08 } },
    'weapon_falling_star':  { name:'落星剑',   emoji:'🌠', slot:'weapon', rarity:'epic',   desc:'星辰陨铁淬炼，一剑破空。', buff:{ atk:35, crit:0.12, maxMp:20 } },
    'weapon_dragon_slayer': { name:'屠龙鞭',   emoji:'🐲', slot:'weapon', rarity:'legend', desc:'传说中斩杀过孽龙的神兵。',   buff:{ atk:55, crit:0.15, maxHp:30 } },
    // ==== 衣袍（robe）====
    'robe_qingpao':      { name:'青罗袍',   emoji:'👘', slot:'robe', rarity:'common', desc:'新入宗门弟子袍。',           buff:{ def:3, maxHp:20 } },
    'robe_yunwen':       { name:'云纹道袍', emoji:'👘', slot:'robe', rarity:'fine',   desc:'云纹绣就，御风而行。',       buff:{ def:6, maxHp:40 } },
    'robe_baiyu':        { name:'白玉锦衣', emoji:'👘', slot:'robe', rarity:'rare',   desc:'白玉丝线织成，刀枪难入。',   buff:{ def:12, maxHp:80 } },
    'robe_xian':         { name:'霓裳羽衣', emoji:'🥋', slot:'robe', rarity:'epic',   desc:'仙女下凡遗落之物。',         buff:{ def:20, maxHp:120, maxMp:30 } },
    'robe_zhentian':     { name:'镇天神袍', emoji:'👘', slot:'robe', rarity:'legend', desc:'鸿蒙之气所化，天地不侵。',   buff:{ def:35, maxHp:200, maxMp:50 } },
    // ==== 法器（focus）====
    'focus_yushu':       { name:'玉书',     emoji:'📖', slot:'focus', rarity:'common', desc:'一卷入门法诀。',             buff:{ maxMp:15 } },
    'focus_qixing':      { name:'七星幡',   emoji:'🎏', slot:'focus', rarity:'fine',   desc:'七颗星宝嵌于幡上。',         buff:{ maxMp:30, crit:0.03 } },
    'focus_zhuji':       { name:'筑基铃',   emoji:'🔔', slot:'focus', rarity:'rare',   desc:'筑基修士随身法器。',         buff:{ maxMp:50, crit:0.06 } },
    'focus_taiji':       { name:'太极图',   emoji:'☯',  slot:'focus', rarity:'epic',   desc:'阴阳流转，玄妙无穷。',       buff:{ maxMp:80, crit:0.10, def:5 } },
    'focus_hongmeng':    { name:'鸿蒙珠',   emoji:'🔮', slot:'focus', rarity:'legend', desc:'开天辟地一枚珠。',           buff:{ maxMp:150, crit:0.15, atk:10 } },
    // ==== 头冠（crown）====
    'crown_muguan':      { name:'木簪',     emoji:'💇', slot:'crown', rarity:'common', desc:'寻常木簪，束发之用。',       buff:{ maxHp:10 } },
    'crown_yinguan':     { name:'银冠',     emoji:'👑', slot:'crown', rarity:'fine',   desc:'银丝所制。',                 buff:{ maxHp:25, maxMp:10 } },
    'crown_jinguan':     { name:'金冠',     emoji:'👑', slot:'crown', rarity:'rare',   desc:'纯金打造。',                 buff:{ maxHp:50, maxMp:20, def:3 } },
    'crown_wangzhe':     { name:'王者冠',   emoji:'👑', slot:'crown', rarity:'epic',   desc:'古国王者遗物。',             buff:{ maxHp:80, maxMp:40, def:6, crit:0.05 } },
    'crown_immortal':    { name:'仙帝冠',   emoji:'👑', slot:'crown', rarity:'legend', desc:'昔年仙帝加冕之物。',         buff:{ maxHp:150, maxMp:70, def:12, crit:0.10 } },
  };

  // ==========================================================
  //  💊 v3 数据：丹药
  // ==========================================================
  Game.PILL_DATA = {
    'pill_qixue':   { name:'气血丹',   emoji:'💊', rarity:'common', desc:'恢复气血 50 点。',           hp: 50,   cost: 60 },
    'pill_lingqi':  { name:'灵气丹',   emoji:'💊', rarity:'common', desc:'恢复灵力 30 点。',           mp: 30,   cost: 60 },
    'pill_zhuji':   { name:'筑基丹',   emoji:'🧪', rarity:'rare',   desc:'助你冲击境界，+80 修为。',   exp: 80,  cost: 200 },
    'pill_daoxin':  { name:'定心丹',   emoji:'🧪', rarity:'fine',   desc:'安神定志，+30 道心。',       daoxin: 30, cost: 120 },
    'pill_peiyuan': { name:'培元丹',   emoji:'💊', rarity:'fine',   desc:'温补根基，HP+80, MP+40。',   hp:80, mp:40, cost: 150 },
    'pill_jiuzhuan':{ name:'九转还魂丹', emoji:'✨', rarity:'legend', desc:'传说仙家宝丹，HP+300, MP+150, 修为+200。', hp:300, mp:150, exp:200, cost: 800 },
  };

  // ==========================================================
  //  🐉 v3 数据：灵宠
  // ==========================================================
  Game.PET_DATA = {
    'pet_baihu':    { name:'白虎幼崽', emoji:'🐯', rarity:'rare',   atk:12, hp:60,  desc:'凶兽血脉，天生攻击力高。', unlock:'击败 20 只妖兽' },
    'pet_qinglong': { name:'青龙幼苗', emoji:'🐲', rarity:'epic',   atk:15, hp:80,  desc:'龙族血脉，成长潜力惊人。', unlock:'物理化学各掌握 5 篇功法' },
    'pet_zhuque':   { name:'朱雀雏鸟', emoji:'🐦', rarity:'epic',   atk:20, hp:50,  desc:'火系凶兽，爆发力极强。',   unlock:'连击达到 30' },
    'pet_xuanwu':   { name:'玄武幼龟', emoji:'🐢', rarity:'rare',   atk:8,  hp:120, desc:'防御系灵宠，血厚肉盾。',   unlock:'完成 5 次每日任务' },
    'pet_qilin':    { name:'麒麟灵嗣', emoji:'🦄', rarity:'legend', atk:25, hp:100, desc:'吉兽血脉，助主人渡劫。',   unlock:'突破至元婴期' },
    'pet_huli':     { name:'狐狸小妖', emoji:'🦊', rarity:'fine',   atk:10, hp:40,  desc:'初阶灵宠，性格活泼。',     unlock:'免费领取' },
  };

  // ==========================================================
  //  🏆 v3 数据：成就（每条 check(state)→number，target 为达成阈值）
  // ==========================================================
  Game.ACHIEVEMENTS = {
    'achv_first_step':    { name:'初入道途', icon:'🚪', desc:'首次答题', target:1, reward:{shi:20}, check:(s)=>s.char.totalAnswered||0 },
    'achv_100_correct':   { name:'百战之心', icon:'⚔',  desc:'累计答对 100 题', target:100, reward:{shi:200,exp:100}, check:(s)=>s.char.totalCorrect||0 },
    'achv_500_correct':   { name:'千锤百炼', icon:'🔥', desc:'累计答对 500 题', target:500, reward:{shi:800,exp:500}, check:(s)=>s.char.totalCorrect||0 },
    'achv_1000_correct':  { name:'万法归宗', icon:'✨', desc:'累计答对 1000 题', target:1000,reward:{shi:2000,exp:1500}, check:(s)=>s.char.totalCorrect||0 },
    'achv_streak10':      { name:'连破十妖', icon:'💫', desc:'达成 10 连击', target:10, reward:{shi:100}, check:(s)=>s.char.bestStreak||0 },
    'achv_streak30':      { name:'一气呵成', icon:'🌟', desc:'达成 30 连击', target:30, reward:{shi:300, exp:100}, check:(s)=>s.char.bestStreak||0 },
    'achv_streak50':      { name:'心无旁骛', icon:'🌠', desc:'达成 50 连击', target:50, reward:{shi:800, exp:300}, check:(s)=>s.char.bestStreak||0 },
    'achv_realm_qi':      { name:'气感初生', icon:'🌱', desc:'突破至炼气期九层', target:9, reward:{shi:150}, check:(s)=>s.char.realmId||0 },
    'achv_realm_zhuji':   { name:'筑基有成', icon:'🏔', desc:'突破至筑基后期', target:12, reward:{shi:400,exp:200}, check:(s)=>s.char.realmId||0 },
    'achv_realm_jindan':  { name:'金丹大成', icon:'☯',  desc:'突破至金丹圆满', target:17, reward:{shi:1200}, check:(s)=>s.char.realmId||0 },
    'achv_realm_yuanying':{ name:'元婴出窍', icon:'👶', desc:'突破至元婴初期', target:18, reward:{shi:2000,exp:800}, check:(s)=>s.char.realmId||0 },
    'achv_realm_xian':    { name:'羽化登仙', icon:'👼', desc:'飞升真仙', target:27, reward:{shi:10000,exp:5000}, check:(s)=>s.char.realmId||0 },
    'achv_manual_10':     { name:'博学多闻', icon:'📚', desc:'参悟 10 篇功法', target:10, reward:{shi:200}, check:(s)=>Object.values(s.sects||{}).reduce((a,b)=>a+(b.masteredManuals||[]).length,0) },
    'achv_manual_30':     { name:'博采众长', icon:'📖', desc:'参悟 30 篇功法', target:30, reward:{shi:600,exp:300}, check:(s)=>Object.values(s.sects||{}).reduce((a,b)=>a+(b.masteredManuals||[]).length,0) },
    'achv_manual_60':     { name:'学富五车', icon:'📖', desc:'参悟 60 篇功法', target:60, reward:{shi:1500,exp:800}, check:(s)=>Object.values(s.sects||{}).reduce((a,b)=>a+(b.masteredManuals||[]).length,0) },
    'achv_battle_100':    { name:'百战之王', icon:'⚔',  desc:'完成 100 场妖兽战', target:100, reward:{shi:300}, check:(s)=>s.battle&&s.battle.totalBattles||0 },
    'achv_daoxin_full':   { name:'道心圆满', icon:'🧘', desc:'道心值达到 300', target:300, reward:{shi:200}, check:(s)=>s.char.daoxin||0 },
    'achv_cave_max':      { name:'仙人洞府', icon:'🏯', desc:'洞府升到 5 级', target:5, reward:{shi:500}, check:(s)=>s.cave&&s.cave.level||0 },
    'achv_secret_20':     { name:'秘境常客', icon:'🗺', desc:'探索秘境 20 次', target:20, reward:{shi:400}, check:(s)=>s.secretRealm&&s.secretRealm.events?s.secretRealm.events.length:0 },
    'achv_artifact_5':    { name:'法宝五藏', icon:'🎒', desc:'拥有 5 件法宝', target:5, reward:{shi:300}, check:(s)=>s.char.artifacts?s.char.artifacts.length:0 },
    'achv_gear_full':     { name:'披坚执锐', icon:'⚔',  desc:'装备全部 4 部位', target:4, reward:{shi:500}, check:(s)=>Object.values(s.char.equippedGear||{}).filter(Boolean).length },
    'achv_pet_owner':     { name:'与灵宠为伴', icon:'🐉', desc:'获得第一只灵宠', target:1, reward:{shi:200}, check:(s)=>s.char.pet?1:0 },
    'achv_all_six':       { name:'六艺齐修', icon:'🏆', desc:'6 科各参悟 3 篇功法', target:6, reward:{shi:1500,exp:600}, check:(s)=>['physics','chemistry','geography','chinese','math','english'].filter(k=>(s.sects[k]&&s.sects[k].masteredManuals||[]).length>=3).length },
    'achv_no_mistake':    { name:'心如止水', icon:'💧', desc:'正确率 ≥ 90%（题数 ≥ 100）', target:1, reward:{shi:800,exp:300}, check:(s)=>((s.char.totalAnswered||0)>=100 && ((s.char.totalCorrect||0)/(s.char.totalAnswered||1))>=0.9 ? 1 : 0) },
    'achv_daily_7':       { name:'七日之约', icon:'📅', desc:'连续 7 日完成每日任务', target:7, reward:{shi:400}, check:(s)=>s.char.dailyStreak||0 },
    'achv_demon_slain':   { name:'心魔尽渡', icon:'😇', desc:'清空所有心魔（错题）', target:1, reward:{shi:600,exp:200}, check:(s)=>((s.char.totalAnswered||0)>=50 && (s.heartDemons||[]).length===0 ? 1 : 0) },
    'achv_tower_climb':   { name:'登临塔顶', icon:'🗼', desc:'闯关塔通关 7 层', target:7, reward:{shi:1000,exp:500}, check:(s)=>s.char.maxTowerFloor||0 },
    'achv_spiritroot':    { name:'灵根天定', icon:'🎴', desc:'觉醒灵根', target:1, reward:{shi:100}, check:(s)=>s.char.spiritRoot?1:0 },
    'achv_night_owl':     { name:'凌晨修士', icon:'🌙', desc:'凌晨 1-5 点答题', target:1, reward:{shi:66}, check:(s)=>s.char.nightAnswered?1:0 },
    'achv_speed_learner': { name:'一日千里', icon:'🚀', desc:'单日修为 +500', target:500, reward:{shi:200}, check:(s)=>s.char.todayExpGain||0 },
  };

  global.Game = Game;
  global.REALMS = REALMS;

})(typeof window !== 'undefined' ? window : this);
