/* ===================================================
 * 《问道修仙学院》剧情 & 成就事件引擎 v3.0
 *
 * v3.0 相对 v1.0 的新增：
 *   + 成就监听：hookup 一次即可自动侦听 Game 事件（answer / battle_end / master_manual）
 *     并调用 Game._checkAchievements() 触发成就解锁 toast + 灵石奖励
 *   + 每日任务进度：answer/正确 / battle_end/胜利 / master_manual 事件都会调用
 *     Game._dailyProgress(type, n) 累计当日任务进度
 *   + 地图节点剧情：visitNode(nodeId) 时若 STORY_DATA 里有 map_<nodeId> 且没看过，
 *     自动播放对应剧情
 *   + 剧情场景可携带 v3 新字段：
 *       - line.hpDelta / mpDelta / daoxinDelta —— 直接改血/蓝/道心
 *       - line.pill / line.gear / line.pet —— 直接给道具/装备/宠物
 *       - line.achievement —— 直接解锁指定成就
 *   + 完全向后兼容 v1.0 剧情数据
 * =================================================== */

(function (global) {
  'use strict';

  // ============================================================
  //  Story 核心
  // ============================================================
  const Story = {

    /**
     * 播放一段场景（多段对话 + 可选分支）
     */
    play(sceneId, allScenes, onComplete) {
      const scenes = allScenes || global.STORY_DATA;
      const scene = scenes && scenes[sceneId];
      if (!scene) {
        console.warn('[Story] 找不到场景', sceneId);
        if (onComplete) onComplete();
        return;
      }
      this._renderScene(scene, scenes, onComplete);
      if (Game.state && !Game.state.story.seenScenes.includes(sceneId)) {
        Game.state.story.seenScenes.push(sceneId);
        Game.save();
      }
    },

    _applyLineEffects(line) {
      if (!line || !Game.state) return;
      const c = Game.state.char;
      if (line.flag) Game.setFlag(line.flag);
      if (line.reward) {
        if (line.reward.exp)     Game.addExp(line.reward.exp);
        if (line.reward.lingshi) Game.addLingshi(line.reward.lingshi);
        if (line.reward.daoxin)  Game.changeDaoxin(line.reward.daoxin);
      }
      // v3 新效果字段
      if (typeof line.hpDelta === 'number' && c.hp !== undefined) {
        c.hp = Math.max(0, Math.min(c.maxHp || 100, c.hp + line.hpDelta));
      }
      if (typeof line.mpDelta === 'number' && c.mp !== undefined) {
        c.mp = Math.max(0, Math.min(c.maxMp || 50, c.mp + line.mpDelta));
      }
      if (typeof line.daoxinDelta === 'number') Game.changeDaoxin(line.daoxinDelta);
      if (line.pill && Game.addPill) Game.addPill(line.pill, line.pillNum || 1);
      if (line.gear && Game.state.char.gearInventory) {
        if (!Game.state.char.gearInventory.includes(line.gear)) {
          Game.state.char.gearInventory.push(line.gear);
        }
      }
      if (line.pet && Game.adoptPet) Game.adoptPet(line.pet);
      if (line.achievement && Game.state.char.achievements) {
        if (!Game.state.char.achievements.includes(line.achievement)) {
          Game.state.char.achievements.push(line.achievement);
          if (Game.ACHIEVEMENTS && Game.ACHIEVEMENTS[line.achievement] && UI.toast) {
            const a = Game.ACHIEVEMENTS[line.achievement];
            UI.toast(`🏅 成就解锁：${a.name}`, 'success', 3500);
          }
        }
      }
      Game.save();
    },

    _renderScene(scene, allScenes, onComplete) {
      let mask = document.querySelector('.xx-modal-mask.story-mask');
      if (!mask) {
        mask = document.createElement('div');
        mask.className = 'xx-modal-mask story-mask';
        document.body.appendChild(mask);
      } else {
        mask.innerHTML = '';
      }
      const box = document.createElement('div');
      box.className = 'story-dialog';
      mask.appendChild(box);

      let idx = 0;
      const lines = scene.lines || [];

      const finish = () => {
        mask.remove();
        if (scene.reward) {
          if (scene.reward.exp)     Game.addExp(scene.reward.exp);
          if (scene.reward.lingshi) Game.addLingshi(scene.reward.lingshi);
        }
        if (scene.onEnd) scene.onEnd();
        if (onComplete) onComplete();
        UI.refreshTopbar && UI.refreshTopbar({ backHref: (location.pathname.indexOf('/subjects/')>=0 ? '../index.html' : undefined) });
      };

      const showLine = () => {
        if (idx >= lines.length) {
          if (scene.choices && scene.choices.length) {
            showChoices();
          } else {
            box.innerHTML += `<div style="text-align:right;margin-top:12px;">
              <button class="xx-btn xx-btn-primary" id="storyEnd">继续 →</button>
            </div>`;
            box.querySelector('#storyEnd').onclick = finish;
          }
          return;
        }
        const line = lines[idx];
        box.innerHTML = `
          <div class="story-speaker">
            <span class="story-speaker-avatar">${line.avatar || '👤'}</span>
            <span class="story-speaker-name">${line.speaker || ''}</span>
          </div>
          <div class="story-text">${line.text}</div>
          <div style="text-align:right;margin-top:14px;">
            <span style="font-size:12px;color:var(--xx-text-dim);">${idx + 1} / ${lines.length}</span>
            &nbsp;&nbsp;
            <button class="xx-btn xx-btn-sm" id="storyNext">${idx === lines.length - 1 && !(scene.choices && scene.choices.length) ? '收功 ✦' : '下一句 ▶'}</button>
          </div>
        `;
        this._applyLineEffects(line);
        box.querySelector('#storyNext').onclick = () => { idx++; showLine(); };
      };

      const showChoices = () => {
        let html = `
          <div class="story-speaker">
            <span class="story-speaker-avatar">❓</span>
            <span class="story-speaker-name">道心抉择</span>
          </div>
          <div class="story-text">${scene.choicePrompt || '你将如何应对？'}</div>
          <div class="story-choices">
        `;
        scene.choices.forEach((c, i) => {
          html += `<div class="story-choice" data-i="${i}">${c.text}</div>`;
        });
        html += '</div>';
        box.innerHTML = html;
        box.querySelectorAll('.story-choice').forEach(el => {
          el.onclick = () => {
            const ch = scene.choices[parseInt(el.dataset.i)];
            this._applyLineEffects(ch); // 复用同一批 effect 处理
            mask.remove();
            if (ch.next) {
              this.play(ch.next, allScenes, onComplete);
            } else {
              if (scene.onEnd) scene.onEnd();
              if (onComplete) onComplete();
              UI.refreshTopbar && UI.refreshTopbar({ backHref: (location.pathname.indexOf('/subjects/')>=0 ? '../index.html' : undefined) });
            }
          };
        });
      };

      showLine();
    },

    /**
     * 进入主页时自动尝试触发开场剧情、灵根抽取剧情、地图节点剧情
     */
    autoTriggerIfNeeded() {
      const data = global.STORY_DATA;
      if (!data || !Game.state) return;
      // 开场剧情
      if (!Game.state.story.seenScenes.includes('prologue_01')) {
        this.play('prologue_01', data, () => { UI.refreshTopbar && UI.refreshTopbar(); });
        return;
      }
      // 灵根抽取剧情（v2.0 新）
      if (!Game.state.char.spiritRoot && !Game.state.story.seenScenes.includes('spirit_root_intro')) {
        this.play('spirit_root_intro', data);
        return;
      }
    },

    /**
     * 地图节点访问时尝试播放 map_<nodeId> 剧情（v3 新）
     */
    tryPlayMapScene(nodeId) {
      const data = global.STORY_DATA;
      if (!data || !nodeId) return false;
      const sid = 'map_' + nodeId;
      if (data[sid] && !this.seen(sid)) {
        this.play(sid, data);
        return true;
      }
      return false;
    },

    seen(sceneId) {
      return Game.state && Game.state.story && Game.state.story.seenScenes.includes(sceneId);
    }
  };

  // ============================================================
  //  Achievement Listener 成就监听器（v3 新）
  //  自动在 Game 事件流上监听并触发成就检查 + 每日任务
  // ============================================================
  const AchievementListener = {
    hooked: false,

    hookup() {
      if (this.hooked || !Game.on) return;
      this.hooked = true;

      // 答题事件
      Game.on('answer', (payload) => {
        payload = payload || {};
        // 每日任务：任意答题
        if (Game._dailyProgress) Game._dailyProgress('answer', 1);
        if (payload.correct && Game._dailyProgress) Game._dailyProgress('correct', 1);
        // 成就检查
        if (Game._checkAchievements) Game._checkAchievements();
      });

      // 战斗结束
      Game.on('battle_end', (payload) => {
        payload = payload || {};
        if (Game._dailyProgress) Game._dailyProgress('battle', 1);
        if (payload.win) {
          if (Game._dailyProgress) Game._dailyProgress('win', 1);
          if (payload.boss && Game._dailyProgress) Game._dailyProgress('boss', 1);
        }
        if (Game._checkAchievements) Game._checkAchievements();
      });

      // 掌握功法
      Game.on('master_manual', (payload) => {
        if (Game._dailyProgress) Game._dailyProgress('master', 1);
        if (Game._checkAchievements) Game._checkAchievements();
      });

      // 突破境界
      Game.on('breakthrough', (payload) => {
        if (Game._dailyProgress) Game._dailyProgress('breakthrough', 1);
        if (Game._checkAchievements) Game._checkAchievements();
        // 播放对应境界剧情
        if (payload && payload.realmId && global.STORY_DATA) {
          const sid = 'breakthrough_' + payload.realmId;
          if (global.STORY_DATA[sid] && !Story.seen(sid)) {
            setTimeout(() => Story.play(sid, global.STORY_DATA), 400);
          }
        }
      });

      // 秘境探索
      Game.on('secret_realm', () => {
        if (Game._dailyProgress) Game._dailyProgress('secret', 1);
        if (Game._checkAchievements) Game._checkAchievements();
      });

      // 打坐
      Game.on('meditate', () => {
        if (Game._dailyProgress) Game._dailyProgress('meditate', 1);
        if (Game._checkAchievements) Game._checkAchievements();
      });

      console.log('[AchievementListener] v3 hooked ✓');
    }
  };

  // 全局暴露
  global.Story = Story;
  global.AchievementListener = AchievementListener;

  // 页面加载完成后自动 hookup
  if (typeof window !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => {
        setTimeout(() => AchievementListener.hookup(), 100);
      });
    } else {
      setTimeout(() => AchievementListener.hookup(), 100);
    }
  }

})(typeof window !== 'undefined' ? window : this);
