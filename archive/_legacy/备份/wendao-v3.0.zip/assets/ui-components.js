/* ===================================================
 * 《问道修仙学院》UI 通用组件 v2.0
 * v1.0：顶部状态栏 / 弹窗 / Toast / 角色面板 / 境界突破
 * v2.0 新增：灵根抽取 / 法宝阁 / 洞府 / 秘境 / 每日任务 /
 *            战斗技能栏 / 答题特效 / 灵气粒子背景
 * =================================================== */

(function (global) {
  'use strict';

  const UI = {

    // ====== Toast 飘字 ======
    toast(text, type = 'info', dur = 2800) {
      let wrap = document.querySelector('.xx-toast-wrap');
      if (!wrap) {
        wrap = document.createElement('div');
        wrap.className = 'xx-toast-wrap';
        document.body.appendChild(wrap);
      }
      const t = document.createElement('div');
      t.className = 'xx-toast ' + type;
      t.textContent = text;
      wrap.appendChild(t);
      setTimeout(() => { t.remove(); }, dur + 200);
    },

    // ====== 顶部状态栏（v3.0：增加 HP/MP + 灵根徽章） ======
    renderTopbar(opts = {}) {
      if (Game._ensureV2Fields) Game._ensureV2Fields();
      const c = Game.state.char;
      const realm = Game.currentRealm();
      const backHref = opts.backHref || 'index.html';
      const inSubPage = !!opts.backHref;
      const root = Game.getSpiritRoot && Game.getSpiritRoot();
      const rootBadge = root ? `<span class="xx-stat root-badge">${root.icon} ${root.name}</span>` : '';
      const hpPct = Math.round((c.hp||0) / (c.maxHp||1) * 100);
      const mpPct = Math.round((c.mp||0) / (c.maxMp||1) * 100);
      const html = `
        <div class="xx-topbar">
          <div class="brand">
            <a href="${backHref}" style="color:inherit;text-decoration:none;">⚔ 问道修仙学院</a>
            <span class="v-tag">v3.0</span>
          </div>
          <div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center;">
            <span class="xx-stat xx-realm-tag">${realm.name}</span>
            ${rootBadge}
            <span class="xx-stat" title="气血"><span>❤️</span> <b>${c.hp}/${c.maxHp}</b></span>
            <span class="xx-stat" title="灵力"><span>💫</span> <b>${c.mp}/${c.maxMp}</b></span>
            <span class="xx-stat"><span>💎</span> <b>${c.lingshi}</b></span>
            <span class="xx-stat"><span>🔥</span> <b>${c.streak}</b></span>
            ${ inSubPage ? `<a href="${backHref}" class="xx-btn">⬅ 山门</a>` : ''}
          </div>
        </div>
      `;
      return html;
    },

    refreshTopbar(opts = {}) {
      const old = document.querySelector('.xx-topbar');
      if (!old) return;
      const tmp = document.createElement('div');
      tmp.innerHTML = this.renderTopbar(opts);
      old.replaceWith(tmp.firstElementChild);
    },

    // ====== 弹窗 ======
    modal(opts = {}) {
      const { title = '', body = '', actions = [], onClose } = opts;
      const mask = document.createElement('div');
      mask.className = 'xx-modal-mask';

      const m = document.createElement('div');
      m.className = 'xx-modal';
      m.innerHTML = `
        <button class="xx-modal-close" aria-label="关闭">×</button>
        ${title ? `<h3 class="xx-modal-title">${title}</h3>` : ''}
        <div class="xx-modal-body">${body}</div>
        ${actions.length ? `<div class="quest-actions" style="margin-top:16px;justify-content:flex-end;"></div>` : ''}
      `;

      const close = () => {
        mask.remove();
        if (onClose) onClose();
      };

      m.querySelector('.xx-modal-close').onclick = close;
      mask.onclick = (e) => { if (e.target === mask) close(); };

      if (actions.length) {
        const aw = m.querySelector('.quest-actions');
        actions.forEach(a => {
          const b = document.createElement('button');
          b.className = 'xx-btn ' + (a.primary ? 'xx-btn-primary' : '');
          b.textContent = a.label;
          b.onclick = () => {
            if (a.onClick && a.onClick() === false) return; // 返回 false 阻止关闭
            close();
          };
          aw.appendChild(b);
        });
      }

      mask.appendChild(m);
      document.body.appendChild(mask);
      return { close, mask, m };
    },

    confirm(text, onYes) {
      return this.modal({
        title: '⚠ 确认',
        body: `<p>${text}</p>`,
        actions: [
          { label: '取消' },
          { label: '确定', primary: true, onClick: onYes }
        ],
      });
    },

    // ====== 境界突破特效 ======
    breakthrough(realm) {
      const mask = document.createElement('div');
      mask.className = 'breakthrough-mask';
      mask.innerHTML = `
        <div class="breakthrough-text">突 破</div>
        <div class="breakthrough-realm">${realm.name}</div>
        <div style="color:#f5c97a;margin-top:14px;font-size:14px;letter-spacing:2px;">${realm.sub}</div>
      `;
      document.body.appendChild(mask);
      setTimeout(() => mask.remove(), 2200);
      this.toast(`恭喜突破至「${realm.name}」`, 'success', 3500);
    },

    // ====== 角色面板（v3.0：2D 立绘 + HP/MP + 装备预览） ======
    renderCharPanel() {
      if (Game._ensureV2Fields) Game._ensureV2Fields();
      const c = Game.state.char;
      const realm = Game.currentRealm();
      const next = Game.nextRealm();
      const progress = Math.round(Game.realmProgress() * 100);
      const acc = (Game.accuracy() * 100).toFixed(1);
      const hpPct = Math.round((c.hp||0) / (c.maxHp||1) * 100);
      const mpPct = Math.round((c.mp||0) / (c.maxMp||1) * 100);
      const pet = c.pet;
      const petBadge = pet ? `<div style="margin-top:8px;font-size:12px;color:var(--xx-purple);">🐉 ${pet.emoji} ${pet.name} · Lv.${pet.level}</div>` : '';
      return `
        <div class="char-panel">
          <div class="char-avatar-box">
            <div class="char-portrait">
              <div class="char-portrait-body">
                <span class="char-portrait-emoji">${c.avatar||'🧙'}</span>
              </div>
            </div>
            <div class="char-name">${c.name}</div>
            <div style="color:var(--xx-text-dim);font-size:12px;margin-top:4px;">${c.title}</div>
            <div style="margin-top:12px;">
              <span class="xx-stat xx-realm-tag">${realm.name}</span>
            </div>
            <div style="font-size:12px;color:var(--xx-text-soft);margin-top:6px;">${realm.sub}</div>
            ${petBadge}
          </div>
          <div class="char-info-box">
            <div style="font-family:var(--xx-font-art);font-size:16px;color:var(--xx-gold);letter-spacing:2px;">⚡ 修为进度</div>
            <div class="cult-bar-wrap">
              <div class="cult-bar"><div class="cult-bar-fill" style="width:${progress}%"></div></div>
              <div class="cult-bar-label">
                <span>${c.exp} / ${next ? next.need : c.exp}</span>
                <span>${next ? `距「${next.name}」${next.need - c.exp} 修为` : '已至飞升真仙'}</span>
              </div>
            </div>
            <!-- v3：HP / MP 双条状态 -->
            <div class="cult-bar-wrap" style="margin-top:10px;">
              <div style="font-size:11px;color:var(--xx-text-dim);">❤ 气血  ${c.hp} / ${c.maxHp}</div>
              <div class="cult-bar" style="height:8px;"><div class="cult-bar-fill" style="width:${hpPct}%;background:var(--v3-hp);"></div></div>
            </div>
            <div class="cult-bar-wrap" style="margin-top:6px;">
              <div style="font-size:11px;color:var(--xx-text-dim);">💫 灵力  ${c.mp} / ${c.maxMp}</div>
              <div class="cult-bar" style="height:8px;"><div class="cult-bar-fill" style="width:${mpPct}%;background:var(--v3-mp);"></div></div>
            </div>

            <div class="stat-grid">
              <div class="stat-item cyan"><div class="lab">💎 灵石</div><div class="val">${c.lingshi}</div></div>
              <div class="stat-item green"><div class="lab">🧘 道心</div><div class="val">${c.daoxin}</div></div>
              <div class="stat-item gold"><div class="lab">⚔ 攻击</div><div class="val">${c.atk}</div></div>
              <div class="stat-item purple"><div class="lab">🛡 防御</div><div class="val">${c.def}</div></div>
              <div class="stat-item purple"><div class="lab">🔥 最高连击</div><div class="val">${c.bestStreak}</div></div>
              <div class="stat-item"><div class="lab">📊 正确率</div><div class="val">${acc}%</div></div>
              <div class="stat-item"><div class="lab">⚔ 共答题</div><div class="val">${c.totalAnswered}</div></div>
              <div class="stat-item red"><div class="lab">😈 心魔</div><div class="val">${Game.heartDemons().length}</div></div>
            </div>
          </div>
        </div>
      `;
    },

    // ====== 宗门地图 ======
    renderSectMap() {
      const sects = [
        { key:'physics',   icon:'⚡', name:'雷霆殿', subject:'物理', desc:'掌天地之力，操控雷霆万钧。运动、波动、电磁、热学，皆在掌中。', cls:'sect-physics'  },
        { key:'chemistry', icon:'⚗',  name:'丹鼎峰', subject:'化学', desc:'炼丹问道，元素为基。从化学反应到有机分子，洞察物质本源。',     cls:'sect-chemistry'},
        { key:'geography', icon:'🌏', name:'山河阁', subject:'地理', desc:'纵观天地，山川河流，气候洋流，区域兴衰皆入眼帘。',           cls:'sect-geography'},
        { key:'chinese',   icon:'📜', name:'文渊阁', subject:'语文', desc:'笔走龙蛇，文以载道。古诗文阅读、现代文鉴赏、议论文写作。',    cls:'sect-chinese'  },
        { key:'math',      icon:'🔢', name:'推衍宫', subject:'数学', desc:'演算天机，函数为剑，几何作盾。万物皆数，数即道也。',          cls:'sect-math'     },
        { key:'english',   icon:'🌐', name:'译灵堂', subject:'英语', desc:'通晓异界灵语，沟通天下。词汇、语法、阅读、写作。',           cls:'sect-english'  },
      ];
      let html = '<div class="sect-map">';
      sects.forEach(s => {
        const st = Game.state.sects[s.key] || { masteredManuals:[], defeatedQuests:[] };
        const mCnt = st.masteredManuals.length;
        const qCnt = st.defeatedQuests.length;
        const locked = !st.unlocked;
        const cls = `sect-card ${s.cls} ${locked ? 'locked' : ''}`;
        const href = locked ? 'javascript:void(0)' : `subjects/${s.key}.html`;
        // 用 manual 数估算总进度（如果数据已加载）
        const totalManuals = (global[`${s.key.toUpperCase()}_MANUALS`] || []).length || 0;
        const totalBank = (global[`${s.key.toUpperCase()}_BANK`] || []).length || 0;
        const totalAll = totalManuals + totalBank;
        const done = mCnt + qCnt;
        const pct = totalAll > 0 ? Math.min(100, Math.round(done / totalAll * 100)) : 0;
        html += `
          <a class="${cls}" href="${href}">
            <span class="sect-icon">${s.icon}</span>
            <div class="sect-subject">${s.subject}</div>
            <div class="sect-name">${s.name}</div>
            <div class="sect-desc">${s.desc}</div>
            <div class="sect-progress">
              功法 ${mCnt} / 妖兽 ${qCnt}
              <div class="sect-progress-bar"><div class="sect-progress-fill" style="width:${pct}%"></div></div>
            </div>
          </a>
        `;
      });
      html += '</div>';
      return html;
    },

    // ====== 心魔录视图 ======
    renderHeartDemons() {
      const list = Game.heartDemons();
      if (!list.length) {
        return `<div class="xx-empty">心境空明，无心魔缠身 🌿</div>`;
      }
      const sectName = { physics:'⚡雷霆殿', chemistry:'⚗丹鼎峰', geography:'🌏山河阁',
                         chinese:'📜文渊阁', math:'🔢推衍宫', english:'🌐译灵堂' };
      let html = '<div class="heart-demon-list">';
      list.forEach(d => {
        const bank = global[`${d.sect.toUpperCase()}_BANK`] || [];
        const q = bank.find(x => x.id === d.qid);
        const qDesc = q ? (q.q.length > 50 ? q.q.slice(0, 50) + '…' : q.q) : '(题目数据未加载)';
        html += `
          <div class="heart-demon-item" data-sect="${d.sect}" data-qid="${d.qid}">
            <span style="color:var(--xx-red);font-weight:700;">[${sectName[d.sect] || d.sect}]</span>
            ${qDesc}
            <div style="font-size:11px;color:var(--xx-text-dim);margin-top:4px;">
              失手 ${d.wrongCount} 次 · ${new Date(d.lastWrongAt).toLocaleString('zh-CN')}
              · <a href="subjects/${d.sect}.html#q=${d.qid}" style="color:var(--xx-cyan);">前往重练 →</a>
            </div>
          </div>
        `;
      });
      html += '</div>';
      return html;
    },

    // ============================================================
    //  v2.0 新增：灵根抽取
    // ============================================================
    showSpiritRootDraw(onPicked) {
      const roots = Object.values(Game.SPIRIT_ROOTS);
      let body = '<p style="color:var(--xx-text-soft);font-size:13.5px;line-height:1.7;margin-bottom:12px;">' +
        '入道之初，需测灵根。每个修士天赋不同，可影响日后修行速度。<br>' +
        '<b style="color:var(--xx-gold);">注意：灵根一经选定，不可更改！</b>请慎重抉择。</p>';
      body += '<div class="spirit-root-grid">';
      roots.forEach(r => {
        body += `
          <div class="spirit-root-card root-${r.id}" data-root="${r.id}">
            <span class="root-icon">${r.icon}</span>
            <div class="root-name">${r.name}</div>
            <div class="root-desc">${r.desc}</div>
          </div>
        `;
      });
      body += '</div>';
      body += '<div class="hint-bubble">提示：物化地选手建议优先考虑 <b>雷灵根</b>（物理大加成）、<b>火灵根</b>（化学大加成）或 <b>土灵根</b>（地理大加成）。</div>';
      const m = UI.modal({ title:'✦ 测灵根 · 入道之始', body, actions:[] });
      m.m.querySelectorAll('.spirit-root-card').forEach(card => {
        card.onclick = () => {
          const rid = card.dataset.root;
          UI.confirm(`确定选择「${Game.SPIRIT_ROOTS[rid].name}」吗？此选择不可更改。`, () => {
            Game.setSpiritRoot(rid);
            UI.toast(`你选择了「${Game.SPIRIT_ROOTS[rid].name}」，修行之路就此启程！`, 'success');
            m.close();
            if (onPicked) onPicked(rid);
          });
        };
      });
      return m;
    },

    // ============================================================
    //  v2.0 新增：法宝阁
    // ============================================================
    renderArtifactShop() {
      // v2.2 容错
      if (Game._ensureV2Fields) Game._ensureV2Fields();
      const arts = Game.ARTIFACTS || {};
      const owned = Game.state.char.artifacts || [];
      const equipped = Game.state.char.equippedArtifacts || [];
      let html = '<div class="xx-tip">🎒 法宝阁 · 每件法宝可永久增益。最多同时装备 3 件。</div>';
      html += '<div class="artifact-grid">';
      Object.keys(arts).forEach(aid => {
        const a = arts[aid];
        const has = owned.includes(aid);
        const eq  = equipped.includes(aid);
        const cls = `artifact-card ${has?'owned':''} ${eq?'equipped':''}`;
        let action = '';
        if (!has) {
          action = `<button class="iv-btn" data-buy="${aid}">💎 炼制 ${a.cost}</button>`;
        } else if (!eq) {
          action = `<button class="iv-btn ghost" data-equip="${aid}">⚔ 装备</button>`;
        } else {
          action = `<button class="iv-btn ghost" data-unequip="${aid}">⬇ 卸下</button>`;
        }
        html += `
          <div class="${cls}">
            <span class="artifact-icon">${a.icon}</span>
            <div class="artifact-name">${a.name}</div>
            <div class="artifact-desc">${a.desc}</div>
            <div class="artifact-cost">${has?'已拥有':`售价 ${a.cost} 灵石`}</div>
            <div class="artifact-actions">${action}</div>
          </div>
        `;
      });
      html += '</div>';
      return html;
    },
    bindArtifactShop(container, onChange) {
      container.querySelectorAll('[data-buy]').forEach(b => {
        b.onclick = () => {
          const r = Game.buyArtifact(b.dataset.buy);
          UI.toast(r.msg, r.ok?'success':'error');
          if (r.ok && onChange) onChange();
        };
      });
      container.querySelectorAll('[data-equip]').forEach(b => {
        b.onclick = () => {
          if (Game.equipArtifact(b.dataset.equip)) {
            UI.toast('已装备', 'success');
            if (onChange) onChange();
          }
        };
      });
      container.querySelectorAll('[data-unequip]').forEach(b => {
        b.onclick = () => {
          Game.unequipArtifact(b.dataset.unequip);
          UI.toast('已卸下', 'info');
          if (onChange) onChange();
        };
      });
    },

    // ============================================================
    //  v2.0 新增：洞府
    // ============================================================
    renderCave() {
      // v2.2 容错
      if (Game._ensureV2Fields) Game._ensureV2Fields();
      const cave = Game.state.cave;
      const canM = Game.canMeditate();
      const cdMin = canM ? 0 : Math.ceil((30*60*1000 - (Date.now() - cave.lastMeditateAt))/60000);
      let html = `
        <div class="cave-stage">
          <div class="cave-bg-stars"></div>
          <div class="cave-avatar">${Game.state.char.avatar||'🧘'}</div>
          <div class="cave-info">
            <div class="cave-title">${cave.level >= 5?'飞升宝殿':(cave.level >= 3?'灵气洞府':'修士石洞')}</div>
            <div class="cave-level-tag">洞府等级 Lv.${cave.level}</div>
            <div style="margin-top:14px;color:var(--xx-text-soft);font-size:13px;">
              此处灵气浓郁，可助你恢复道心、参悟天地。
            </div>
          </div>
        </div>
        <div class="iv-controls" style="justify-content:center;margin-top:14px;">
          <button class="iv-btn" id="cave-meditate" ${canM?'':'disabled'}>
            🧘 ${canM?`打坐冥想（道心+30, 修为+${10*cave.level}）`:`冷却中（${cdMin} 分钟）`}
          </button>
          <button class="iv-btn ghost" id="cave-upgrade">
            ⏫ 升级洞府（${cave.level*500} 灵石）
          </button>
        </div>
      `;
      return html;
    },
    bindCave(container, onChange) {
      const btnM = container.querySelector('#cave-meditate');
      const btnU = container.querySelector('#cave-upgrade');
      if (btnM) btnM.onclick = () => {
        const r = Game.meditate();
        UI.toast(r.msg, r.ok?'success':'error');
        if (r.ok && onChange) onChange();
      };
      if (btnU) btnU.onclick = () => {
        UI.confirm(`花费 ${Game.state.cave.level*500} 灵石升级洞府？升级后打坐效果增强。`, () => {
          const r = Game.upgradeCave();
          UI.toast(r.msg, r.ok?'success':'error');
          if (r.ok && onChange) onChange();
        });
      };
    },

    // ============================================================
    //  v2.0 新增：秘境
    // ============================================================
    renderSecretRealm() {
      // v2.2 容错
      if (Game._ensureV2Fields) Game._ensureV2Fields();
      const sr = Game.state.secretRealm;
      const canE = Game.canEnterSecret();
      const cdMin = canE ? 0 : Math.ceil((60*60*1000 - (Date.now() - sr.lastEnterAt))/60000);
      let html = `
        <div class="secret-realm-stage">
          <div style="text-align:center;padding:30px 10px;">
            <div style="font-size:48px;">🗺</div>
            <div style="font-family:var(--xx-font-art);font-size:20px;color:var(--xx-purple);letter-spacing:4px;margin-top:10px;">秘境探索</div>
            <div style="font-size:13px;color:var(--xx-text-soft);margin-top:6px;line-height:1.7;">
              传闻有上古遗迹蕴藏天材地宝、奇异机缘。<br>每一小时可探索一次。
            </div>
            <button class="iv-btn" id="sr-enter" ${canE?'':'disabled'} style="margin-top:16px;">
              ${canE?'🚪 进入秘境':`冷却中（${cdMin} 分钟）`}
            </button>
          </div>
        </div>
      `;
      if (sr.events && sr.events.length) {
        html += '<div class="xx-section-title" style="margin-top:18px;font-size:15px;">📜 历次奇遇</div>';
        sr.events.slice(0,8).forEach(e => {
          html += `<div class="secret-history-item"><b style="color:var(--xx-purple);">${e.msg}</b> <span style="color:var(--xx-green);">${e.detail||''}</span></div>`;
        });
      }
      return html;
    },
    bindSecretRealm(container, onChange) {
      const btn = container.querySelector('#sr-enter');
      if (btn) btn.onclick = () => {
        const r = Game.enterSecret();
        if (!r.ok) { UI.toast(r.msg, 'error'); return; }
        // 弹窗显示奇遇
        UI.modal({
          title: '✦ 秘境奇遇',
          body: `
            <div class="secret-event-card">
              <div class="secret-event-msg">${r.event.msg}</div>
              <div class="secret-event-detail">${r.detail}</div>
            </div>
          `,
          actions: [{ label:'继续修行', primary:true }]
        });
        if (onChange) onChange();
      };
    },

    // ============================================================
    //  v2.0 新增：每日任务
    // ============================================================
    renderDailyTasks() {
      // v2.2 容错：如果今日任务还未生成，主动调一次
      if (Game._ensureV2Fields) Game._ensureV2Fields();
      if (Game._refreshDaily) Game._refreshDaily();
      const tasks = (Game.state.daily && Game.state.daily.tasks) || [];
      if (!tasks.length) return '<div class="xx-empty">每日任务加载中…</div>';
      let html = '<div class="xx-tip">📅 每日任务 · 子夜 0:00 刷新。完成后可领取丰厚奖励。</div>';
      tasks.forEach(t => {
        const pct = Math.min(100, Math.round(t.progress/t.target*100));
        const done = t.progress >= t.target;
        html += `
          <div class="daily-task ${done?'done':''} ${t.claimed?'claimed':''}">
            <div class="task-info">
              <div class="task-desc">${t.desc}</div>
              <div class="task-progress-bar">
                <div class="task-progress-fill" style="width:${pct}%"></div>
              </div>
              <div class="task-reward">进度 ${t.progress}/${t.target} · 奖励：+${t.reward.exp}修为 +${t.reward.shi}灵石</div>
            </div>
            ${ t.claimed ? '<span style="color:var(--xx-text-dim);font-size:12px;">✓ 已领取</span>'
               : (done ? `<button class="iv-btn" data-claim="${t.id}">🎁 领取</button>`
                  : '<span style="color:var(--xx-text-dim);font-size:12px;">进行中</span>') }
          </div>
        `;
      });
      return html;
    },
    bindDailyTasks(container, onChange) {
      container.querySelectorAll('[data-claim]').forEach(b => {
        b.onclick = () => {
          const r = Game.claimDaily(b.dataset.claim);
          UI.toast(r.msg, r.ok?'success':'error');
          if (r.ok && onChange) onChange();
        };
      });
    },

    // ============================================================
    //  v2.0 新增：答题特效（暴击爆发/正误反馈）
    // ============================================================
    showCombo(text) {
      const el = document.createElement('div');
      el.className = 'combo-burst';
      el.textContent = text;
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 1200);
    },
    showAnswerFx(correct) {
      const el = document.createElement('div');
      el.className = 'answer-fx';
      el.textContent = correct ? '⚔' : '💔';
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 900);
    },

    // ============================================================
    //  v2.0 新增：灵气粒子背景
    // ============================================================
    initQiParticles() {
      if (document.querySelector('.qi-particles')) return;
      const wrap = document.createElement('div');
      wrap.className = 'qi-particles';
      for (let i=0; i<10; i++) {
        const p = document.createElement('div');
        p.className = 'qi-particle';
        p.style.left = (Math.random()*100) + '%';
        p.style.animationDelay = (Math.random()*8) + 's';
        p.style.animationDuration = (6 + Math.random()*4) + 's';
        if (Math.random() > 0.6) p.style.background = 'var(--xx-purple)';
        wrap.appendChild(p);
      }
      document.body.appendChild(wrap);
    },

    // ================================================
    //  🗺 v3 新增：世界大地图
    // ================================================
    renderWorldMap() {
      if (Game._ensureV2Fields) Game._ensureV2Fields();
      const wm = Game.state.worldMap;
      // 8 个节点位置（800×480 SVG 坐标）
      const NODES = [
        { id:'start',     name:'问道山门', sub:'缘起之地',       x:400, y:70,  emoji:'⛩', href:null },
        { id:'physics',   name:'雷震殿',   sub:'物理 / 18 篇功法', x:150, y:170, emoji:'⚡', href:'subjects/physics.html' },
        { id:'chemistry', name:'丹鼎峰',   sub:'化学 / 11 篇功法', x:650, y:170, emoji:'⚗',  href:'subjects/chemistry.html' },
        { id:'geography', name:'山河阁',   sub:'地理 / 11 篇功法', x:70,  y:320, emoji:'🌏', href:'subjects/geography.html' },
        { id:'chinese',   name:'文渊阁',   sub:'语文 / 9 篇功法',  x:280, y:340, emoji:'📜', href:'subjects/chinese.html' },
        { id:'math',      name:'推衍宫',   sub:'数学 / 9 篇功法',  x:520, y:340, emoji:'🔢', href:'subjects/math.html' },
        { id:'english',   name:'译灵堂',   sub:'英语 / 7 篇功法',  x:730, y:320, emoji:'🌐', href:'subjects/english.html' },
        { id:'tower',     name:'飞升宝塔', sub:'高考 / 终极塔',      x:400, y:430, emoji:'🗼', href:'#tower' },
      ];
      const paths = [
        ['start','physics'], ['start','chemistry'],
        ['physics','geography'], ['physics','chinese'],
        ['chemistry','math'], ['chemistry','english'],
        ['geography','chinese'], ['chinese','math'], ['math','english'],
        ['geography','tower'], ['english','tower'], ['chinese','tower'], ['math','tower']
      ];
      const nMap = {};
      NODES.forEach(n => nMap[n.id] = n);
      const nodeById = id => nMap[id];

      let svg = `<svg class="world-map-svg" viewBox="0 0 800 480" preserveAspectRatio="xMidYMid meet">`;
      // 背景远山 (装饰)
      svg += `<defs>
        <radialGradient id="wm-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stop-color="rgba(178,136,255,0.35)"/><stop offset="100%" stop-color="transparent"/>
        </radialGradient>
        <linearGradient id="wm-cloud" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="rgba(178,136,255,0.20)"/><stop offset="100%" stop-color="transparent"/>
        </linearGradient>
      </defs>`;
      // 云雾 (多层)
      svg += `<ellipse cx="200" cy="460" rx="260" ry="40" fill="url(#wm-cloud)" class="cloud"/>`;
      svg += `<ellipse cx="600" cy="470" rx="260" ry="35" fill="url(#wm-cloud)" class="cloud"/>`;
      // 远山（三角）
      svg += `<polygon class="mountain" points="0,470 100,300 200,400 260,340 340,460" fill="rgba(30,25,60,0.6)"/>`;
      svg += `<polygon class="mountain" points="460,470 540,340 620,400 720,300 800,470" fill="rgba(30,25,60,0.6)"/>`;
      // 星星
      for (let i = 0; i < 20; i++) {
        const x = Math.random()*800; const y = Math.random()*280;
        svg += `<circle cx="${x}" cy="${y}" r="${Math.random()*1.5+0.5}" fill="#fff" opacity="${0.3+Math.random()*0.5}"/>`;
      }
      // 路径
      paths.forEach(([a,b]) => {
        const A = nodeById(a), B = nodeById(b);
        if (!A || !B) return;
        // 绘制一条弧线
        const mx = (A.x+B.x)/2, my = (A.y+B.y)/2 - 20;
        svg += `<path class="path-line" d="M ${A.x} ${A.y} Q ${mx} ${my} ${B.x} ${B.y}"/>`;
      });
      // 节点
      NODES.forEach(n => {
        const unlocked = wm.unlocked[n.id] !== false;
        const cls = 'location' + (unlocked ? '' : ' locked');
        const href = unlocked ? (n.href||'') : '';
        svg += `<g class="${cls}" data-node="${n.id}" data-href="${href}">`;
        // 光晕
        if (unlocked) svg += `<circle cx="${n.x}" cy="${n.y}" r="38" fill="url(#wm-glow)"/>`;
        svg += `<circle class="loc-ring" cx="${n.x}" cy="${n.y}" r="28"/>`;
        // emoji
        svg += `<text class="loc-emoji" x="${n.x}" y="${n.y+11}" text-anchor="middle">${n.emoji}</text>`;
        // 标题
        svg += `<text class="loc-label" x="${n.x}" y="${n.y+50}">${n.name}</text>`;
        svg += `<text class="loc-sub" x="${n.x}" y="${n.y+66}">${n.sub}</text>`;
        svg += `</g>`;
      });
      svg += `</svg>`;
      return `<div class="world-map-wrap">${svg}
        <div class="world-map-legend">
          <span class="legend-item"><span class="lgd-dot"></span>已解锁</span>
          <span class="legend-item"><span class="lgd-dot locked"></span>未解锁</span>
          <span style="margin-left:auto;color:var(--xx-text-dim);">💡 点击任一宗门进入</span>
        </div>
      </div>`;
    },

    bindWorldMap(container) {
      container.querySelectorAll('.location').forEach(g => {
        if (g.classList.contains('locked')) {
          g.onclick = () => UI.toast('此地尚未解锁', 'error');
          return;
        }
        g.onclick = () => {
          const href = g.dataset.href;
          const node = g.dataset.node;
          Game.visitNode(node);
          if (href && href !== '#tower') { window.location.href = href; return; }
          if (href === '#tower') { UI.toast('飞升宝塔 — 请先突破金丹期后解锁', 'info'); return; }
          if (node === 'start') { UI.toast('你回到了问道山门', 'info'); }
        };
      });
    },

    // ================================================
    //  🏆 v3 成就殿堂
    // ================================================
    renderAchievements() {
      if (!Game.ACHIEVEMENTS) return '<div class="xx-empty">成就系统未启用</div>';
      Game._checkAchievements();
      const s = Game.state;
      const total = Object.keys(Game.ACHIEVEMENTS).length;
      const done = Object.values(s.achievements||{}).filter(x=>x.done).length;
      let html = `<div class="xx-tip">🏆 成就殿堂 · <b style="color:var(--xx-gold);">${done} / ${total}</b> 已解锁</div>`;
      html += '<div class="achv-grid">';
      Object.keys(Game.ACHIEVEMENTS).forEach(aid => {
        const a = Game.ACHIEVEMENTS[aid];
        const rec = (s.achievements||{})[aid] || { progress:0, done:false };
        const pct = Math.min(100, Math.round(rec.progress / (a.target||1) * 100));
        html += `
          <div class="achv-card ${rec.done?'done':'locked'}">
            <div class="achv-icon">${a.icon}</div>
            <div class="achv-name">${a.name}</div>
            <div class="achv-desc">${a.desc}</div>
            <div class="achv-progress"><div class="achv-progress-fill" style="width:${pct}%"></div></div>
            <div class="achv-progress-text">${rec.progress}/${a.target||1}${rec.done?' · ✅':''}</div>
          </div>
        `;
      });
      html += '</div>';
      return html;
    },

    // ================================================
    //  ⚔ v3 装备面板
    // ================================================
    renderGear() {
      if (Game._ensureV2Fields) Game._ensureV2Fields();
      const c = Game.state.char;
      const gears = Game.GEAR_DATA || {};
      const owned = c.gear || {};
      // 先列已装备四槽
      const slots = [
        { key:'weapon', name:'武器', icon:'🗡' },
        { key:'robe',   name:'衣袍', icon:'👘' },
        { key:'focus',  name:'法器', icon:'📖' },
        { key:'crown',  name:'头冠', icon:'👑' },
      ];
      let html = `<div class="xx-tip">⚔ 装备共 4 部位：武器 / 衣袍 / 法器 / 头冠。装备后得相应属性。</div>`;
      html += '<div class="equip-slots">';
      slots.forEach(sl => {
        const gid = c.equippedGear[sl.key];
        const g = gid && gears[gid];
        if (g) {
          html += `
            <div class="equip-slot equipped rarity-${g.rarity}" data-slot="${sl.key}" title="${g.desc}">
              <div class="slot-icon">${g.emoji}</div>
              <div class="slot-name" style="color:var(--xx-gold);">${g.name}</div>
            </div>`;
        } else {
          html += `
            <div class="equip-slot" data-slot="${sl.key}">
              <div class="slot-icon">${sl.icon}</div>
              <div class="slot-name">${sl.name}</div>
            </div>`;
        }
      });
      html += '</div>';
      // 背包（拥有的装备）
      html += '<div style="margin-top:14px;font-family:var(--xx-font-art);font-size:15px;color:var(--xx-gold);letter-spacing:3px;">🎒 背包·装备</div>';
      html += '<div class="inv-grid" style="margin-top:8px;">';
      let hasAny = false;
      Object.keys(gears).forEach(gid => {
        if (!owned[gid]) return;
        hasAny = true;
        const g = gears[gid];
        const equipped = Object.values(c.equippedGear).includes(gid);
        const buffText = Object.entries(g.buff || {}).map(([k,v])=>{
          const map = { atk:'攻击', def:'防御', maxHp:'气血', maxMp:'灵力', crit:'暴击' };
          const val = k==='crit' ? `${Math.round(v*100)}%` : `+${v}`;
          return `${map[k]||k}${val}`;
        }).join(' · ');
        html += `
          <div class="inv-item rarity-${g.rarity}" data-gear="${gid}" title="${g.desc}">
            <div class="inv-icon">${g.emoji}</div>
            <div class="inv-name">${g.name}</div>
            <div class="inv-tag">${buffText}</div>
            <button class="iv-btn" style="margin-top:6px;" data-eq-btn="${gid}">${equipped?'卸下':'装备'}</button>
          </div>`;
      });
      if (!hasAny) html += '<div class="xx-empty" style="grid-column:1/-1;">背包空空如也。<br>去秘境探索、或担当宗门讨伐得到装备。</div>';
      html += '</div>';
      return html;
    },

    bindGear(container, onChange) {
      const gears = Game.GEAR_DATA || {};
      container.querySelectorAll('[data-eq-btn]').forEach(b => {
        b.onclick = (e) => {
          e.stopPropagation();
          const gid = b.dataset.eqBtn;
          const g = gears[gid]; if (!g) return;
          const c = Game.state.char;
          const equipped = c.equippedGear[g.slot] === gid;
          if (equipped) {
            Game.unequipGear(g.slot);
            UI.toast('已卸下', 'info');
          } else {
            const r = Game.equipGear(gid);
            UI.toast(r.msg, r.ok?'success':'error');
          }
          if (onChange) onChange();
        };
      });
    },

    // ================================================
    //  🐉 v3 宠物面板
    // ================================================
    renderPets() {
      if (Game._ensureV2Fields) Game._ensureV2Fields();
      const c = Game.state.char;
      const pets = Game.PET_DATA || {};
      let html = '<div class="xx-tip">🐉 灵宠伴你修行，获取方式见各宠描述。同一时间只能携带一只。</div>';
      if (c.pet) {
        const p = c.pet;
        const nextExp = p.level * 100;
        const pct = Math.round(p.exp/nextExp * 100);
        html += `
          <div class="pet-card">
            <div class="pet-avatar">${p.emoji}</div>
            <div class="pet-info">
              <div class="pet-name">${p.name}</div>
              <div class="pet-lv">Lv.${p.level} · ${p.exp}/${nextExp} EXP</div>
              <div class="pet-stats">
                <span class="pet-stat">⚔ <b>${p.atk}</b></span>
                <span class="pet-stat">❤ <b>${p.hp}</b></span>
              </div>
              <div class="cult-bar" style="height:6px;margin-top:6px;"><div class="cult-bar-fill" style="width:${pct}%"></div></div>
              <button class="iv-btn ghost" style="margin-top:6px;" data-pet-dismiss="1">👋 送走</button>
            </div>
          </div>`;
      }
      html += '<div style="margin-top:14px;font-family:var(--xx-font-art);color:var(--xx-gold);letter-spacing:3px;">🌟 可拜入门下</div>';
      html += '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px;margin-top:8px;">';
      Object.keys(pets).forEach(pid => {
        const p = pets[pid];
        const owned = c.pet && c.pet.id === pid;
        html += `
          <div class="pet-card" style="opacity:${owned?0.55:1};">
            <div class="pet-avatar">${p.emoji}</div>
            <div class="pet-info">
              <div class="pet-name">${p.name}</div>
              <div class="pet-lv">${p.rarity==='legend'?'✨传奇':(p.rarity==='epic'?'💎史诗':'频维稀有')}</div>
              <div style="font-size:11px;color:var(--xx-text-soft);line-height:1.6;margin-top:4px;">${p.desc}</div>
              <div style="font-size:10.5px;color:var(--xx-cyan);margin-top:4px;">解锁：${p.unlock}</div>
              <button class="iv-btn" style="margin-top:6px;" data-pet-adopt="${pid}" ${owned?'disabled':''}>${owned?'已拥有':'🤍 拜入门下'}</button>
            </div>
          </div>`;
      });
      html += '</div>';
      return html;
    },

    bindPets(container, onChange) {
      container.querySelectorAll('[data-pet-adopt]').forEach(b => {
        b.onclick = () => {
          const r = Game.adoptPet(b.dataset.petAdopt);
          UI.toast(r.msg, r.ok?'success':'error');
          if (r.ok && onChange) onChange();
        };
      });
      const dis = container.querySelector('[data-pet-dismiss]');
      if (dis) dis.onclick = () => {
        UI.confirm('确定送走当前灵宠？不可恢复。', () => {
          Game.dismissPet();
          UI.toast('宠物已送走', 'info');
          if (onChange) onChange();
        });
      };
    },

    // ================================================
    //  💊 v3 丹药房
    // ================================================
    renderPills() {
      if (Game._ensureV2Fields) Game._ensureV2Fields();
      const c = Game.state.char;
      const pills = Game.PILL_DATA || {};
      let html = '<div class="xx-tip">💊 丹药可恢复 HP / MP / 道心，或直接增长修为。可在秘境/每日任务/名山大川得到。</div>';
      html += '<div class="inv-grid">';
      let any = false;
      Object.keys(pills).forEach(pid => {
        const p = pills[pid];
        const n = c.pills[pid] || 0;
        if (n <= 0) return;
        any = true;
        const effect = [];
        if (p.hp) effect.push(`HP+${p.hp}`);
        if (p.mp) effect.push(`MP+${p.mp}`);
        if (p.daoxin) effect.push(`道心+${p.daoxin}`);
        if (p.exp) effect.push(`修为+${p.exp}`);
        html += `
          <div class="inv-item rarity-${p.rarity}">
            <div class="inv-count">×${n}</div>
            <div class="inv-icon">${p.emoji}</div>
            <div class="inv-name">${p.name}</div>
            <div class="inv-tag">${effect.join(' · ')}</div>
            <button class="iv-btn" style="margin-top:6px;" data-use-pill="${pid}">服用</button>
          </div>`;
      });
      if (!any) html += '<div class="xx-empty" style="grid-column:1/-1;">丹室空空。<br>去秘境探索、或完成每日任务获取丹药。</div>';
      html += '</div>';
      return html;
    },

    bindPills(container, onChange) {
      container.querySelectorAll('[data-use-pill]').forEach(b => {
        b.onclick = () => {
          const r = Game.usePill(b.dataset.usePill);
          UI.toast(r.msg, r.ok?'success':'error');
          if (r.ok && onChange) onChange();
        };
      });
    },

    // ================================================
    //  ⚔ v3 战斗场景
    //  用法：UI.openBattle({ enemy:{name,emoji,hp,atk}, question:{...}, onWin, onLose })
    // ================================================
    openBattle(opts) {
      opts = opts || {};
      const enemy = Object.assign({ name:'妖兽', emoji:'👿', hp:100, maxHp:100, atk:12 }, opts.enemy || {});
      enemy.maxHp = enemy.maxHp || enemy.hp;
      const c = Game.state.char;

      // 建面板
      const mask = document.createElement('div');
      mask.className = 'xx-modal-mask';
      const scene = document.createElement('div');
      scene.className = 'xx-modal';
      scene.style.maxWidth = '760px';
      scene.style.padding = '0';
      scene.innerHTML = `
        <button class="xx-modal-close">×</button>
        <div class="battle-scene">
          <div class="battle-bg"></div>
          <div class="battle-stage">
            <div class="battle-hero">
              <div class="battle-portrait hero-portrait">${c.avatar||'🧙'}</div>
              <div class="battle-name">${c.name}</div>
              <div class="battle-hp-wrap">
                <div class="battle-hp"><div class="battle-hp-fill hero-hp" style="width:${c.hp/c.maxHp*100}%"></div></div>
                <div class="battle-mp"><div class="battle-mp-fill hero-mp" style="width:${c.mp/c.maxMp*100}%"></div></div>
                <div class="battle-hp-label"><span class="hero-hp-txt">${c.hp}/${c.maxHp}</span><span class="hero-mp-txt">MP ${c.mp}/${c.maxMp}</span></div>
              </div>
            </div>
            <div class="battle-enemy">
              <div class="battle-portrait enemy-portrait">${enemy.emoji}</div>
              <div class="battle-name" style="color:var(--xx-red);">${enemy.name}</div>
              <div class="battle-hp-wrap">
                <div class="battle-hp"><div class="battle-hp-fill enemy-hp" style="width:100%"></div></div>
                <div class="battle-hp-label"><span class="enemy-hp-txt">${enemy.hp}/${enemy.maxHp}</span><span>攻击 ${enemy.atk}</span></div>
              </div>
            </div>
          </div>
          <div class="battle-control">
            <div class="skill-bar">
              <span class="skill-btn" data-skill="basic">⚔ 平取 <span class="skill-cost">免费</span></span>
              <span class="skill-btn" data-skill="lightning">⚡ 天雷诀 <span class="skill-cost">20 MP ·2伤</span></span>
              <span class="skill-btn" data-skill="fireball">🔥 火球术 <span class="skill-cost">15 MP ·1.5伤</span></span>
              <span class="skill-btn" data-skill="heal">💚 小循环 · HP+30 <span class="skill-cost">10 MP</span></span>
            </div>
            <div class="battle-log" style="font-size:11.5px;color:var(--xx-text-dim);min-height:14px;margin-bottom:6px;"></div>
            <div class="battle-question-wrap"></div>
          </div>
        </div>
      `;
      mask.appendChild(scene);
      document.body.appendChild(mask);

      let selectedSkill = 'basic';
      const heroEl = scene.querySelector('.hero-portrait');
      const enemyEl = scene.querySelector('.enemy-portrait');
      const heroHpFill = scene.querySelector('.hero-hp');
      const heroMpFill = scene.querySelector('.hero-mp');
      const heroHpTxt = scene.querySelector('.hero-hp-txt');
      const heroMpTxt = scene.querySelector('.hero-mp-txt');
      const enemyHpFill = scene.querySelector('.enemy-hp');
      const enemyHpTxt = scene.querySelector('.enemy-hp-txt');
      const logEl = scene.querySelector('.battle-log');
      const qWrap = scene.querySelector('.battle-question-wrap');
      const closeBtn = scene.querySelector('.xx-modal-close');

      function log(msg) { logEl.textContent = msg; }
      function updHero() {
        heroHpFill.style.width = (c.hp/c.maxHp*100)+'%';
        heroMpFill.style.width = (c.mp/c.maxMp*100)+'%';
        heroHpTxt.textContent = `${c.hp}/${c.maxHp}`;
        heroMpTxt.textContent = `MP ${c.mp}/${c.maxMp}`;
      }
      function updEnemy() {
        enemyHpFill.style.width = (enemy.hp/enemy.maxHp*100)+'%';
        enemyHpTxt.textContent = `${enemy.hp}/${enemy.maxHp}`;
      }
      function floatText(target, text, cls) {
        const t = document.createElement('div');
        t.className = 'dmg-float ' + (cls||'dmg');
        t.textContent = text;
        const rect = target.getBoundingClientRect();
        const parent = scene.querySelector('.battle-scene');
        const parentRect = parent.getBoundingClientRect();
        t.style.left = (rect.left - parentRect.left + rect.width/2) + 'px';
        t.style.top  = (rect.top  - parentRect.top - 10) + 'px';
        parent.appendChild(t);
        setTimeout(()=>t.remove(), 1200);
      }
      function spellFx(kind) {
        const el = document.createElement('div');
        el.className = 'spell-fx ' + kind;
        // 简化：直接用 emoji 作为特效
        el.style.fontSize = '52px';
        el.style.color = kind==='fireball'?'#f39c56':kind==='lightning'?'#f5c97a':kind==='ice'?'#6ed5e0':'#fff';
        el.style.textShadow = '0 0 16px currentColor';
        el.textContent = kind==='fireball'?'🔥':kind==='lightning'?'⚡':kind==='ice'?'❄️':'✨';
        scene.querySelector('.battle-scene').appendChild(el);
        setTimeout(()=>el.remove(), 800);
      }

      // 绑定技能栏
      scene.querySelectorAll('[data-skill]').forEach(b => {
        if (b.dataset.skill === 'basic') b.classList.add('active');
        b.onclick = () => {
          scene.querySelectorAll('[data-skill]').forEach(x=>x.classList.remove('active'));
          b.classList.add('active');
          selectedSkill = b.dataset.skill;
          if (selectedSkill === 'heal') {
            if (c.mp < 10) { UI.toast('灵力不足', 'error'); return; }
            c.mp -= 10; c.hp = Math.min(c.maxHp, c.hp + 30); Game.save();
            updHero();
            floatText(heroEl, '+30', 'heal');
            log('施展小循环，HP 回复中…');
            selectedSkill = 'basic';
            scene.querySelectorAll('[data-skill]').forEach(x=>x.classList.remove('active'));
            scene.querySelector('[data-skill=basic]').classList.add('active');
          }
        };
      });

      // 呼出题目
      function loadQuestion() {
        const q = opts.getQuestion ? opts.getQuestion() : opts.question;
        if (!q) { finishBattle(true); return; }
        renderQuestion(q);
      }
      function renderQuestion(q) {
        const opts2 = q.options || [];
        qWrap.innerHTML = `
          <div class="battle-question">${q.q}</div>
          <div class="battle-options">
            ${opts2.map((o,i)=>`<div class="battle-option" data-opt="${o.charAt(0)}">${o}</div>`).join('')}
          </div>`;
        qWrap.querySelectorAll('.battle-option').forEach(op => {
          op.onclick = () => onAnswer(q, op.dataset.opt, op);
        });
      }
      function onAnswer(q, pick, el) {
        const ansRaw = q.answer;
        const correct = Array.isArray(ansRaw)
          ? ansRaw.includes(pick)
          : (typeof ansRaw === 'string' && ansRaw.indexOf(pick) >= 0);
        // 途径：让 Game 报告答题结果（派发 answer 事件）
        if (Game.answerReport) Game.answerReport(q, correct);
        if (correct) {
          el.classList.add('correct');
          // 技能伤害
          let mul = 1, mpCost = 0, spell = null;
          if (selectedSkill === 'lightning') { mul = 2; mpCost = 20; spell = 'lightning'; }
          else if (selectedSkill === 'fireball') { mul = 1.5; mpCost = 15; spell = 'fireball'; }
          if (c.mp < mpCost) { mul = 1; mpCost = 0; spell = null; UI.toast('灵力不够，自动降为平取', 'info'); }
          const r = Game.battleCast({ skillMul: mul, mpCost });
          heroEl.classList.add('attack');
          setTimeout(()=>heroEl.classList.remove('attack'), 500);
          if (spell) spellFx(spell);
          enemy.hp = Math.max(0, enemy.hp - r.dmg);
          setTimeout(()=>{
            enemyEl.classList.add('hurt');
            setTimeout(()=>enemyEl.classList.remove('hurt'), 350);
            floatText(enemyEl, (r.crit?'暴击! ':'') + '-' + r.dmg, r.crit?'crit':'dmg');
            updEnemy(); updHero();
            if (enemy.hp <= 0) { enemyEl.classList.add('defeat'); log('妖兽已斩！'); setTimeout(()=>finishBattle(true), 900); }
            else { setTimeout(loadQuestion, 700); }
          }, 300);
        } else {
          el.classList.add('wrong');
          // 标正确项
          qWrap.querySelectorAll('.battle-option').forEach(op => {
            const key = op.dataset.opt;
            const ans = Array.isArray(ansRaw)?ansRaw:String(ansRaw);
            if ((Array.isArray(ans) ? ans.includes(key) : ans.indexOf(key) >= 0)) op.classList.add('correct');
          });
          const dmg = Game.battleTakeHit(enemy.atk);
          heroEl.classList.add('hurt');
          setTimeout(()=>heroEl.classList.remove('hurt'), 350);
          floatText(heroEl, '-' + dmg.dmg, 'dmg');
          updHero();
          log('答错 — 妖兽反噬 ' + dmg.dmg + '。');
          if (dmg.dead) { setTimeout(()=>finishBattle(false), 900); }
          else { setTimeout(loadQuestion, 1400); }
        }
      }
      function finishBattle(win) {
        if (win && opts.onWin) opts.onWin();
        if (!win && opts.onLose) opts.onLose();
        setTimeout(()=>{
          const winMsg = win
            ? `<div style="text-align:center;font-family:var(--xx-font-art);color:var(--xx-gold);font-size:22px;letter-spacing:4px;">⚔ 斩妖胜利</div>`
            : `<div style="text-align:center;font-family:var(--xx-font-art);color:var(--xx-red);font-size:22px;letter-spacing:4px;">💀 道心崩碎</div>`;
          qWrap.innerHTML = winMsg + `<div style="text-align:center;margin-top:12px;"><button class="xx-btn xx-btn-primary" id="battleEnd">退出战斗</button></div>`;
          scene.querySelector('#battleEnd').onclick = () => { mask.remove(); if (opts.onClose) opts.onClose(win); };
        }, 400);
      }

      closeBtn.onclick = () => { mask.remove(); if (opts.onClose) opts.onClose(false); };
      // 首题
      loadQuestion();

      return { close: () => mask.remove() };
    },

  };

  // 全局：突破特效自动监听
  if (typeof window !== 'undefined' && global.Game) {
    global.Game.on('breakthrough', realm => UI.breakthrough(realm));
  }
  // 文档加载完再绑定（如果脚本顺序保证 Game 先初始化）
  document.addEventListener('DOMContentLoaded', () => {
    if (global.Game && !global.Game._uiBound) {
      global.Game.on('breakthrough', realm => UI.breakthrough(realm));
      global.Game._uiBound = true;
    }
  });

  global.UI = UI;

})(typeof window !== 'undefined' ? window : this);
