# 《问道修仙学院》v5 · 迷你小游戏设计文档

> 版本：v5.0-minigames-01 ｜ 日期：2026-08-19 ｜ 基线 main：`4e86b2d57cb1356e706b8ce20dc9899505314122`
> 关联蓝图：`docs/v5-design/`（模块化重构蓝图，见 `wendao-architecture-survey-v450.md`）

---

## 1. 总览

v5 阶段新增两个可独立运行、零外部依赖的迷你小游戏，作为主游戏 `src/v5/minigame/` 的模块化试点：

| 小游戏 | 目录 | 玩法类型 | 核心循环 |
|---|---|---|---|
| 炼丹合炉 | `src/v5/minigame/alchemy/` | 3×3 拼图 + 丹方匹配 | 拖拽元素 → 匹配丹方 → 炼丹 → 精通成长 |
| 妖塔守御 | `src/v5/minigame/tower-defense/` | 塔防 | 布塔 → 守波 → 灵石经济 → 解锁新塔 |

两者均遵循 v5 模块规范：
- 纯 ES5，`(function(global){...})(window)` IIFE 包裹，暴露 `AlchemyGame` / `DefenseGame`
- 无框架、无音频、无外部字体、无网络请求
- 存档写入各自 localStorage key，并在 `Game.state` 可达时并入 `Game.state.v5.minigame.*`
- 读取 `REALM_TIERS` / `state.realm.economy` 时全部 `try/catch` + 回退默认值

---

## 2. 炼丹合炉（Alchemy Puzzle）

### 2.1 界面结构
- 左栏：丹方书（36 个丹方，锁定/已炼状态）
- 中栏：丹炉 3×3 网格 + 元素栏（9 元素）+ 连击/精通/已炼统计 + 精通进度条
- 右栏：玩法说明 + 存档说明

### 2.2 九元素
火🔥 / 水💧 / 木🌿 / 金⚜️ / 土⛰️ / 雷⚡ / 风🌪️ / 冰❄️ / 暗🌑
（元素图标为内联 CSS 色块 + emoji，无外部资源）

### 2.3 丹方系统
- 每个丹方 = 3 枚元素在 3×3 网格上的一个形状（cells: `[x,y,elKey]`）
- 匹配判定：当前炉中 3 枚元素与丹方形状一致，**允许 4 种旋转 + 镜像（D4 群，共 8 种变换）**
- 数量：**12 入门 + 24 进阶 = 36 个**
- 解锁门槛：`realmId ≥ recipe.realmGate`（1=筑基 … 24=飞升压轴）

### 2.4 品质公式
```
quality = baseQuality × (1 + 0.1 × combo) × (1 − 0.05 × timeElapsed) × realmMultiplier
realmMultiplier = 1 + (realmId / (realms.length − 1)) × 0.5    （REALM_TIERS 可达时）
                = 1.0                                          （回退）
```
品质档位：凡品 <20 / 良品 ≥20 / 上品 ≥30 / 极品 ≥40 / 仙品 ≥50

### 2.5 存档
`wendao_v5_alchemy_v1`：
```json
{ "currentGrid": [], "completedRecipes": [{id,ts,quality}], "qualityScore": 0, "combos": 0, "bestCombo": 0 }
```

---

## 3. 妖塔守御（Tower Defense）

### 3.1 界面结构
- 主区：Canvas 2D 战场（760×420）+ 控制条（开始/暂停/重开/返回）+ 战报日志
- 右栏：塔卡（5 种）+ 玩法说明
- HUD：境界 / 灵石 / 波次 / 最高波

### 3.2 五塔

| 塔 | 造价 | 攻击 | 攻速 | 射程 | 特效 |
|---|---|---|---|---|---|
| 剑气塔 🗡️ | 100 | 18 | 1.6 | 110 | 单体追加 15% 破甲 |
| 雷符塔 ⚡ | 140 | 30 | 1.0 | 120 | 20% 麻痹 1.2s |
| 寒冰塔 ❄️ | 160 | 12 | 1.2 | 130 | 命中减速 35% |
| 业火塔 🔥 | 200 | 42 | 0.8 | 100 | 对妖将/大妖 ×1.5 |
| 诛邪塔 🌟 | 260 | 26 | 1.4 | 150 | 优先大妖，暴击 +25% |

### 3.3 敌人四阶
妖兵（60 HP）/ 妖兽（130）/ 妖将（300）/ 大妖（700），对应难度档位递增。

### 3.4 波次与境界缩放
- 基础 10 波，每波敌数/构成见 `buildWaves`
- **境界每 +1：每波 +1 敌、敌 HP ×1.10**（`hpMul = 1.10^(realmId−1)`）

### 3.5 经济与奖励
- 开局灵石：`state.realm.economy.lingshi` 可达则取（下限 200），否则默认 500
- 每波奖励：`reward = base × (1 + 0.2 × streak)`，`base = 20 + wave × 10`
- 灵石用于布塔与自动解锁新塔（`unlockedTowers`）

### 3.6 存档
`wendao_v5_defense_v1`：
```json
{ "unlockedTowers": ["jianqi"], "bestWave": 0, "petBonus": {atk,def,hp}, "totalReward": 0 }
```
灵宠加成（`Game.getPetBonus()` 可达时）自动并入塔攻。

### 3.7 状态机
- 未开始 → 开始守御 → 战斗中（可暂停/继续）→ 每波结算 → 失败/十波全守 → 重开
- 覆盖层：失败 / 胜利两种结算弹窗

---

## 4. 与 v5 蓝图交叉引用

- 模块目录：`src/v5/miniggame/{alchemy,tower-defense}/` 对应蓝图 `content/<subject>` 与 `ui/<panel>` 拆分原则
- 全局暴露面收敛：仅 `AlchemyGame` / `DefenseGame` 两个全局符号
- 存档并入 `Game.state.v5.minigame.*`，为 v5 统一存档 schema 预留字段
- 经济读取走 `state.realm.economy`，与主游戏灵石体系打通

---

## 5. 后续待办
- [ ] 接入主游戏 portal（`src/_portal/index.html` 增加两个入口）
- [ ] 与主存档 `wendao_save_v2` 的 v5 段合并迁移
- [ ] 音效（可选，需 v5 音频模块）
- [ ] 更多丹方 / 更多波次与 Boss 波
