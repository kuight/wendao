/* ============================================================
 * 《问道修仙学院》v5 · 妖塔守御 (Tower Defense) — core module
 * 文件：src/v5/minigame/tower-defense/defense-core.js
 * 说明：独立 ES5 模块，Canvas 2D 渲染，无框架、无音频依赖。
 *       经济/境界数据优先读 Game.state，不可达时回退默认值。
 * ============================================================ */
(function (global) {
  'use strict';

  var STORAGE_KEY = 'wendao_v5_defense_v1';

  /* ---------- 五塔 ---------- */
  var TOWERS = [
    { id: 'jianqi',  name: '剑气塔', glyph: '🗡️', cost: 100, atk: 18, atkSpeed: 1.6, range: 110, special: '对单体追加 15% 破甲' },
    { id: 'leifu',   name: '雷符塔', glyph: '⚡', cost: 140, atk: 30, atkSpeed: 1.0, range: 120, special: '20% 概率麻痹 1.2s' },
    { id: 'hanbing', name: '寒冰塔', glyph: '❄️', cost: 160, atk: 12, atkSpeed: 1.2, range: 130, special: '命中减速 35%' },
    { id: 'yehuo',   name: '业火塔', glyph: '🔥', cost: 200, atk: 42, atkSpeed: 0.8, range: 100, special: '对妖将/大妖伤害 ×1.5' },
    { id: 'zhuxie',  name: '诛邪塔', glyph: '🌟', cost: 260, atk: 26, atkSpeed: 1.4, range: 150, special: '优先锁定大妖，暴击 +25%' }
  ];

  /* ---------- 敌人 ---------- */
  var ENEMY_TYPES = [
    { key: 'yaobing', name: '妖兵', color: '#8a7f5a', hp: 60,  speed: 1.0, reward: 8 },
    { key: 'yaoshou', name: '妖兽', color: '#b06bff', hp: 130, speed: 0.85, reward: 14 },
    { key: 'yaojiang',name: '妖将', color: '#ff5a3c', hp: 300, speed: 0.7, reward: 26 },
    { key: 'dayao',   name: '大妖', color: '#ffd700', hp: 700, speed: 0.55, reward: 50 }
  ];

  /* ---------- 波次配置（10 波基础，随境界缩放） ---------- */
  function buildWaves(realmId) {
    var rid = realmId || 0;
    var extra = Math.max(0, rid - 1);
    var hpMul = Math.pow(1.10, extra);
    var waves = [];
    var i, j, list;
    var base = [
      { type: 0, count: 4 }, { type: 0, count: 6 }, { type: 0, count: 8, mix: 1 },
      { type: 1, count: 5 }, { type: 1, count: 7, mix: 0 }, { type: 1, count: 9, mix: 2 },
      { type: 2, count: 5 }, { type: 2, count: 7, mix: 1 }, { type: 2, count: 9, mix: 3 },
      { type: 3, count: 6 }
    ];
    for (i = 0; i < base.length; i++) {
      list = [];
      var cfg = base[i];
      for (j = 0; j < cfg.count + extra; j++) {
        var t = cfg.type;
        if (cfg.mix && j % 3 === 0) t = cfg.mix;
        list.push(makeEnemy(t, hpMul));
      }
      waves.push({ wave: i + 1, enemies: list });
    }
    return waves;
  }
  function makeEnemy(typeIdx, hpMul) {
    var t = ENEMY_TYPES[typeIdx] || ENEMY_TYPES[0];
    return {
      type: t.key, name: t.name, color: t.color,
      hp: Math.round(t.hp * hpMul), maxHp: Math.round(t.hp * hpMul),
      speed: t.speed, reward: t.reward, x: -30, y: 0, alive: true, slow: 0
    };
  }

  /* ---------- 经济（state.realm.economy 可达则用，否则默认 500 开局） ---------- */
  function startingLingshi() {
    try {
      var g = global.Game;
      if (g && g.state && g.state.realm && g.state.realm.economy && typeof g.state.realm.economy.lingshi === 'number') {
        return Math.max(200, g.state.realm.economy.lingshi);
      }
    } catch (e) {}
    return 500;
  }
  function realmIdOf() {
    try { var g = global.Game; if (g && g.state && g.state.char) return g.state.char.realmId || 0; } catch (e) {}
    return 0;
  }

  /* ---------- 存档 ---------- */
  function defaultState() {
    return { unlockedTowers: ['jianqi'], bestWave: 0, petBonus: { atk: 0, def: 0, hp: 0 }, totalReward: 0 };
  }
  function loadSave() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return defaultState();
      var s = JSON.parse(raw);
      if (!s || typeof s !== 'object') return defaultState();
      s.unlockedTowers = s.unlockedTowers && s.unlockedTowers.length ? s.unlockedTowers : ['jianqi'];
      s.bestWave = s.bestWave || 0;
      s.petBonus = s.petBonus || { atk: 0, def: 0, hp: 0 };
      s.totalReward = s.totalReward || 0;
      return s;
    } catch (e) { return defaultState(); }
  }
  function persist(state) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (e) {}
    try {
      if (global.Game && global.Game.state) {
        global.Game.state.v5 = global.Game.state.v5 || {};
        global.Game.state.v5.minigame = global.Game.state.v5.minigame || {};
        global.Game.state.v5.minigame['tower-defense'] = state;
      }
    } catch (e) {}
  }
  function unlockTower(state, id) {
    if (state.unlockedTowers.indexOf(id) >= 0) return false;
    state.unlockedTowers.push(id);
    persist(state);
    return true;
  }

  /* ---------- 波次奖励：base×(1+0.2×streak) ---------- */
  function waveReward(wave, streak) {
    var base = 20 + wave * 10;
    return Math.round(base * (1 + 0.2 * (streak || 0)));
  }

  var DefenseGame = {
    TOWERS: TOWERS,
    ENEMY_TYPES: ENEMY_TYPES,
    STORAGE_KEY: STORAGE_KEY,
    buildWaves: buildWaves,
    startingLingshi: startingLingshi,
    realmIdOf: realmIdOf,
    loadSave: loadSave,
    persist: persist,
    unlockTower: unlockTower,
    waveReward: waveReward,
    getTower: function (id) {
      for (var i = 0; i < TOWERS.length; i++) if (TOWERS[i].id === id) return TOWERS[i];
      return null;
    }
  };

  global.DefenseGame = DefenseGame;
  if (typeof module !== 'undefined' && module.exports) module.exports = DefenseGame;
})(typeof window !== 'undefined' ? window : this);
