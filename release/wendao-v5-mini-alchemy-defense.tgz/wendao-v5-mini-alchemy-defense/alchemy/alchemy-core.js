/* ============================================================
 * 《问道修仙学院》v5 · 炼丹合炉 (Alchemy Puzzle) — core module
 * 文件：src/v5/minigame/alchemy/alchemy-core.js
 * 说明：独立 ES5 模块。可读取 game-core.js 的 REALM_TIERS / Game.state，
 *       不可达时自动回退默认值。无外部资源依赖。
 * ============================================================ */
(function (global) {
  'use strict';

  var STORAGE_KEY = 'wendao_v5_alchemy_v1';

  /* ---------- 九元素 ---------- */
  var ELEMENTS = [
    { key: 'huo',  name: '火', glyph: '🔥', color: '#ff5a3c' },
    { key: 'shui', name: '水', glyph: '💧', color: '#4aa8ff' },
    { key: 'mu',   name: '木', glyph: '🌿', color: '#3fbf6f' },
    { key: 'jin',  name: '金', glyph: '⚜️', color: '#e8c34a' },
    { key: 'tu',   name: '土', glyph: '⛰️', color: '#c98a4b' },
    { key: 'lei',  name: '雷', glyph: '⚡', color: '#b06bff' },
    { key: 'feng', name: '风', glyph: '🌪️', color: '#7fd4d4' },
    { key: 'bing', name: '冰', glyph: '❄️', color: '#9fd8ff' },
    { key: 'an',   name: '暗', glyph: '🌑', color: '#6a6a8a' }
  ];
  var EL_BY_KEY = {};
  ELEMENTS.forEach(function (e) { EL_BY_KEY[e.key] = e; });

  /* ---------- 丹方（3 格形状，可旋转/镜像） ---------- */
  // cells: [x, y, elKey]，x/y ∈ 0..2
  function R(id, name, gate, quality, cells, desc) {
    return { id: id, name: name, realmGate: gate, baseQuality: quality, cells: cells, desc: desc || '' };
  }

  var RECIPES = [
    // —— 12 个入门丹方（境界 1–3）——
    R('r01', '回气散', 1, 10, [[0,0,'mu'],[1,0,'shui'],[2,0,'huo']], '木水相济，火行引气'),
    R('r02', '聚灵丹', 1, 12, [[0,0,'lei'],[1,1,'lei'],[2,2,'lei']], '雷引灵机，一线贯之'),
    R('r03', '辟谷丸', 1, 10, [[0,0,'jin'],[0,1,'jin'],[0,2,'jin']], '金石为引，百日不饥'),
    R('r04', '凝气丹', 2, 14, [[0,0,'shui'],[1,1,'shui'],[2,2,'shui']], '水聚成渊，凝气归元'),
    R('r05', '淬体膏', 2, 13, [[0,0,'tu'],[1,0,'tu'],[2,0,'tu']], '厚土淬体，皮如坚岩'),
    R('r06', '明心散', 2, 15, [[0,0,'feng'],[1,1,'feng'],[2,2,'feng']], '风过无痕，明心见性'),
    R('r07', '引雷符', 2, 16, [[0,0,'lei'],[1,0,'lei'],[2,0,'lei']], '雷符横列，引动天威'),
    R('r08', '筑基丹', 3, 20, [[0,0,'mu'],[0,1,'mu'],[0,2,'mu']], '木柱擎天，道基始成'),
    R('r09', '养神丸', 3, 18, [[0,0,'bing'],[1,1,'bing'],[2,2,'bing']], '冰心养神，杂念尽消'),
    R('r10', '金创药', 3, 17, [[0,0,'huo'],[1,1,'huo'],[2,2,'huo']], '烈火煅药，止血生肌'),
    R('r11', '驱邪香', 3, 19, [[0,0,'an'],[1,1,'an'],[2,2,'an']], '暗香驱邪，百秽不侵'),
    R('r12', '通脉散', 3, 18, [[0,0,'tu'],[1,1,'tu'],[2,2,'tu']], '土行通脉，气血如流'),
    // —— 24 个进阶丹方（境界 4–24，随境界解锁）——
    R('r13', '聚元丹', 4, 22, [[0,0,'lei'],[1,0,'lei'],[0,1,'lei']], '雷元勾连，三才聚顶'),
    R('r14', '洗髓丹', 5, 22, [[0,0,'shui'],[1,0,'shui'],[0,1,'shui']], '水洗灵髓，脱胎换骨'),
    R('r15', '九转还魂丹', 6, 24, [[0,0,'mu'],[1,0,'mu'],[0,1,'mu']], '木气回春，九转还魂'),
    R('r16', '天元丹', 7, 25, [[0,0,'huo'],[1,0,'huo'],[0,1,'huo']], '火炼天元，精气神足'),
    R('r17', '太清丹', 8, 26, [[0,0,'jin'],[1,0,'jin'],[0,1,'jin']], '金性至坚，太清一气'),
    R('r18', '玉露丸', 9, 24, [[0,0,'bing'],[1,0,'bing'],[0,1,'bing']], '冰露凝霜，玉润珠圆'),
    R('r19', '玄阴丹', 10, 28, [[0,0,'an'],[1,0,'an'],[0,1,'an']], '玄阴内敛，寒魄自生'),
    R('r20', '巽风丹', 11, 26, [[0,0,'feng'],[1,0,'feng'],[0,1,'feng']], '巽风入体，身轻如燕'),
    R('r21', '厚土丹', 12, 27, [[0,0,'tu'],[1,0,'tu'],[0,1,'tu']], '厚土载物，稳若山岳'),
    R('r22', '三才丹', 13, 30, [[0,0,'lei'],[1,1,'lei'],[2,0,'lei']], '雷震三才，天地人合'),
    R('r23', '五行丹', 14, 32, [[0,0,'huo'],[1,1,'huo'],[2,0,'huo']], '火行五方，生生不息'),
    R('r24', '六合丹', 15, 30, [[0,0,'shui'],[1,1,'shui'],[2,0,'shui']], '水润六合，泽被苍生'),
    R('r25', '七星丹', 16, 33, [[0,0,'mu'],[1,1,'mu'],[2,0,'mu']], '木曜七星，周天流转'),
    R('r26', '八卦丹', 17, 34, [[0,0,'jin'],[1,1,'jin'],[2,0,'jin']], '金演八卦，万象归一'),
    R('r27', '九宫丹', 18, 35, [[0,0,'tu'],[1,1,'tu'],[2,0,'tu']], '土镇九宫，乾坤定鼎'),
    R('r28', '化神丹', 19, 40, [[0,0,'an'],[1,1,'an'],[2,0,'an']], '暗合神机，一念化神'),
    R('r29', '渡劫丹', 20, 42, [[0,0,'bing'],[1,1,'bing'],[2,0,'bing']], '冰封雷劫，安然渡之'),
    R('r30', '炼虚丹', 21, 44, [[0,0,'feng'],[1,1,'feng'],[2,0,'feng']], '风炼虚空，与道同行'),
    R('r31', '大乘丹', 22, 48, [[0,0,'lei'],[1,0,'lei'],[2,1,'lei']], '雷阶三叠，大乘可期'),
    R('r32', '登仙丹', 23, 50, [[0,0,'huo'],[1,0,'huo'],[2,1,'huo']], '火梯登仙，羽化飞升'),
    R('r33', '飞升丹', 24, 60, [[0,0,'jin'],[1,1,'jin'],[2,2,'jin']], '金线通天，飞升压轴'),
    R('r34', '天劫丹', 20, 45, [[0,0,'an'],[1,0,'an'],[2,1,'an']], '暗渡天劫，逆天改命'),
    R('r35', '混沌丹', 23, 52, [[0,0,'bing'],[1,0,'bing'],[2,1,'bing']], '冰封混沌，重开一界'),
    R('r36', '无极丹', 24, 66, [[0,0,'an'],[1,0,'an'],[2,0,'an']], '暗行无极，一线通天')
  ];

  /* ---------- 旋转 / 镜像（D4 群，共 8 种变换） ---------- */
  function rot90(p) { return { x: p.y, y: 2 - p.x }; }
  function mirror(p) { return { x: 2 - p.x, y: p.y }; }
  function applyT(p, t) {
    var q = { x: p.x, y: p.y };
    var r = t % 4, m = t >= 4, i;
    for (i = 0; i < r; i++) q = rot90(q);
    if (m) q = mirror(q);
    return q;
  }
  function transformCells(cells, t) {
    return cells.map(function (p) {
      var q = applyT({ x: p[0], y: p[1] }, t);
      return { x: q.x, y: q.y, el: p[2] };
    });
  }
  function cellsKey(cells) {
    var arr = cells.slice().sort(function (a, b) { return (a.x - b.x) || (a.y - b.y); });
    return arr.map(function (p) { return p.x + ',' + p.y + ':' + p.el; }).join('|');
  }
  function findMatch(grid) {
    var gk = cellsKey(grid);
    for (var i = 0; i < RECIPES.length; i++) {
      var r = RECIPES[i];
      for (var t = 0; t < 8; t++) {
        if (cellsKey(transformCells(r.cells, t)) === gk) return { recipe: r, transform: t };
      }
    }
    return null;
  }

  /* ---------- 境界倍率（REALM_TIERS 可达则用，否则回退 1.0） ---------- */
  function realmMultiplier(realmId) {
    var rid = realmId || 0;
    var realms = null;
    try {
      if (global.Game && typeof global.Game.getAllRealms === 'function') realms = global.Game.getAllRealms();
      else if (global.REALMS && global.REALMS.length) realms = global.REALMS;
    } catch (e) { realms = null; }
    if (Array.isArray(realms) && realms.length > 1) return 1 + (rid / (realms.length - 1)) * 0.5;
    return 1.0;
  }

  /* ---------- 品质公式 ---------- */
  function computeQuality(recipe, combo, elapsedSec, realmId) {
    var tFactor = Math.max(0.2, 1 - 0.05 * (elapsedSec || 0));
    var q = recipe.baseQuality * (1 + 0.1 * (combo || 0)) * tFactor * realmMultiplier(realmId);
    return Math.max(1, Math.round(q));
  }
  function tierOf(q) {
    if (q >= 50) return { name: '仙品', cls: 't-immortal' };
    if (q >= 40) return { name: '极品', cls: 't-epic' };
    if (q >= 30) return { name: '上品', cls: 't-rare' };
    if (q >= 20) return { name: '良品', cls: 't-fine' };
    return { name: '凡品', cls: 't-common' };
  }

  /* ---------- 存档 ---------- */
  function defaultState() {
    return { currentGrid: [], completedRecipes: [], qualityScore: 0, combos: 0, bestCombo: 0 };
  }
  function loadSave() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return defaultState();
      var s = JSON.parse(raw);
      if (!s || typeof s !== 'object') return defaultState();
      s.currentGrid = s.currentGrid || [];
      s.completedRecipes = s.completedRecipes || [];
      s.qualityScore = s.qualityScore || 0;
      s.combos = s.combos || 0;
      s.bestCombo = s.bestCombo || 0;
      return s;
    } catch (e) { return defaultState(); }
  }
  function persist(state) {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); } catch (e) {}
    try {
      if (global.Game && global.Game.state) {
        global.Game.state.v5 = global.Game.state.v5 || {};
        global.Game.state.v5.minigame = global.Game.state.v5.minigame || {};
        global.Game.state.v5.minigame.alchemy = state;
      }
    } catch (e) {}
  }

  /* ---------- 公开 API ---------- */
  var AlchemyGame = {
    ELEMENTS: ELEMENTS,
    RECIPES: RECIPES,
    STORAGE_KEY: STORAGE_KEY,
    getElement: function (k) { return EL_BY_KEY[k] || null; },
    loadSave: loadSave,
    persist: persist,
    realmMultiplier: realmMultiplier,
    computeQuality: computeQuality,
    tierOf: tierOf,
    findMatch: findMatch,
    isUnlocked: function (recipe, realmId) { return (realmId || 0) >= recipe.realmGate; },
    unlockedCount: function (realmId) {
      var n = 0;
      RECIPES.forEach(function (r) { if ((realmId || 0) >= r.realmGate) n++; });
      return n;
    }
  };

  global.AlchemyGame = AlchemyGame;
  if (typeof module !== 'undefined' && module.exports) module.exports = AlchemyGame;
})(typeof window !== 'undefined' ? window : this);
