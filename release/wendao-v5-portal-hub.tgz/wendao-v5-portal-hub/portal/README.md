# v5 入口主页（Portal Hub）

本目录提供《问道修仙学院》v5.0 开放世界入口的单页 SPA 主站，定位为「二次元开放世界学习版」的门户页面。

## 文件清单

| 文件 | 字节量级 | 职责 |
|---|---|---|
| `index.html` | ~25 KB | 主页骨架 + 七科符箓 + 桃花仙 + 视差背景 |
| `portal.css` | ~12 KB | 设计令牌 / 七科配色 / 3D 倾斜 / 响应式 |
| `portal.js`  | ~10 KB | 境界进度 / 卡片跳转 / 粒子 / 启动开放世界 |
| `README.md`  | 本文件 | 路由蓝图与集成说明 |

## 路由约定

1. 七科符箓 → 默认跳转 `subjects/<key>/index.html`（chinese/math/english/physics/chemistry/geography）；
2. 综合修仙殿 → `subjects/hall/index.html`；
3. 「启动 开放世界」按钮 → 优先调用 `window.GameV5.worldBoot(state)`；若未挂载则回退到语文宗门并显示提示；
4. 支线玩法链接为相对路径 `../minigame/<kind>/index.html`。

## 集成步骤

```bash
# 1. 复制到现有仓库的 v5 目录
mkdir -p src/v5/portal
cp portal/index.html portal/portal.css portal/portal.js portal/README.md \
   src/v5/portal/

# 2. 让 src/index.html 在 v5 模式下重定向到此页（或直接替换）
#    示例：把 <body> 第一个 <script> 之前插入：
#    if (location.search.indexOf('v5') >= 0) location.replace('v5/portal/index.html');

# 3. 确保 src/v5/bootstrap/world-boot.js 暴露 GameV5.worldBoot()
#    若尚未实现：先让 v5/portal/portal.js 回退到语文宗门即可，不阻塞首屏。

# 4. 七科页目录若尚未存在，按需建立占位：
mkdir -p src/subjects/{chinese,math,english,physics,chemistry,geography,hall}
```

## 主题与色板

固定在 portal.css 的 7 个 CSS 变量中：

| 学科 | 变量 | 色值 |
|---|---|---|
| 语文 | `--c-chinese` | `#ff7eb6` |
| 数学 | `--c-math` | `#6ee7ff` |
| 英语 | `--c-english` | `#b08fff` |
| 物理 | `--c-physics` | `#b8ff7e` |
| 化学 | `--c-chem` | `#ffc66e` |
| 地理 | `--c-geo` | `#87e8ff` |
| 综合修仙殿 | `--c-hall` | `#ff5e7e` |

若需要切换主题色调，只改 `:root` 内变量即可，无须改 JS / HTML。

## 自定义建议

- **字体**：未来 CJK webfont 接入请在 `portal.css` 顶部用 `@font-face` 替换预留给 `var(--serif)` 的占位注释；
- **吉祥物插画**：当前是 SVG 占位，正式资产到位后请替换 `.v5-mascot svg` 内部节点；
- **境界映射**：`portal.js` 内置了 10 个境界的回退表（`REALMS_FALLBACK`），如 `window.Game.getRealm` 已挂载则优先用运行时真值。

## 蓝图引用

- `/mnt/aidrive/wendao-v5-blueprint.md` §3 模块拆分
- `/mnt/aidrive/wendao-architecture-survey-v450.md` 旧架构现状

## 注意事项

- 当前包为**纯前端本地预览**版本，未做 CDN / Tailwind 依赖；
- 所有图像与动画均通过 SVG + CSS keyframes 完成；
- 已在 Chrome / Safari / 移动 375 / 1366 视口适配；
- 仓库整合工作（G76 SP3 之后）由后续 PR 串行推进。