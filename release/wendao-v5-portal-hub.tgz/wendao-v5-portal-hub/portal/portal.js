/* portal.js · 开放世界门户交互
 * - 启动 v5 开放世界（GameV5.worldBoot）
 * - 7 科符箓卡片：3D 倾斜 + 点击跳转
 * - 境界进度弧 + 徽标
 * - 桃花仙粒子 / 樱花瓣生成
 * - 桃花仙闲置动画已在 CSS 内完成
 */
(function () {
  'use strict';

  var STATE_KEYS = ['wendao_save_v2','xxSideDockZoom'];
  var REALMS_FALLBACK = [
    { key:'lianqi',  name:'炼气' },
    { key:'lianti',  name:'炼体' },
    { key:'zhuji',   name:'筑基' },
    { key:'jindan',  name:'金丹' },
    { key:'yuanying',name:'元婴' },
    { key:'huashen', name:'化神' },
    { key:'dujie',   name:'渡劫' },
    { key:'lianxu',  name:'炼虚' },
    { key:'dacheng', name:'大乘' },
    { key:'dengxian',name:'登仙' }
  ];

  // ------- 工具 -------
  function $(sel, root) { return (root || document).querySelector(sel); }
  function on(el, ev, fn) { if (el) el.addEventListener(ev, fn); }

  function readState() {
    try {
      for (var i = 0; i < STATE_KEYS.length; i++) {
        var raw = localStorage.getItem(STATE_KEYS[i]);
        if (raw) {
          try { return JSON.parse(raw); } catch (_) { return {}; }
        }
      }
    } catch (_) { /* localStorage 不可用 */ }
    return {};
  }

  function realmOf(rid) {
    if (window.Game && typeof window.Game.getRealm === 'function') {
      try {
        var r = window.Game.getRealm(rid || 0);
        if (r && r.name) return r;
      } catch (_) { /* fallthrough */ }
    }
    var idx = Math.max(0, Math.min(rid | 0, REALMS_FALLBACK.length - 1));
    return REALMS_FALLBACK[idx];
  }

  // ------- 境界进度弧 -------
  function renderRealm() {
    var realm = $('#v5-realm');
    var arc   = $('#v5-arc');
    var name  = $('#v5-realm-name');
    var prog  = $('#v5-realm-progress');
    var next  = realm && realm.querySelector('.v5-realm__next');
    if (!realm || !arc || !name) return;

    var st = readState();
    var char = (st && st.char) || {};
    var rid = char.realmId | 0;
    var cur = realmOf(rid);
    var nxt = realmOf(rid + 1);
    var exp = Math.max(0, char.cultivation | 0);
    var need = Math.max(100, exp + 1);
    var pct = Math.min(100, Math.max(0, Math.round((exp / need) * 100)));

    realm.dataset.rid = String(rid);
    name.textContent = cur.name || ('境界 ' + rid);
    if (prog) prog.textContent = exp + ' / ' + need;
    if (next) next.textContent = '→ ' + nxt.name;
    arc.style.strokeDasharray = pct + ' 100';
  }

  // ------- 3D 倾斜 -------
  function attachTilt(card) {
    var wrap = card.querySelector('.v5-card__wrap');
    if (!wrap) return;
    var rafId = 0;
    function reset() {
      card.removeAttribute('data-tilting');
      wrap.style.transform = '';
    }
    function onMove(ev) {
      var r = card.getBoundingClientRect();
      var cx = r.left + r.width  / 2;
      var cy = r.top  + r.height / 2;
      var dx = (ev.clientX - cx) / (r.width  / 2);
      var dy = (ev.clientY - cy) / (r.height / 2);
      var rx = (+dy * 12).toFixed(2);
      var ry = (-dx * 12).toFixed(2);
      cancelAnimationFrame(rafId);
      rafId = requestAnimationFrame(function () {
        card.setAttribute('data-tilting', '1');
        wrap.style.transform = 'rotateX(' + rx + 'deg) rotateY(' + ry + 'deg)';
      });
    }
    on(card, 'mousemove', onMove);
    on(card, 'mouseleave', function () { cancelAnimationFrame(rafId); reset(); });
    on(card, 'blur', reset);
  }

  function attachCards() {
    var cards = document.querySelectorAll('.v5-card');
    for (var i = 0; i < cards.length; i++) attachTilt(cards[i]);
  }

  // ------- 跳转 -------
  function subjectEntry(subject) {
    if (window.GameV5 && typeof window.GameV5.subjectEntry === 'function') {
      try { window.GameV5.subjectEntry(subject); return true; } catch (_) {}
    }
    if (subject === 'hall') { location.href = 'subjects/hall/index.html'; return true; }
    location.href = 'subjects/' + subject + '/index.html';
    return true;
  }

  function attachNav() {
    var cards = document.querySelectorAll('.v5-card__enter');
    for (var i = 0; i < cards.length; i++) {
      (function (btn) {
        on(btn, 'click', function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          subjectEntry(btn.getAttribute('data-subject') || 'chinese');
        });
      })(cards[i]);
    }
    on($('.v5-card'), 'keydown', function (ev) {
      if (ev.key !== 'Enter' && ev.key !== ' ') return;
      var subj = ev.currentTarget.getAttribute('data-subject');
      if (subj) subjectEntry(subj);
    });
  }

  // ------- 开放世界 -------
  function bootWorld() {
    if (window.GameV5 && typeof window.GameV5.worldBoot === 'function') {
      try {
        window.GameV5.worldBoot(readState());
        return true;
      } catch (e) {
        console.warn('[v5-portal] GameV5.worldBoot 抛错:', e);
      }
    }
    var note = $('#v5-cta-note');
    if (note) note.textContent = 'GameV5.worldBoot 未挂载，已先打开语文宗门，待开放世界 bootstrap 补齐后再启用此处入口。';
    subjectEntry('chinese');
    return false;
  }
  function attachWorldBtn() {
    var btn = $('#v5-world-boot');
    if (!btn) return;
    on(btn, 'click', bootWorld);
  }

  // ------- 樱花瓣 -------
  function spawnPetals() {
    var host = $('#v5-petals');
    if (!host) return;
    var N = Math.min(28, Math.max(8, Math.floor(window.innerWidth / 90)));
    var frag = document.createDocumentFragment();
    for (var i = 0; i < N; i++) {
      var s = document.createElement('span');
      s.style.left = (Math.random() * 100) + 'vw';
      s.style.animationDelay = (Math.random() * 12) + 's';
      s.style.animationDuration = (10 + Math.random() * 6) + 's';
      s.style.opacity = (0.4 + Math.random() * 0.6).toFixed(2);
      frag.appendChild(s);
    }
    host.appendChild(frag);
  }

  // ------- 桃花仙粒子 -------
  function spawnSparkles() {
    var host = $('#v5-dust');
    if (!host) return;
    var N = Math.min(60, Math.max(20, Math.floor(window.innerWidth / 32)));
    var frag = document.createDocumentFragment();
    for (var i = 0; i < N; i++) {
      var d = document.createElement('span');
      var size = 2 + Math.random() * 3;
      d.style.position = 'absolute';
      d.style.width = size + 'px';
      d.style.height = size + 'px';
      d.style.borderRadius = '50%';
      d.style.background = (i % 3 === 0) ? '#ffc66e' : '#fff2cc';
      d.style.left = (Math.random() * 100) + 'vw';
      d.style.top  = (Math.random() * 100) + 'vh';
      d.style.opacity = (0.3 + Math.random() * 0.5).toFixed(2);
      d.style.boxShadow = '0 0 ' + (4 + Math.random() * 8) + 'px rgba(255,194,110,0.7)';
      d.style.transition = 'transform 6s linear, opacity 6s linear';
      frag.appendChild(d);
    }
    host.appendChild(frag);

    var bits = host.children;
    function recycle() {
      for (var j = 0; j < bits.length; j++) {
        var b = bits[j];
        b.style.transform = 'translate3d(0,' + (10 + Math.random() * 90) + 'vh,0)';
        b.style.opacity = '0';
      }
      setTimeout(function () {
        for (var k = 0; k < bits.length; k++) {
          var c = bits[k];
          c.style.transition = 'none';
          c.style.transform = 'translate3d(0,0,0)';
          c.style.top = (Math.random() * 100) + 'vh';
          c.style.opacity = (0.3 + Math.random() * 0.5).toFixed(2);
        }
        requestAnimationFrame(function () {
          for (var m = 0; m < bits.length; m++) {
            bits[m].style.transition = 'transform 6s linear, opacity 6s linear';
          }
        });
      }, 40);
    }
    setInterval(recycle, 6200);
  }

  // ------- init -------
  function init() {
    spawnPetals();
    spawnSparkles();
    renderRealm();
    attachCards();
    attachNav();
    attachWorldBtn();
    // 监听 storage 变化（其它标签升级境界时同步）
    on(window, 'storage', function (e) {
      if (e && e.key && e.key.indexOf('wendao_save') === 0) renderRealm();
    });
  }
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();