/*!
 * wendao-v5/preview-core.js
 * 本地兜底 3D 渲染: Canvas2D 主舞台 + CSS3D-transform 浮层粒子
 * 真实 three.js 接入时, 由 three-loader-stub.js 触发 Wendao3DRegisterRealThree,
 * 然后上层 viewer.html / V5ModelPreview 切到真 THREE.Scene 管线即可。
 *
 * 设计: 本文件不需要任何真实 three.js 就能渲染 demo;
 *       顶点/面 → 2D 投影 → 按相机绕 Y 轴旋转 30°/s → 上下浮动 4px。
 */
(function (root) {
  'use strict';

  function Projector(camDist) {
    this.camDist = camDist || 240;
    this.yaw = -0.4;     // 绕 Y 轴
    this.pitch = 0.25;   // 绕 X 轴
    this.zoom = 1.0;
    this.targetYaw = this.yaw;
    this.targetPitch = this.pitch;
    this.targetZoom = this.zoom;
    this.rotSpeed = Math.PI / 6; // 30°/s
    this.bobAmp = 4;
    this.bobT = 0;
  }
  Projector.prototype.update = function (dt) {
    // yaw 持续旋转
    this.yaw += this.rotSpeed * dt;
    // 平滑到 target
    this.pitch += (this.targetPitch - this.pitch) * Math.min(1, dt * 4);
    this.zoom  += (this.targetZoom  - this.zoom ) * Math.min(1, dt * 4);
    this.bobT += dt;
  };
  Projector.prototype.project = function (v) {
    var x = v.x, y = v.y, z = v.z;
    // 绕 Y 轴 (yaw)
    var cy = Math.cos(this.yaw), sy = Math.sin(this.yaw);
    var x1 = x * cy + z * sy;
    var z1 = -x * sy + z * cy;
    // 绕 X 轴 (pitch)
    var cp = Math.cos(this.pitch), sp = Math.sin(this.pitch);
    var y1 = y * cp - z1 * sp;
    var z2 = y * sp + z1 * cp;
    // 透视
    var f = this.camDist / (this.camDist + z2);
    return { x: x1 * f, y: y1 * f, depth: z2, factor: f };
  };

  function V5ModelPreview(canvas, opts) {
    if (!canvas) throw new Error('V5ModelPreview: canvas required');
    opts = opts || {};
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.dpr = Math.max(1, root.devicePixelRatio || 1);
    this.cam = new Projector();
    this.model = null;
    this.particles = [];
    this.showParticles = true;
    this._raf = 0;
    this._lastT = 0;
    this._onLoaded = opts.onModelLoaded || function(){};
    this._cache = {};
    this._setupInteraction();
    this._resize();
    var self = this;
    root.addEventListener('resize', function(){ self._resize(); });
  }
  V5ModelPreview.prototype._resize = function () {
    var rect = this.canvas.getBoundingClientRect();
    this.canvas.width = Math.max(1, Math.floor(rect.width * this.dpr));
    this.canvas.height = Math.max(1, Math.floor(rect.height * this.dpr));
  };
  V5ModelPreview.prototype._setupInteraction = function () {
    var self = this;
    var dragging = false, lastX = 0, lastY = 0;
    this.canvas.addEventListener('mousedown', function (e) {
      dragging = true; lastX = e.clientX; lastY = e.clientY;
    });
    root.addEventListener('mouseup', function () { dragging = false; });
    root.addEventListener('mousemove', function (e) {
      if (!dragging) return;
      self.cam.targetYaw   += (e.clientX - lastX) * 0.01;
      self.cam.targetPitch -= (e.clientY - lastY) * 0.01;
      lastX = e.clientX; lastY = e.clientY;
    });
    this.canvas.addEventListener('wheel', function (e) {
      e.preventDefault();
      self.cam.targetZoom *= (1 - e.deltaY * 0.001);
      self.cam.targetZoom = Math.min(3.0, Math.max(0.4, self.cam.targetZoom));
    }, { passive: false });
  };
  V5ModelPreview.prototype.cacheModel = function (url) {
    if (this._cache[url]) return this._cache[url];
    // 同步 fetch; viewer.html 由本地 file:// 加载, 此处使用 XHR 同步更稳
    var xhr = new (root.XMLHttpRequest || function(){})();
    if (xhr && typeof xhr.open === 'function') {
      xhr.open('GET', url, false);
      try { xhr.send(null); }
      catch (e) { /* 浏览器 file:// 同步 XHR 可能抛错; 仍返回兜底 */ }
      if (xhr && xhr.status === 200 && xhr.responseText) {
        try { this._cache[url] = JSON.parse(xhr.responseText); return this._cache[url]; } catch(_){}
      }
    }
    // 兜底: 用内置最小模型
    this._cache[url] = {
      id:'fallback', name:'兜底·立方体', realmGate:'凡人', polycount:8,
      vertices:[
        {x:-6,y:-6,z:0,c:'#7fa6c8'},{x:6,y:-6,z:0,c:'#a7c8e6'},
        {x:-6,y:6,z:0,c:'#cfeaff'},{x:6,y:6,z:0,c:'#e8c873'}
      ],
      faces:[{a:0,b:1,c:2},{a:1,b:3,c:2}], colors:['#7fa6c8','#e8c873']
    };
    return this._cache[url];
  };
  V5ModelPreview.prototype.loadModel = function (json) {
    this.model = json;
    this._spawnParticles(json);
    this._onLoaded(json);
    this._start();
  };
  V5ModelPreview.prototype._spawnParticles = function (json) {
    var n = 60;
    this.particles = [];
    for (var i = 0; i < n; i++) {
      var ang = (i / n) * Math.PI * 2;
      this.particles.push({
        ang: ang, speed: 0.4 + (i % 7) * 0.07, radius: 28 + (i % 5) * 4,
        yoff: ((i * 7) % 20) - 10, size: 1.5 + (i % 3) * 0.6
      });
    }
  };
  V5ModelPreview.prototype.toggleParticles = function () {
    this.showParticles = !this.showParticles;
    return this.showParticles;
  };
  V5ModelPreview.prototype.resetCamera = function () {
    this.cam.yaw = -0.4; this.cam.targetYaw = -0.4;
    this.cam.pitch = 0.25; this.cam.targetPitch = 0.25;
    this.cam.zoom = 1.0;  this.cam.targetZoom = 1.0;
  };
  V5ModelPreview.prototype._start = function () {
    if (this._raf) return;
    var self = this;
    var last = performance.now();
    function frame(now) {
      var dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      self._render(dt);
      self._raf = requestAnimationFrame(frame);
    }
    this._raf = requestAnimationFrame(frame);
  };
  V5ModelPreview.prototype._render = function (dt) {
    this.cam.update(dt);
    var ctx = this.ctx, w = this.canvas.width, h = this.canvas.height;
    ctx.clearRect(0, 0, w, h);

    // 背景渐变 + 雾感
    var g = ctx.createRadialGradient(w * 0.5, h * 0.5, 20, w * 0.5, h * 0.5, Math.max(w, h) * 0.6);
    g.addColorStop(0, '#1a2540');
    g.addColorStop(1, '#070b16');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);

    if (!this.model) return;
    var bob = Math.sin(this.cam.bobT * 2) * this.cam.bobAmp;
    var cx = w / 2, cy = h / 2 + bob;

    // 投影所有顶点
    var verts = this.model.vertices || [];
    var proj = new Array(verts.length);
    for (var i = 0; i < verts.length; i++) {
      proj[i] = this.cam.project(verts[i]);
    }

    // faces
    var faces = this.model.faces || [];
    // 按 depth 排序 (painter)
    var indexed = faces.map(function (f, k) { return { f: f, k: k }; });
    indexed.sort(function (a, b) {
      var da = (proj[a.f.a] && proj[a.f.a].depth || 0) + (proj[a.f.b] && proj[a.f.b].depth || 0) + (proj[a.f.c] && proj[a.f.c].depth || 0);
      var db = (proj[b.f.a] && proj[b.f.a].depth || 0) + (proj[b.f.b] && proj[b.f.b].depth || 0) + (proj[b.f.c] && proj[b.f.c].depth || 0);
      return db - da;
    });
    var colors = this.model.colors || ['#7fa6c8','#e8c873','#cfeaff','#9ad9cf'];
    var zoom = this.cam.zoom;
    indexed.forEach(function (entry, idx) {
      var f = entry.f;
      var pa = proj[f.a], pb = proj[f.b], pc = proj[f.c];
      if (!pa || !pb || !pc) return;
      ctx.beginPath();
      ctx.moveTo(cx + pa.x * zoom, cy - pa.y * zoom);
      ctx.lineTo(cx + pb.x * zoom, cy - pb.y * zoom);
      ctx.lineTo(cx + pc.x * zoom, cy - pc.y * zoom);
      ctx.closePath();
      ctx.fillStyle = colors[idx % colors.length];
      ctx.globalAlpha = (pa.factor + pb.factor + pc.factor) / 3 / 1.4 + 0.25;
      ctx.fill();
      ctx.globalAlpha = 1;
      ctx.strokeStyle = 'rgba(207,234,255,0.35)';
      ctx.lineWidth = 1 * this.dpr;
      ctx.stroke();
    }.bind(this));

    // 灵符粒子
    if (this.showParticles) {
      for (var j = 0; j < this.particles.length; j++) {
        var p = this.particles[j];
        var ang = p.ang + this.cam.bobT * p.speed;
        var px = cx + Math.cos(ang) * p.radius * zoom;
        var py = cy + Math.sin(ang) * p.radius * 0.4 * zoom + p.yoff;
        ctx.beginPath();
        ctx.arc(px, py, p.size * this.dpr, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(232,200,115,0.85)';
        ctx.fill();
      }
    }

    // 三方向光形成的 rim halo
    ctx.save();
    var rim = ctx.createRadialGradient(cx, cy, 30 * zoom, cx, cy, 180 * zoom);
    rim.addColorStop(0,   'rgba(207,234,255,0.00)');
    rim.addColorStop(0.5, 'rgba(207,234,255,0.10)');
    rim.addColorStop(1,   'rgba(207,234,255,0.00)');
    ctx.fillStyle = rim;
    ctx.fillRect(0, 0, w, h);
    ctx.restore();
  };

  root.WendaoModelPreview = V5ModelPreview;
  root.V5ModelPreview = V5ModelPreview;
  root.WendaoProjector = Projector;
})(typeof window !== 'undefined' ? window : this);