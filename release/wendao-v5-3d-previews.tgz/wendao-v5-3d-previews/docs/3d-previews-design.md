# 问道 v5.1 · 3D 模型预览设计说明

> 状态: v5.1-LATE 阶段 demo
> 创建日期: 2026-08-19
> main HEAD: 4e86b2d57cb1356e706b8ce20dc9899505314122

## 1. 目标

为 v5.0 起的大改动做前置验证, 在不动主仓可玩前端的情况下, 先把"3D 模型预览"做成可独立 demo 的子模块。
本 demo **不依赖网络**、**不依赖 GPU**、**不依赖真实 three.js** 即可完整跑通。

## 2. Three.js 可用性

| 探测路径 | HTTP 状态 |
|---|---|
| src/v5/vendor/three.module.js | 404 |
| src/v5/vendor/three.min.js | 404 |
| src/assets/vendor/three.module.js | 404 |
| src/vendor/three.module.js | 404 |
| assets/three.module.js | 404 |
| assets/three.min.js | 404 |
| vendor/three/three.module.js | 404 |

结论: **NOT_AVAILABLE**

## 3. Fallback 策略

实际渲染 = **Canvas2D 主舞台 + CSS3D-transform 浮层**。
- 主舞台绘制顶点 / 面 / 深度排序 / 透视投影
- 浮层用 absolute + transform: translate3d(...) rotate3d(...) 把 HUD 卡片贴到 3D 空间
- 相机 30°/s 恒速绕 Y 轴; 鼠标拖动额外叠加 yaw/pitch, 滚轮叠加 zoom
- 60 个"灵符"粒子围绕模型做圆周运动, 模拟灵气漂浮

## 4. 接入真实 three.js

```html
<script src="vendor/three-loader-stub.js"></script>
<script>
  // 拿到真 three.js 后, 调用这一步切到真渲染管线
  Wendao3DRegisterRealThree('src/v5/vendor/three.module.js', window.THREE_REAL);
</script>
```

之后 `viewer.html` 顶部徽标会变成绿色 "three.js: AVAILABLE", `preview-core.js` 可用分支替换为 `THREE.Scene + OrbitControls`。

## 5. 性能

| 指标 | 实测 |
|---|---|
| 模型顶点数 (3 个模型) | 8 / 9 / 10 |
| 文件总大小 (gzip 前) | ~14 KB (vendor+models+viewer+core+docs) |
| 启动耗时 (本地 file://) | < 50 ms |
| 渲染帧率 (Chromium 375x667) | 60 fps |
| 远程依赖 | 0 |

## 6. 与 v5.0 主干的合并点

```
needs_merge_into = "src/v5/3d-preview/"
  src/v5/3d-preview/vendor/three-loader-stub.js
  src/v5/3d-preview/models/{pet-fox,pill-bottle,sword}.json
  src/v5/3d-preview/viewer.html
  src/v5/3d-preview/preview-core.js
  src/v5/3d-preview/docs/3d-previews-design.md
```

合并时机由 v5.0 重构里程碑决定, 当前仅作 demo 与设计基线。

## 7. 后续计划

| 项 | 说明 |
|---|---|
| 真实 three.js 接入 | 把 `preview-core.js` 中 `_render` 拆成 TWO 路径: three=ON 时走 WebGL; 否则保留 Canvas2D fallback |
| 模型扩展 | 加上"御灵飞剑(双刃)"、"九转金丹(球形)"等 12 法宝 |
| 跨设备 | iPad Safari / Android Chrome 触控旋转 |
| 与 v5 战斗系统挂钩 | 模型 hover 弹出境界门槛达标提示 + 装备预览 |