'use strict';
// 校验脚本：课题步骤数 + 引擎走查
const path = require('path');
const { QUEST_REGISTRY } = require(path.join(__dirname, 'quest-engine', 'quest-registry.js'));
const { V5QuestEngine, computeReward, gradeStep } = require(path.join(__dirname, 'quest-engine', 'engine.js'));

// 1) 步骤数断言
let total = 0;
const perQuest = {};
for (const q of QUEST_REGISTRY) {
  perQuest[q.id] = q.steps.length;
  total += q.steps.length;
}
console.log('PER_QUEST_STEPS=' + JSON.stringify(perQuest));
console.log('TOTAL_STEPS=' + total);
console.log('TOTAL_STEPS_EXPECTED=60');
console.log('STEPS_OK=' + (total === 60 ? 'YES' : 'NO'));

// 2) 唯一性检查
const ids = QUEST_REGISTRY.map(q => q.id);
const stepIds = QUEST_REGISTRY.flatMap(q => q.steps.map(s => s.stepId));
console.log('QUEST_IDS_UNIQUE=' + (new Set(ids).size === ids.length ? 'YES' : 'NO'));
console.log('STEP_IDS_UNIQUE=' + (new Set(stepIds).size === stepIds.length ? 'YES' : 'NO'));

// 3) 引擎走查：Q1 完整通关（含一次错误 + 一次提示 + 一次部分得分）
const engine = new V5QuestEngine({ storageKey: 'v5_quest_proto_test' });
const q1 = engine.getQuest('Q1');
console.log('Q1_STEPS=' + q1.steps.length + ' SUBJECTS=' + q1.subjects.join(','));

// 模拟 localStorage（Node 环境）
const memStore = {};
global.localStorage = {
  getItem: k => (k in memStore ? memStore[k] : null),
  setItem: (k, v) => { memStore[k] = String(v); },
  removeItem: k => { delete memStore[k]; }
};

engine.start('Q1');
const results = [];
for (const step of q1.steps) {
  let answer;
  if (step.answerType === 'choice') answer = step.exactAnswer;
  else if (step.answerType === 'numeric') answer = step.exactAnswer;
  else answer = 'CO₂ 超标，需加强通风'; // validate 关键字命中
  const res = engine.submitStep(step.stepId, answer);
  results.push({ stepId: step.stepId, pass: res.pass, score: res.score, done: res.done });
}
console.log('Q1_WALKTHROUGH_ALL_PASS=' + (results.every(r => r.pass) ? 'YES' : 'NO'));
console.log('Q1_WALKTHROUGH_DONE=' + (results[results.length - 1].done ? 'YES' : 'NO'));
const prog = engine.getProgress('Q1');
console.log('Q1_FINAL_TOTAL_SCORE=' + prog.totalScore);
console.log('Q1_COMPLETED_STEPS=' + prog.completedSteps.length);

// 4) 提示扣分验证：Q2-S1 先用提示再答对
engine.start('Q2');
engine.useHint();
const s2 = engine.currentStep('Q2');
const r2 = engine.submitStep(s2.stepId, s2.exactAnswer);
console.log('Q2_HINT_PENALTY_SCORE=' + r2.score + ' (expect 100-15=85)');
console.log('Q2_HINT_PENALTY_OK=' + (r2.score === 85 ? 'YES' : 'NO'));

// 5) 部分得分验证：validate 返回数值 70
const fakeStep = { answerType: 'validate', validate: () => 70, difficulty: 3 };
const g = gradeStep(fakeStep, 'x');
console.log('PARTIAL_GRADE_PASS=' + g.pass + ' SCORE=' + g.score + ' (expect true/70)');

// 6) 奖励公式抽查
const rw = computeReward({ difficulty: 4 });
console.log('REWARD_DIFF4=' + JSON.stringify(rw));

// 7) 完整通关 JSON 样例（Q1）
const sample = {
  quest: { id: q1.id, title: q1.title, realmGate: q1.realmGate, subjects: q1.subjects, stepCount: q1.steps.length },
  progress: { questId: prog.questId, completedSteps: prog.completedSteps, totalScore: prog.totalScore, done: prog.done }
};
console.log('SAMPLE_QUEST_JSON=' + JSON.stringify(sample, null, 2));
