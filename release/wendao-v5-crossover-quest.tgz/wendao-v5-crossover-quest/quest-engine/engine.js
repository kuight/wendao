/**
 * 《问道修仙学院》v5.1 §5 跨学科课题系统 — 课题引擎
 * V5 QUEST ENGINE
 *
 * 职责：
 *  - 从 QUEST_REGISTRY 加载课题（load / start / resume）
 *  - 逐步骤校验答案（choice / numeric / validate 三种 answerType）
 *  - 支持部分得分（partial credit）与提示扣分（hintsUsed penalty）
 *  - 计算奖励（coins / exp / petBonus / realmProgress）
 *  - 持久化到 state.v5.quest[]（与主存档 wendao_save_v2 解耦，便于原型期独立验证）
 *  - 跨链接到 /v5/minigame/ai-tutor/ 的 showTutorHint()（仅占位，不实现 AI 接口）
 *
 * 双端加载：Node(require) 与浏览器(window.V5QuestEngine)。
 */
'use strict';

const { QUEST_REGISTRY } = (typeof require === 'function')
  ? require('./quest-registry.js')
  : { QUEST_REGISTRY: (typeof window !== 'undefined' ? window.QUEST_REGISTRY : []) };

// ---------------------------------------------------------------
// 奖励公式
//   base = 8 + difficulty * 6            (diff 1 → 14, diff 5 → 38)
//   coins = round(base * 1.2)
//   exp   = round(base * 1.0)
//   petBonus = diff >= 4 ? 0.5 + diff*0.1 : 0   (高阶课题给灵宠成长加成)
//   realmProgress = diff >= 3 ? 0.4 + diff*0.15 : 0.2
// ---------------------------------------------------------------
function computeReward(step) {
  const diff = Math.min(5, Math.max(1, step.difficulty || 1));
  const base = 8 + diff * 6;
  const coins = Math.round(base * 1.2);
  const exp = Math.round(base * 1.0);
  const petBonus = diff >= 4 ? +(0.5 + diff * 0.1).toFixed(2) : 0;
  const realmProgress = diff >= 3 ? +(0.4 + diff * 0.15).toFixed(2) : 0.2;
  return { coins, exp, petBonus, realmProgress };
}

// 答案规范化：numeric 类型去掉空格与千分位
function normalizeAnswer(answer) {
  if (answer === null || answer === undefined) return '';
  return String(answer).trim().replace(/[,\s]/g, '');
}

// 判定单步是否答对；返回 { pass, score }，score 支持部分得分
function gradeStep(step, answer) {
  if (!step) return { pass: false, score: 0 };
  const type = step.answerType || 'choice';
  let pass = false;
  let score = 0;

  if (type === 'choice') {
    pass = normalizeAnswer(answer).toUpperCase() === normalizeAnswer(step.exactAnswer).toUpperCase();
    score = pass ? 100 : 0;
  } else if (type === 'numeric') {
    const got = parseFloat(normalizeAnswer(answer));
    const want = parseFloat(step.exactAnswer);
    if (!isNaN(got) && !isNaN(want)) {
      pass = Math.abs(got - want) < 1e-6;
      score = pass ? 100 : 0;
    }
  } else if (type === 'validate') {
    if (typeof step.validate === 'function') {
      const res = step.validate(answer);
      // 允许 validate 返回布尔或 0-100 数值（部分得分）
      if (typeof res === 'number') {
        score = Math.max(0, Math.min(100, res));
        pass = score >= 60;
      } else {
        pass = !!res;
        score = pass ? 100 : 0;
      }
    } else {
      // 无 validate 函数时退化为关键字匹配
      const kw = Array.isArray(step.keywords) ? step.keywords : [];
      const s = String(answer || '');
      const hits = kw.filter((k) => s.includes(k)).length;
      score = kw.length ? Math.round((hits / kw.length) * 100) : 0;
      pass = score >= 60;
    }
  }
  return { pass, score };
}

// ---------------------------------------------------------------
// V5QuestEngine
// ---------------------------------------------------------------
class V5QuestEngine {
  /**
   * @param {Object} opts
   *   opts.storageKey  - 原型期独立存档键（默认 'v5_quest_proto'）
   *   opts.onSave      - 外部持久化钩子（可接主存档 state.v5.quest）
   */
  constructor(opts = {}) {
    this.registry = opts.registry || QUEST_REGISTRY;
    this.storageKey = opts.storageKey || 'v5_quest_proto';
    this.onSave = opts.onSave || null;
    this.state = {
      current: null,          // 当前进行中的课题 id
      quests: [],             // 各课题进度 [{questId, completedSteps, lastStep, hintsUsed, totalScore, done}]
      settings: { hintsPenalty: 15, partialCredit: true }
    };
    this._load();
  }

  // ---------- 基础查询 ----------
  listQuests() { return this.registry.slice(); }
  getQuest(questId) { return this.registry.find((q) => q.id === questId) || null; }
  getProgress(questId) {
    return this.state.quests.find((p) => p.questId === questId) || null;
  }
  isUnlocked(quest, realmId) {
    return (realmId || 0) >= (quest.realmGate || 1);
  }

  // ---------- 加载 / 开始 / 恢复 ----------
  load(questId) {
    const q = this.getQuest(questId);
    if (!q) throw new Error(`[V5Quest] 未知课题: ${questId}`);
    return q;
  }

  start(questId) {
    const q = this.load(questId);
    let prog = this.getProgress(questId);
    if (!prog) {
      prog = {
        questId: q.id,
        completedSteps: [],
        lastStep: q.steps[0] ? q.steps[0].stepId : null,
        hintsUsed: 0,
        totalScore: 0,
        done: false
      };
      this.state.quests.push(prog);
    }
    this.state.current = questId;
    this._save();
    return { quest: q, progress: prog };
  }

  resume() {
    if (!this.state.current) return null;
    const q = this.getQuest(this.state.current);
    const prog = this.getProgress(this.state.current);
    return q && prog ? { quest: q, progress: prog } : null;
  }

  // ---------- 当前步骤 ----------
  currentStep(questId) {
    const q = this.load(questId);
    const prog = this.getProgress(questId);
    if (!prog) return null;
    if (prog.done) return null;
    const step = q.steps.find((s) => s.stepId === prog.lastStep);
    return step || null;
  }

  // ---------- 提交答案 ----------
  /**
   * @returns {Object} { stepId, pass, score, partial, hintsUsed, reward, nextStep, done }
   */
  submitStep(stepId, answer) {
    const questId = this.state.current;
    if (!questId) throw new Error('[V5Quest] 未开始任何课题');
    const q = this.load(questId);
    const prog = this.getProgress(questId);
    if (!prog) throw new Error('[V5Quest] 课题无进度记录');

    const idx = q.steps.findIndex((s) => s.stepId === stepId);
    if (idx < 0) throw new Error(`[V5Quest] 未知步骤: ${stepId}`);
    if (idx !== q.steps.findIndex((s) => s.stepId === prog.lastStep)) {
      return { error: 'NOT_CURRENT_STEP', stepId };
    }

    const step = q.steps[idx];
    const { pass, score } = gradeStep(step, answer);

    // 提示扣分（仅答对时生效，且不扣到 0 以下）
    let finalScore = score;
    if (pass && prog.hintsUsed > 0 && this.state.settings.hintsPenalty > 0) {
      finalScore = Math.max(0, score - prog.hintsUsed * this.state.settings.hintsPenalty);
    }

    const partial = pass && finalScore < 100;

    // 记录进度
    if (!prog.completedSteps.includes(stepId)) {
      prog.completedSteps.push(stepId);
    }
    prog.totalScore = Math.round(prog.totalScore + finalScore);

    // 是否完成全部步骤
    const allDone = q.steps.every((s) => prog.completedSteps.includes(s.stepId));
    let reward = null;
    if (pass) {
      const base = computeReward(step);
      // 部分得分按比例折算奖励
      const ratio = finalScore / 100;
      reward = {
        coins: Math.round(base.coins * ratio),
        exp: Math.round(base.exp * ratio),
        petBonus: +(base.petBonus * ratio).toFixed(2),
        realmProgress: +(base.realmProgress * ratio).toFixed(2)
      };
    }

    if (allDone) {
      prog.done = true;
      prog.lastStep = null;
    } else {
      prog.lastStep = q.steps[idx + 1] ? q.steps[idx + 1].stepId : null;
    }

    this._save();
    return {
      stepId,
      pass,
      score: finalScore,
      partial,
      hintsUsed: prog.hintsUsed,
      reward,
      nextStep: prog.lastStep,
      done: prog.done,
      totalScore: prog.totalScore
    };
  }

  // ---------- 提示 ----------
  useHint() {
    const prog = this.getProgress(this.state.current);
    if (!prog) return null;
    prog.hintsUsed += 1;
    this._save();
    return { hintsUsed: prog.hintsUsed, penaltyPerHint: this.state.settings.hintsPenalty };
  }

  // 跨链接到 AI 陪练（仅占位，不实现 AI 接口）
  showTutorHint(step) {
    const href = '/v5/minigame/ai-tutor/?quest=' + (this.state.current || '') + '&step=' + (step ? step.stepId : '');
    if (typeof window !== 'undefined') {
      // 原型期：返回跳转目标，由 UI 决定是否 window.open
      return { href, message: '这道题太难？去 AI 陪练室请教吧。' };
    }
    return { href, message: '这道题太难？去 AI 陪练室请教吧。' };
  }

  // ---------- 持久化 ----------
  _load() {
    if (typeof localStorage === 'undefined') return;
    try {
      const raw = localStorage.getItem(this.storageKey);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && Array.isArray(parsed.quests)) {
          this.state.quests = parsed.quests;
          this.state.current = parsed.current || null;
          if (parsed.settings) this.state.settings = Object.assign(this.state.settings, parsed.settings);
        }
      }
    } catch (e) {
      // 损坏存档静默回退到空状态
    }
  }

  _save() {
    const payload = {
      current: this.state.current,
      quests: this.state.quests,
      settings: this.state.settings,
      schemaVersion: 1
    };
    if (typeof localStorage !== 'undefined') {
      try { localStorage.setItem(this.storageKey, JSON.stringify(payload)); } catch (e) { /* 配额不足忽略 */ }
    }
    if (this.onSave) this.onSave(payload);
  }

  // ---------- 导出 / 导入（原型期调试用） ----------
  exportState() { return JSON.stringify(this.state, null, 2); }
  importState(json) {
    const parsed = JSON.parse(json);
    if (parsed && Array.isArray(parsed.quests)) this.state = parsed;
    this._save();
    return this.state;
  }
}

// 兼容双端导出
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { V5QuestEngine, QUEST_REGISTRY, computeReward, gradeStep };
} else if (typeof window !== 'undefined') {
  window.V5QuestEngine = V5QuestEngine;
  window.V5Quest = { V5QuestEngine, QUEST_REGISTRY };
}
