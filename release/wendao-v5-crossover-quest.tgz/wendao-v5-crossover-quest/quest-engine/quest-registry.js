/**
 * 《问道修仙学院》v5.1 §5 跨学科课题系统 — 课题注册表
 * QUEST REGISTRY — 8 大修仙课题 × 60 关
 * 每个课题由 3-5 个学科交叉构成；每步含 subject / difficulty(1-5) / answerType
 * answerType: choice(选项) | numeric(数值) | validate(函数校验)
 * 步骤总数 = 8 + 7 + 8 + 7 + 7 + 7 + 8 + 8 = 60
 * 本文件为纯数据，可被 engine.js 在 Node(require) 与浏览器(window.QUEST_REGISTRY) 双端加载。
 */
'use strict';

const QUEST_REGISTRY = [
  // ============================================================
  // Q1 洞府选址 — 地理×物理×数学×生物×化学 (8 步)
  // ============================================================
  {
    id: 'Q1',
    title: '洞府选址',
    theme: '地理堪舆 · 五行相生',
    realmGate: 1,
    subjects: ['geography', 'physics', 'math', 'biology', 'chemistry'],
    desc: '为宗门挑选灵气充盈的洞府，综合地理、物理、数学、生物与化学知识完成堪舆。',
    steps: [
      { stepId: 'Q1-S1', subject: 'geography', difficulty: 1, answerType: 'choice',
        question: '洞府宜建在背风向阳、水源充沛之地。下列哪种地形最符合“藏风聚气”？',
        options: ['A. 陡峭山顶风口', 'B. 三面环山、一面临水的凹地', 'C. 沙漠腹地', 'D. 河心沙洲'],
        exactAnswer: 'B', hint: '古人选址讲究“负阴抱阳、背山面水”。', reward: { coins: 12, exp: 10 } },
      { stepId: 'Q1-S2', subject: 'physics', difficulty: 2, answerType: 'choice',
        question: '洞府开凿于山体，需评估岩层承压。若洞顶岩层厚 30 m，密度 2.6 g/cm³，g=10 N/kg，洞顶单位面积承受的压强约为？',
        options: ['A. 7.8×10⁵ Pa', 'B. 3.9×10⁵ Pa', 'C. 1.3×10⁶ Pa', 'D. 7.8×10⁴ Pa'],
        exactAnswer: 'A', hint: 'P = ρgh，注意单位换算：2.6 g/cm³ = 2600 kg/m³。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q1-S3', subject: 'math', difficulty: 2, answerType: 'numeric',
        question: '洞府平面呈矩形，长 24 m、宽 18 m。若按每 6 m² 布一座聚灵阵基，需布阵基多少座？',
        expected: 72, exactAnswer: '72', hint: '面积 = 长 × 宽，再除以 6。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q1-S4', subject: 'biology', difficulty: 2, answerType: 'choice',
        question: '洞府周边灵植繁茂，说明土壤肥力与微生物活跃。下列哪种微生物对灵植根系共生固氮最重要？',
        options: ['A. 硝化细菌', 'B. 根瘤菌', 'C. 乳酸菌', 'D. 酵母菌'],
        exactAnswer: 'B', hint: '豆科植物与根瘤菌共生固氮。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q1-S5', subject: 'chemistry', difficulty: 3, answerType: 'choice',
        question: '洞府水源检测发现 pH=5.5，偏酸。欲中和至近中性，下列哪种物质最适宜？',
        options: ['A. 浓硫酸', 'B. 生石灰(CaO)', 'C. 食盐', 'D. 酒精'],
        exactAnswer: 'B', hint: '碱性氧化物可中和酸性水。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q1-S6', subject: 'geography', difficulty: 3, answerType: 'choice',
        question: '堪舆需避开水脉断层。下列哪种地质构造最易引发地气泄漏？',
        options: ['A. 背斜顶部', 'B. 断层破碎带', 'C. 向斜核部', 'D. 侵入岩体'],
        exactAnswer: 'B', hint: '断层带岩层破碎，地气沿裂隙外泄。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q1-S7', subject: 'physics', difficulty: 4, answerType: 'numeric',
        question: '洞府需布设隔音结界，要求将外界 80 dB 噪声降至 40 dB。结界需衰减多少分贝？',
        expected: 40, exactAnswer: '40', hint: '衰减量 = 原分贝 − 目标分贝。', reward: { coins: 22, exp: 20 } },
      { stepId: 'Q1-S8', subject: 'chemistry', difficulty: 4, answerType: 'validate',
        question: '洞府灵气浓度检测：测得 CO₂ 体积分数 0.12%（正常 0.03%）。请判断通风是否达标并说明理由。',
        expected: 'CO₂ 超标 4 倍，需加强通风', validate: (a) => { const s = String(a || ''); return s.includes('超标') || s.includes('0.12'); },
        hint: '正常大气 CO₂ 约 0.03%，0.12% 为其 4 倍。', reward: { coins: 22, exp: 20 } }
    ]
  },

  // ============================================================
  // Q2 宗门防御 — 数学×物理×化学 (7 步)
  // ============================================================
  {
    id: 'Q2',
    title: '宗门防御',
    theme: '护山大阵 · 攻防测算',
    realmGate: 2,
    subjects: ['math', 'physics', 'chemistry'],
    desc: '设计护山大阵与防御工事，用数学与物理测算攻防，以化学加固阵基。',
    steps: [
      { stepId: 'Q2-S1', subject: 'math', difficulty: 1, answerType: 'numeric',
        question: '护山大阵呈圆形，半径 100 m。阵墙周长约为多少米？（π 取 3.14）',
        expected: 628, exactAnswer: '628', hint: '周长 = 2πr。', reward: { coins: 12, exp: 10 } },
      { stepId: 'Q2-S2', subject: 'physics', difficulty: 2, answerType: 'choice',
        question: '敌方投石机以 45° 角抛射石块，欲使射程最远。忽略空气阻力，最佳抛射角为？',
        options: ['A. 30°', 'B. 45°', 'C. 60°', 'D. 90°'],
        exactAnswer: 'B', hint: '斜抛运动中 45° 射程最远。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q2-S3', subject: 'chemistry', difficulty: 2, answerType: 'choice',
        question: '阵基用石灰浆加固。石灰浆主要成分 Ca(OH)₂ 与空气中哪种气体反应而硬化？',
        options: ['A. O₂', 'B. N₂', 'C. CO₂', 'D. H₂'],
        exactAnswer: 'C', hint: 'Ca(OH)₂ + CO₂ → CaCO₃↓ + H₂O。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q2-S4', subject: 'math', difficulty: 3, answerType: 'numeric',
        question: '敌阵 3000 人分三路进攻，按 5:3:2 分配兵力。中路（系数 3）有多少人？',
        expected: 900, exactAnswer: '900', hint: '总份数 5+3+2=10，3000×3/10。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q2-S5', subject: 'physics', difficulty: 3, answerType: 'choice',
        question: '护城吊桥用滑轮组提升。动滑轮可省一半力，若桥重 2000 N（忽略摩擦），需用多大力拉起？',
        options: ['A. 2000 N', 'B. 1000 N', 'C. 500 N', 'D. 4000 N'],
        exactAnswer: 'B', hint: '一个动滑轮省力一半。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q2-S6', subject: 'math', difficulty: 4, answerType: 'numeric',
        question: '防御阵每轮可抵挡 120 次攻击，敌方每秒进攻 4 次。阵可持续抵挡多少秒？',
        expected: 30, exactAnswer: '30', hint: '120 ÷ 4。', reward: { coins: 22, exp: 20 } },
      { stepId: 'Q2-S7', subject: 'chemistry', difficulty: 4, answerType: 'validate',
        question: '守城需制烟幕弹。请写出用硝酸铵受热分解产生大量气体的化学原理（写出产物之一即可）。',
        expected: 'N₂O 或 水蒸气', validate: (a) => { const s = String(a || ''); return s.includes('N2O') || s.includes('N₂O') || s.includes('水'); },
        hint: 'NH₄NO₃ 受热分解产生 N₂O 与 H₂O。', reward: { coins: 22, exp: 20 } }
    ]
  },

  // ============================================================
  // Q3 丹药炼制 — 化学×生物×物理 (8 步)
  // ============================================================
  {
    id: 'Q3',
    title: '丹药炼制',
    theme: '丹炉火候 · 药性配伍',
    realmGate: 3,
    subjects: ['chemistry', 'biology', 'physics'],
    desc: '从药性配伍到火候控制，以化学、生物与物理知识炼制上品丹药。',
    steps: [
      { stepId: 'Q3-S1', subject: 'chemistry', difficulty: 1, answerType: 'choice',
        question: '炼丹炉需控温。下列哪种操作能降低炉内温度？',
        options: ['A. 加大鼓风', 'B. 减少燃料并减弱鼓风', 'C. 增加燃料', 'D. 封闭出气口'],
        exactAnswer: 'B', hint: '减少燃料供给可降温。', reward: { coins: 12, exp: 10 } },
      { stepId: 'Q3-S2', subject: 'biology', difficulty: 2, answerType: 'choice',
        question: '灵草“血竭”入药取其活血化瘀之效。其有效成分主要存在于植物哪个部位？',
        options: ['A. 叶片', 'B. 树脂/茎干渗出物', 'C. 花朵', 'D. 种子'],
        exactAnswer: 'B', hint: '血竭为棕榈科植物树脂。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q3-S3', subject: 'physics', difficulty: 2, answerType: 'numeric',
        question: '丹炉以 220 V 供电，功率 1100 W。工作电流为多少安培？',
        expected: 5, exactAnswer: '5', hint: 'I = P / U。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q3-S4', subject: 'chemistry', difficulty: 3, answerType: 'choice',
        question: '丹药需在弱碱性环境成丹。下列哪种物质可作弱碱调节剂？',
        options: ['A. 稀盐酸', 'B. 小苏打(NaHCO₃)', 'C. 纯碱(Na₂CO₃)', 'D. 白醋'],
        exactAnswer: 'B', hint: 'NaHCO₃ 水溶液呈弱碱性。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q3-S5', subject: 'biology', difficulty: 3, answerType: 'choice',
        question: '炼制“培元丹”需提取灵芝多糖。多糖的基本组成单位是？',
        options: ['A. 氨基酸', 'B. 单糖', 'C. 脂肪酸', 'D. 核苷酸'],
        exactAnswer: 'B', hint: '多糖由单糖脱水缩合而成。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q3-S6', subject: 'physics', difficulty: 3, answerType: 'numeric',
        question: '丹炉升温需吸收 2.1×10⁵ J 热量，比热容 c=4200 J/(kg·℃)，药液 5 kg。温度升高多少℃？',
        expected: 10, exactAnswer: '10', hint: 'Δt = Q / (cm)。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q3-S7', subject: 'chemistry', difficulty: 4, answerType: 'choice',
        question: '“九转还魂丹”需去除药液中的重金属杂质。下列哪种方法最有效？',
        options: ['A. 过滤', 'B. 蒸馏', 'C. 沉淀/离子交换', 'D. 蒸发结晶'],
        exactAnswer: 'C', hint: '重金属离子需化学沉淀或交换去除。', reward: { coins: 22, exp: 20 } },
      { stepId: 'Q3-S8', subject: 'biology', difficulty: 4, answerType: 'validate',
        question: '丹药服用后需忌口。请说明为何服用温补丹药期间不宜大量饮茶（提示：鞣酸与药效成分结合）。',
        expected: '鞣酸与药效成分结合影响吸收', validate: (a) => { const s = String(a || ''); return s.includes('鞣酸') || s.includes('结合') || s.includes('吸收'); },
        hint: '茶叶中鞣酸易与生物碱/金属离子结合。', reward: { coins: 22, exp: 20 } }
    ]
  },

  // ============================================================
  // Q4 阵法布置 — 数学×物理×语文 (7 步)
  // ============================================================
  {
    id: 'Q4',
    title: '阵法布置',
    theme: '九宫八卦 · 阵眼推演',
    realmGate: 4,
    subjects: ['math', 'physics', 'chinese'],
    desc: '以数学推演阵位、物理测算能量流转、语文解读阵诀。',
    steps: [
      { stepId: 'Q4-S1', subject: 'math', difficulty: 1, answerType: 'choice',
        question: '九宫格阵每行每列数字之和须相等。1-9 填入九宫格，中心格固定为？',
        options: ['A. 1', 'B. 5', 'C. 9', 'D. 3'],
        exactAnswer: 'B', hint: '洛书九宫，中心为 5。', reward: { coins: 12, exp: 10 } },
      { stepId: 'Q4-S2', subject: 'physics', difficulty: 2, answerType: 'choice',
        question: '阵眼灵石发光需能量。灵石能量转换效率 20%，输入灵能 500 J，输出光能多少？',
        options: ['A. 100 J', 'B. 250 J', 'C. 400 J', 'D. 500 J'],
        exactAnswer: 'A', hint: '输出 = 输入 × 效率。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q4-S3', subject: 'chinese', difficulty: 2, answerType: 'choice',
        question: '阵诀曰：“天行健，君子以自强不息。”此句出自哪部典籍？',
        options: ['A. 《道德经》', 'B. 《周易》', 'C. 《论语》', 'D. 《庄子》'],
        exactAnswer: 'B', hint: '出自《周易·乾卦》象传。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q4-S4', subject: 'math', difficulty: 3, answerType: 'numeric',
        question: '八卦阵 8 个方位各布 3 块灵石，共需多少块？',
        expected: 24, exactAnswer: '24', hint: '8 × 3。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q4-S5', subject: 'physics', difficulty: 3, answerType: 'choice',
        question: '阵中能量沿导线传输，导线电阻 2 Ω，电流 3 A。导线发热功率为？',
        options: ['A. 6 W', 'B. 9 W', 'C. 12 W', 'D. 18 W'],
        exactAnswer: 'D', hint: 'P = I²R = 9×2。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q4-S6', subject: 'chinese', difficulty: 4, answerType: 'choice',
        question: '阵诀“亢龙有悔”出自《周易》乾卦上九爻辞。其含义最贴切的是？',
        options: ['A. 盛极而衰，须防过亢', 'B. 龙腾九天，势不可挡', 'C. 潜龙勿用，静待时机', 'D. 见龙在田，利见大人'],
        exactAnswer: 'A', hint: '“亢”为过高，物极必反。', reward: { coins: 22, exp: 20 } },
      { stepId: 'Q4-S7', subject: 'math', difficulty: 4, answerType: 'validate',
        question: '阵眼需满足“五行相生”链：金→水→木→火→土→金。请写出木生火的相生关系（一句话即可）。',
        expected: '木生火', validate: (a) => { const s = String(a || ''); return s.includes('木') && s.includes('火'); },
        hint: '五行相生：钻木取火。', reward: { coins: 22, exp: 20 } }
    ]
  },

  // ============================================================
  // Q5 灵脉勘探 — 地理×化学×物理 (7 步)
  // ============================================================
  {
    id: 'Q5',
    title: '灵脉勘探',
    theme: '地脉走向 · 矿藏鉴定',
    realmGate: 5,
    subjects: ['geography', 'chemistry', 'physics'],
    desc: '沿地脉寻矿，用地理判断走向、化学鉴定矿质、物理测算储量。',
    steps: [
      { stepId: 'Q5-S1', subject: 'geography', difficulty: 1, answerType: 'choice',
        question: '灵脉多沿褶皱构造分布。下列哪种构造最利于矿液富集？',
        options: ['A. 背斜顶部', 'B. 向斜核部', 'C. 断层带', 'D. 平原沉积层'],
        exactAnswer: 'A', hint: '背斜顶部裂隙利于矿液充填。', reward: { coins: 12, exp: 10 } },
      { stepId: 'Q5-S2', subject: 'chemistry', difficulty: 2, answerType: 'choice',
        question: '探得矿石呈赤红色，主要成分为 Fe₂O₃。该矿为？',
        options: ['A. 磁铁矿', 'B. 赤铁矿', 'C. 黄铁矿', 'D. 菱铁矿'],
        exactAnswer: 'B', hint: '赤铁矿主成分 Fe₂O₃，呈红褐色。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q5-S3', subject: 'physics', difficulty: 2, answerType: 'numeric',
        question: '用声波探测矿层，声波在岩层中速度 4000 m/s，反射波 0.5 s 返回。矿层深度为多少米？',
        expected: 1000, exactAnswer: '1000', hint: '深度 = 速度 × 时间 ÷ 2。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q5-S4', subject: 'geography', difficulty: 3, answerType: 'choice',
        question: '灵脉沿河流阶地延伸。河流阶地主要由哪种外力作用形成？',
        options: ['A. 风力侵蚀', 'B. 流水侵蚀与堆积', 'C. 冰川搬运', 'D. 火山喷发'],
        exactAnswer: 'B', hint: '阶地是地壳抬升与流水下切共同作用。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q5-S5', subject: 'chemistry', difficulty: 3, answerType: 'choice',
        question: '矿样滴加稀盐酸产生大量气泡，气体使澄清石灰水变浑浊。矿样含？',
        options: ['A. 碳酸盐', 'B. 硫酸盐', 'C. 硅酸盐', 'D. 硝酸盐'],
        exactAnswer: 'A', hint: 'CO₂ 使石灰水变浑浊，来自碳酸盐。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q5-S6', subject: 'physics', difficulty: 4, answerType: 'numeric',
        question: '灵脉矿石密度 5 g/cm³，测得体积 2000 cm³。矿石质量为多少克？',
        expected: 10000, exactAnswer: '10000', hint: 'm = ρV。', reward: { coins: 22, exp: 20 } },
      { stepId: 'Q5-S7', subject: 'geography', difficulty: 4, answerType: 'validate',
        question: '灵脉附近发现温泉，说明地热活动活跃。请说明温泉形成的一个地质条件。',
        expected: '地热/岩浆活动或断裂带', validate: (a) => { const s = String(a || ''); return s.includes('地热') || s.includes('岩浆') || s.includes('断裂'); },
        hint: '温泉多与地热梯度或断层有关。', reward: { coins: 22, exp: 20 } }
    ]
  },

  // ============================================================
  // Q6 灵兽捕捉 — 生物×数学×化学 (7 步)
  // ============================================================
  {
    id: 'Q6',
    title: '灵兽捕捉',
    theme: '驯兽之道 · 生态习性',
    realmGate: 6,
    subjects: ['biology', 'math', 'chemistry'],
    desc: '了解灵兽生态习性，以数学布设陷阱、化学配置诱饵。',
    steps: [
      { stepId: 'Q6-S1', subject: 'biology', difficulty: 1, answerType: 'choice',
        question: '灵狐昼伏夜出，属于哪种生态习性？',
        options: ['A. 夜行性', 'B. 昼行性', 'C. 冬眠', 'D. 迁徙'],
        exactAnswer: 'A', hint: '夜行性动物夜间活动。', reward: { coins: 12, exp: 10 } },
      { stepId: 'Q6-S2', subject: 'math', difficulty: 2, answerType: 'numeric',
        question: '捕捉灵兽需布设 3 圈陷阱，每圈 12 个，共需多少个陷阱？',
        expected: 36, exactAnswer: '36', hint: '3 × 12。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q6-S3', subject: 'biology', difficulty: 2, answerType: 'choice',
        question: '灵兽幼崽需母乳喂养。哺乳动物区别于其他动物的核心特征是？',
        options: ['A. 恒温', 'B. 胎生哺乳', 'C. 有脊椎', 'D. 用肺呼吸'],
        exactAnswer: 'B', hint: '胎生哺乳是哺乳纲特有。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q6-S4', subject: 'chemistry', difficulty: 3, answerType: 'choice',
        question: '诱饵需散发气味吸引灵兽。下列哪种物质挥发最快、气味扩散最广？',
        options: ['A. 固态油脂', 'B. 液态芳香精油', 'C. 浓盐水', 'D. 糖浆'],
        exactAnswer: 'B', hint: '挥发性液体分子易扩散。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q6-S5', subject: 'math', difficulty: 3, answerType: 'numeric',
        question: '灵兽群共 45 只，公母比 2:3。母兽有多少只？',
        expected: 27, exactAnswer: '27', hint: '45 × 3/5。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q6-S6', subject: 'biology', difficulty: 4, answerType: 'choice',
        question: '灵鹤迁徙依赖地磁感应。动物感知地磁场主要依靠？',
        options: ['A. 视觉', 'B. 磁感应器官/磁铁矿颗粒', 'C. 嗅觉', 'D. 听觉'],
        exactAnswer: 'B', hint: '部分动物体内含磁铁矿颗粒。', reward: { coins: 22, exp: 20 } },
      { stepId: 'Q6-S7', subject: 'chemistry', difficulty: 4, answerType: 'validate',
        question: '捕捉后需对灵兽消毒伤口。请写出常用消毒剂（如碘伏/酒精）的一个作用原理。',
        expected: '使蛋白质变性杀菌', validate: (a) => { const s = String(a || ''); return s.includes('蛋白') || s.includes('变性') || s.includes('杀菌'); },
        hint: '酒精/碘伏使菌体蛋白质变性。', reward: { coins: 22, exp: 20 } }
    ]
  },

  // ============================================================
  // Q7 宗门战备 — 数学×历史×物理 (8 步)
  // ============================================================
  {
    id: 'Q7',
    title: '宗门战备',
    theme: '粮草辎重 · 兵家韬略',
    realmGate: 7,
    subjects: ['math', 'history', 'physics'],
    desc: '统筹宗门战备物资，以数学测算补给、历史借鉴韬略、物理设计器械。',
    steps: [
      { stepId: 'Q7-S1', subject: 'math', difficulty: 1, answerType: 'numeric',
        question: '宗门每月需灵石 600 块，备战 5 个月。共需储备多少块？',
        expected: 3000, exactAnswer: '3000', hint: '600 × 5。', reward: { coins: 12, exp: 10 } },
      { stepId: 'Q7-S2', subject: 'history', difficulty: 2, answerType: 'choice',
        question: '兵书云“知己知彼，百战不殆”，出自哪部典籍？',
        options: ['A. 《孙子兵法》', 'B. 《六韬》', 'C. 《司马法》', 'D. 《尉缭子》'],
        exactAnswer: 'A', hint: '出自《孙子兵法·谋攻篇》。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q7-S3', subject: 'physics', difficulty: 2, answerType: 'choice',
        question: '投石车将 50 kg 石块以 20 m/s 水平抛出。石块动能约为？',
        options: ['A. 500 J', 'B. 1000 J', 'C. 10000 J', 'D. 20000 J'],
        exactAnswer: 'C', hint: 'Ek = ½mv² = ½×50×400。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q7-S4', subject: 'math', difficulty: 3, answerType: 'numeric',
        question: '补给车队每辆可载 200 石，共需运 1600 石。需多少辆车？',
        expected: 8, exactAnswer: '8', hint: '1600 ÷ 200。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q7-S5', subject: 'history', difficulty: 3, answerType: 'choice',
        question: '“围魏救赵”之计出自哪场著名战役？',
        options: ['A. 桂陵之战', 'B. 长平之战', 'C. 赤壁之战', 'D. 淝水之战'],
        exactAnswer: 'A', hint: '孙膑围魏救赵，桂陵之战。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q7-S6', subject: 'physics', difficulty: 3, answerType: 'numeric',
        question: '守城滚木从 20 m 高滚落（g=10 N/kg）。不计阻力，触地速度约为多少 m/s？',
        expected: 20, exactAnswer: '20', hint: 'v = √(2gh) = √400。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q7-S7', subject: 'math', difficulty: 4, answerType: 'numeric',
        question: '战备粮按 3 个月 5400 石计算，每月消耗 1800 石。若增兵 50%，每月消耗变为多少？',
        expected: 2700, exactAnswer: '2700', hint: '1800 × 1.5。', reward: { coins: 22, exp: 20 } },
      { stepId: 'Q7-S8', subject: 'history', difficulty: 4, answerType: 'validate',
        question: '请用一句话概括《孙子兵法》“不战而屈人之兵”的核心思想。',
        expected: '以谋略取胜而非硬拼', validate: (a) => { const s = String(a || ''); return s.includes('谋') || s.includes('屈') || s.includes('不战'); },
        hint: '强调以智谋使敌军屈服。', reward: { coins: 22, exp: 20 } }
    ]
  },

  // ============================================================
  // Q8 仙缘择配 — 语文×英语×历史 (8 步)
  // ============================================================
  {
    id: 'Q8',
    title: '仙缘择配',
    theme: '红鸾星动 · 文辞传情',
    realmGate: 8,
    subjects: ['chinese', 'english', 'history'],
    desc: '以文辞与史鉴处理仙缘之事，语文表意、英语传信、历史明理。',
    steps: [
      { stepId: 'Q8-S1', subject: 'chinese', difficulty: 1, answerType: 'choice',
        question: '“关关雎鸠，在河之洲”出自哪部诗集？',
        options: ['A. 《诗经》', 'B. 《楚辞》', 'C. 《乐府诗集》', 'D. 《全唐诗》'],
        exactAnswer: 'A', hint: '《诗经·国风·周南·关雎》。', reward: { coins: 12, exp: 10 } },
      { stepId: 'Q8-S2', subject: 'english', difficulty: 2, answerType: 'choice',
        question: 'To express “愿与你共赴仙途”, the best English phrase is?',
        options: ['A. I want to leave you.', 'B. I wish to walk the immortal path with you.', 'C. Go away please.', 'D. I am busy today.'],
        exactAnswer: 'B', hint: '“共赴仙途”= walk the immortal path together。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q8-S3', subject: 'history', difficulty: 2, answerType: 'choice',
        question: '“举案齐眉”形容夫妻相敬如宾，典出东汉哪对夫妇？',
        options: ['A. 梁鸿与孟光', 'B. 司马相如与卓文君', 'C. 诸葛亮与黄月英', 'D. 王献之与郗道茂'],
        exactAnswer: 'A', hint: '梁鸿孟光举案齐眉。', reward: { coins: 15, exp: 14 } },
      { stepId: 'Q8-S4', subject: 'chinese', difficulty: 3, answerType: 'choice',
        question: '情书开篇“见字如面，展信舒颜”，此句属于哪种修辞/表达？',
        options: ['A. 比喻', 'B. 顶真', 'C. 对偶/骈句', 'D. 夸张'],
        exactAnswer: 'C', hint: '“见字如面”对“展信舒颜”。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q8-S5', subject: 'english', difficulty: 3, answerType: 'choice',
        question: 'Which word best fits: “May our ___ last for a thousand years.” (缘分)',
        options: ['A. fate', 'B. fateful', 'C. fatal', 'D. fatality'],
        exactAnswer: 'A', hint: '缘分 = fate / destiny。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q8-S6', subject: 'history', difficulty: 3, answerType: 'choice',
        question: '“在天愿作比翼鸟，在地愿为连理枝”咏的是哪对帝妃爱情？',
        options: ['A. 唐明皇与杨贵妃', 'B. 汉武帝与卫子夫', 'C. 顺治与董鄂妃', 'D. 项羽与虞姬'],
        exactAnswer: 'A', hint: '白居易《长恨歌》咏唐玄宗与杨贵妃。', reward: { coins: 18, exp: 16 } },
      { stepId: 'Q8-S7', subject: 'chinese', difficulty: 4, answerType: 'validate',
        question: '请用一句古诗词表达“两情若是久长时，又岂在朝朝暮暮”的意境（写出原句或同义句）。',
        expected: '两情若是久长时，又岂在朝朝暮暮',
        validate: (a) => { const s = String(a || ''); return s.includes('久长') || s.includes('朝朝暮暮'); },
        hint: '秦观《鹊桥仙》名句。', reward: { coins: 22, exp: 20 } },
      { stepId: 'Q8-S8', subject: 'english', difficulty: 4, answerType: 'validate',
        question: 'Write a short blessing in English for your dao companion (≥3 words).',
        expected: 'any English blessing',
        validate: (a) => { const s = String(a || ''); return /[A-Za-z]{3,}/.test(s); },
        hint: '如 “May our dao last forever.”', reward: { coins: 22, exp: 20 } }
    ]
  }
];

// 兼容双端导出
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { QUEST_REGISTRY };
} else if (typeof window !== 'undefined') {
  window.QUEST_REGISTRY = QUEST_REGISTRY;
}
