# 《问道修仙学院》v5.1 §5 跨学科课题系统 — 接入教程

> 原型版本：2026-08-19 · 基于 main `4e86b2d5…` 本地只读构建
> 交付物：`quest-engine/`（engine.js / quest-registry.js / quest-ui.html）+ 本文档

---

## 1. 系统定位

跨学科课题系统（Cross-Subject Quest System）是 v5.0 架构重构后新增的**玩法层**：
玩家以“修仙课题”为单位，在一个课题内连续完成来自 **3–5 个学科** 的交叉题目，
把分散的学科题库串成有剧情、有门槛、有奖励的长期目标。

- 8 大课题 × 60 关（每关 = 1 步），每步绑定 `subject + difficulty + answerType`
- 课题有**境界门槛**（realmGate），未达标锁定
- 每步答对获得 `coins / exp / petBonus / realmProgress` 四类奖励
- 支持**部分得分**与**提示扣分**，鼓励思考而非盲猜
- 与 `/v5/minigame/ai-tutor/` 跨链接（原型期仅占位跳转）

---

## 2. 目录结构与文件职责

```
src/v5/quest/
├── engine.js          # V5QuestEngine 引擎（~15KB）
├── quest-registry.js  # 8 课题 × 60 步注册表（~10KB）
├── quest-ui.html      # 独立可运行 UI（~12KB）
└── docs/
    └── quest-tutorial-walkthrough.md  # 本文档（~5KB）
```

### 2.1 quest-registry.js（纯数据）
- 导出 `QUEST_REGISTRY`，Node 用 `module.exports`、浏览器挂 `window.QUEST_REGISTRY`
- 每个课题字段：`id / title / theme / realmGate / subjects[] / desc / steps[]`
- 每步字段：
  | 字段 | 说明 |
  |---|---|
  | `stepId` | 全局唯一，如 `Q1-S3` |
  | `subject` | 学科标签（geography/physics/math/biology/chemistry/chinese/english/history） |
  | `difficulty` | 1–5 |
  | `answerType` | `choice`（选项）/ `numeric`（数值）/ `validate`（函数或关键字） |
  | `question` | 题干 |
  | `options` + `exactAnswer` | choice 专用 |
  | `expected` + `exactAnswer` | numeric 专用（expected 供展示） |
  | `validate` | validate 专用（返回布尔或 0–100 数值） |
  | `hint` | 提示文案 |
  | `reward` | 基础奖励（UI 汇总时用） |

### 2.2 engine.js（引擎）
`V5QuestEngine` 核心 API：

| 方法 | 说明 |
|---|---|
| `listQuests()` | 返回全部课题 |
| `getQuest(id)` / `getProgress(id)` | 查询课题 / 进度 |
| `isUnlocked(quest, realmId)` | 门槛判定 |
| `start(questId)` | 开始或恢复课题，置为 current |
| `resume()` | 从存档恢复当前课题 |
| `currentStep(questId)` | 返回当前待答步骤 |
| `submitStep(stepId, answer)` | 校验并推进；返回 `{pass, score, partial, reward, nextStep, done}` |
| `useHint()` | 记录提示次数（答对时每题扣 15 分） |
| `showTutorHint(step)` | 跨链接到 AI 陪练（仅占位，不实现 AI 接口） |
| `exportState()` / `importState(json)` | 原型期调试用 |

**持久化**：默认存 `localStorage['v5_quest_proto']`，与主存档 `wendao_save_v2` 解耦；
接入正式版时通过构造参数 `onSave` 把 `payload` 写入 `state.v5.quest[]` 即可。

---

## 3. 步骤校验逻辑

`gradeStep(step, answer)` 按 `answerType` 分派：

1. **choice**：答案归一化（去空格/千分位）后与 `exactAnswer` 忽略大小写比对；对=100，错=0。
2. **numeric**：`parseFloat` 后与期望值做 `|got - want| < 1e-6` 判定。
3. **validate**：
   - 若 `validate` 是函数且返回**数值** → 视为 0–100 分，`>= 60` 判过（支持部分得分）；
   - 返回**布尔** → 真=100 / 假=0；
   - 无函数 → 退化为 `keywords[]` 命中率，`>= 60%` 判过。

**提示扣分**：答对时 `finalScore = max(0, score - hintsUsed * 15)`；
部分得分按 `finalScore/100` 折算奖励。

---

## 4. 奖励公式表

| difficulty | base(8+6d) | coins(×1.2) | exp(×1.0) | petBonus | realmProgress |
|---|---|---|---|---|---|
| 1 | 14 | 17 | 14 | 0 | 0.2 |
| 2 | 20 | 24 | 20 | 0 | 0.2 |
| 3 | 26 | 31 | 26 | 0 | 0.85 |
| 4 | 32 | 38 | 32 | 0.9 | 0.85 |
| 5 | 38 | 46 | 38 | 1.0 | 1.0 |

> 说明：`petBonus` 仅难度 ≥4 生效（高阶课题给灵宠成长加成）；
> `realmProgress` 难度 ≥3 显著提高（推动境界突破）。
> 实际发放按 `finalScore/100` 折算，答对但用了提示会略减。

---

## 5. 与 v5 Portal 的集成步骤

1. 将 `quest-engine/` 三个文件放入 `src/v5/quest/`。
2. 在 `src/_portal/index.html` 或 v5 主菜单增加入口：
   ```html
   <a href="v5/quest/quest-ui.html">📜 跨学科课题</a>
   ```
3. 正式接入存档：实例化时传入 `onSave` 钩子，把 `payload` 合并进 `state.v5.quest[]`：
   ```js
   const engine = new V5QuestEngine({
     storageKey: 'wendao_save_v2',   // 或直接走主存档
     onSave: (p) => { /* 写入主存档 state.v5.quest */ }
   });
   ```
4. 境界门槛数据源：`quest-ui.html` 当前用 `?realm=N` 模拟；正式版改为读取 `Game.state.char.realmId`。
5. AI 陪练：`showTutorHint()` 返回 `/v5/minigame/ai-tutor/?quest=..&step=..`，待 ai-tutor 模块就绪后替换为真实跳转。

---

## 6. 校验清单（原型期）

```bash
node --check src/v5/quest/engine.js
node --check src/v5/quest/quest-registry.js
# 步骤总数断言：8+7+8+7+7+7+8+8 = 60
```

---

## 7. 后续（v5.0 正式版）扩展方向

- 课题间**前置解锁链**（完成 Q1 才解锁 Q5 等）
- 每步**随机抽题**（从学科题库按难度/知识点采样，替换当前固定题）
- 奖励并入主存档经济系统（灵石/修为/灵宠经验）
- AI 陪练真实接入（讲解 + 举一反三）
